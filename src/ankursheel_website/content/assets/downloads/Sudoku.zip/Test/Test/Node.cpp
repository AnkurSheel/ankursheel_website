#include "Node.hpp"

Node::Node(int row , Header* head) 
{
	left=this;
	right=this;
	up=this;
	down=this;			
	this->row=row;
	this->head=head;			
}

Header::Header(int ID)
: size(0)
, ID(0)
{
	head = this;
}

