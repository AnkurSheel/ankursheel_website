// *****************************************************************************
//  my570MazeSol   version:  1.0   Ankur Sheel  date: 2010/03/24
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#include "my570SudokoSol.hpp"
#include "utility.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "myDebug.h"
#include "Node.hpp"
#include <math.h>
#include "my570list.hpp"

My570SudokuSol::My570SudokuSol(const int bPrintSolution, const int iNoOfSolutions, const int iDims)
: m_iDims(iDims)
, m_iTotSolutions(0)
, m_bPrintSolution(bPrintSolution)
, m_NoOfSolutions(iNoOfSolutions)
{
	m_iPuzzle = new int*[m_iDims];
	m_iSol = new int*[m_iDims];
	for(int i =0;i<m_iDims;i++)
	{
		m_iPuzzle[i] = new int[m_iDims] ;
		m_iSol[i] = new int[m_iDims] ;
	}
	m_RowIndex = new My570List();
}

My570SudokuSol::~My570SudokuSol()
{
	for(int i =0;i<m_iDims;i++)
	{
		SAFE_DELETE_ARRAY(m_iPuzzle[i]);
		SAFE_DELETE_ARRAY(m_iSol[i]);
	}
	SAFE_DELETE_ARRAY(m_iPuzzle);
	SAFE_DELETE_ARRAY(m_iSol);
	Reset();
	SAFE_DELETE(m_RowIndex);
	
}

int My570SudokuSol::ReadLine( FILE * fp, char* const buff )
{
	fgets(buff,MAXSTRINGLENGTH,fp);
	if(feof(fp))	
	{
		return FALSE;
	}
	return TRUE;;
}

void My570SudokuSol::Start( FILE *fp )
{
	InitializePuzzle( fp );
	//PrintMaze();
	BuildMatrix();
	BuildGrid();
	SolveSudoku();
	UnselectAllRows();
	//if(m_iTotSolutions == 1)
	//{
	//	PrintSolution();
	//}
	//else
	//{
	//		fprintf(stdout, "%d solutions found\n", m_iTotSolutions);	
	//}
}

void My570SudokuSol::InitializePuzzle( FILE * fp )
{
	char buff[MAXSTRINGLENGTH];
	int bEOF = ReadLine(fp, buff);
	if(!bEOF)
	{
		fprintf(stderr, "File empty\n");
		exit(0);
	}
	int height = 0;
	int index = 0;

	while(bEOF)
	{
		int i =0;
		index = 0;
		if(buff[i] == '+')
		{
			bEOF = ReadLine(fp, buff);
			continue;
		}
		while(buff[i] !='\0'
			&& buff[i] !='\n')
		{

			if(buff[i] != '|'
				&& buff[i] != '.'
				&& !(buff[i] >= '0'
				&& buff[i] <= '9'))
			{
				fprintf(stderr, "Incorrect character %s\n", buff);
				exit(0);
			}
			if(buff[i] == '|')
			{
				i++;
				continue;
			}
			if(buff[i] == '.')
			{
				m_iPuzzle[height][index] = 0;
				m_iSol[height][index] = -1;
			}
			if(buff[i] >= '0'
				&& buff[i] <= '9')
			{
				m_iPuzzle[height][index] = buff[i] - '0';
				m_iSol[height][index] = 0;
			}
			index++;
			i++;
		}
		if(index != m_iDims)
		{
			fprintf(stderr, "Incorrect length %s\n", buff);
			exit(1);
		}
		height++;
		bEOF = ReadLine(fp, buff);
	}
	if(height != m_iDims)
	{
		fprintf(stderr, "Incorrect height \n");
		exit(0);
	}
}


void My570SudokuSol::PrintMaze()
{
	fprintf(stdout, "+---+---+---+\n"); 
	for(int i =0;i<m_iDims;i++)
	{
		fprintf(stdout, "|"); 
		for(int j =0;j<m_iDims;j++)
		{
			if(m_iPuzzle[i][j] == 0)
			{
				fprintf(stdout, "."); 
			}
			else
			{
				fprintf(stdout, "%d", m_iPuzzle[i][j]); 
			}
			if(((j+1)%3) == 0)
			{
				fprintf(stdout, "|"); 
			}
		}
		fprintf(stdout, "\n"); 
		if(((i+1)%3) == 0)
		{
			fprintf(stdout, "+---+---+---+\n"); 
		}
	}
}

void My570SudokuSol::PrintSolution()
{
	fprintf(stdout, "+---+---+---+\n"); 
	for(int i =0;i<m_iDims;i++)
	{
		fprintf(stdout, "|"); 
		for(int j =0;j<m_iDims;j++)
		{
			if(m_iSol[i][j] == 0)
			{
				fprintf(stdout, "."); 
			}
			else
			{
				fprintf(stdout, "%d", m_iSol[i][j]); 
			}
			if(((j+1)%3) == 0)
			{
				fprintf(stdout, "|"); 
			}
		}
		fprintf(stdout, "\n"); 
		if(((i+1)%3) == 0)
		{
			fprintf(stdout, "+---+---+---+\n"); 
		}
	}
}

void My570SudokuSol::BuildMatrix()
{
	int r = m_iDims*m_iDims*m_iDims;
	int c = 4 * m_iDims * m_iDims;

	m_head = new Header(0);
	m_columns = new Header*[c];
	m_rows = new Node*[r];

	for(int i=0;i<c;i++)
	{
		m_columns[i] = new Header(i);
		m_columns[i]->left = m_head->left;
		m_columns[i]->right = m_head;
		m_head->left->right = m_columns[i];
		m_head->left = m_columns[i];
	}

	int b= 0;
	int sqrtDim = (int)sqrt((float)m_iDims);

	for (int r=0; r<m_iDims; r++) 
	{
		for (int c=0; c<m_iDims; c++) 
		{
			// set the block
			b=(r/sqrtDim)*sqrtDim+(c/sqrtDim);
			for (int d=0; d<m_iDims; d++) 
			{
				int row = r*m_iDims*m_iDims+c*m_iDims+d;
				Node * first = new Node(row);
				int constraint[4] = {r*m_iDims+c
					, m_iDims*(m_iDims+r)+d
					, m_iDims*(c+2*m_iDims)+d
					, m_iDims*(b+3*m_iDims)+d};

				first->head = m_columns[constraint[0]];
				first->head->size++;
				first->down = m_columns[constraint[0]];
				first->up = m_columns[constraint[0]]->up;
				m_columns[constraint[0]]->up->down= first;
				m_columns[constraint[0]]->up = first;
				m_rows[row] = first;

				for (int i=1; i<4; i++) 
				{
					Node* t=new Node(row);
					// left - right
					t->left=first->left;
					t->right=first;
					first->left->right=t;
					first->left=t;

					// up - down
					t->down=m_columns[constraint[i]];
					t->up=m_columns[constraint[i]]->up;
					m_columns[constraint[i]]->up->down=t;
					m_columns[constraint[i]]->up=t;

					// head
					t->head=m_columns[constraint[i]];
					t->head->size++;
				}
			}
		}
	}
}

void My570SudokuSol::BuildGrid()
{
	for (int r=0; r<m_iDims; r++) 
	{
		for (int c=0; c<m_iDims; c++) 
		{
			if (m_iPuzzle[r][c]!=0) 
			{
				int index = r*m_iDims*m_iDims+c*m_iDims+(m_iPuzzle[r][c]-1);
				Node *n = m_rows[index];
				m_RowIndex->Append((void*)n);
				do
				{
					CoverColumn(n->head);
					n = n->right;
				}
				while(n != m_rows[index]);
			}
		}
	}
}

void My570SudokuSol::CoverColumn(Header* c) 
{ 
	// header unplugging
	c->left->right=c->right;
	c->right->left=c->left;

	// nodes unplugging
	Node* i=c->down;
	Node* j=NULL;
	while (i!=c) 
	{
		j=i->right;
		while (j!=i) 
		{
			j->up->down=j->down;
			j->down->up=j->up;
			j->head->size--;
			j=j->right;
		}
		i=i->down;
	}
}

void My570SudokuSol::SolveSudoku()
{
	if(m_NoOfSolutions != 0
		&& m_iTotSolutions >= m_NoOfSolutions)
	{
		return;
	}
	if(m_head == m_head->right)
	{
		m_iTotSolutions++;
		if(m_bPrintSolution)
		{
			GetSolution();
			PrintSolution();
			if(m_NoOfSolutions != 0)
			{
				fprintf(stdout, "\n");
			}
		}
		return;
	}
	Header *c = FindMin();
	if(c->size == 0)
	{
		return;
	}

	CoverColumn(c);
	Node *r = c->down;
	Node *j = NULL;
	My570ListElem* curr = NULL;
	while(r!=c)
	{
		m_RowIndex->Append((void*)r);
		j= r->right;
		while(j!=r)
		{
			CoverColumn(j->head);
			j= j->right;
		}
		SolveSudoku();
		curr = m_RowIndex->Last();
		r = (Node*)(curr->Obj());
		m_RowIndex->Unlink(curr);

		c = r->head;
		j = r->left;
		while(j!=r)
		{
			UncoverColumn(j->head);
			j= j->left;
		}
		r= r->down;
	}
	UncoverColumn(c);
}

Header* My570SudokuSol::FindMin() 
{
	int min=0x7fffffff;
	Header* ret=NULL;
	Header* j=(Header*)m_head->right;
	while (j!=m_head) 
	{
		if (j->size < min) 
		{
			min=j->size;
			ret=j;
		}
		j=(Header*)j->right;
	}
	return ret;
}

void My570SudokuSol::UncoverColumn(Header* c) 
{ 
	// nodes plugging
	Node* i=c->up;
	Node* j=NULL;
	while (i!=c) 
	{
		j=i->left;
		while (j!=i) 
		{
			j->up->down=j;
			j->down->up=j;
			j->head->size++;
			j=j->left;
		}
		i=i->up;
	}
	c->left->right=c;
	c->right->left=c;
}

void My570SudokuSol::UnselectAllRows() 
{
	Node* n=((Node*)(m_RowIndex->Last())->Obj())->left;
	do 
	{
		UncoverColumn(n->head);
		n=n->left;
	} while (n!=m_rows[n->row]);
	UncoverColumn(n->head);
}

void My570SudokuSol::GetSolution()
{
	My570ListElem* first = m_RowIndex->First();
	My570ListElem* curr = first;
	int digit, row, column, val;

	do
	{
		val = ((Node*)curr->Obj())->row;
		digit = val % 9;
		val = val / 9;
		column = val % 9;
		val = val / 9;
		row = val % 9;

		if(m_iSol[row][column] == -1)
		{
			m_iSol[row][column] = digit + 1;
		}
		curr = m_RowIndex->Next(curr);

	}	while(curr !=first);
}

int My570SudokuSol::GetNoOfSolutions()
{
	return m_iTotSolutions;	
}

void My570SudokuSol::Start(int ** puzzleList)
{
	m_iTotSolutions = 0;
	InitializePuzzle(puzzleList);
	BuildMatrix();
	BuildGrid();
	SolveSudoku();
	UnselectAllRows();
	Reset();
}

void My570SudokuSol::InitializePuzzle( int ** iPuzzleList )
{
	for(int i =0;i<m_iDims;i++)
	{
		for(int j =0;j<m_iDims;j++)
		{
			m_iPuzzle[i][j] = iPuzzleList[i][j];
			m_iSol[i][j] = 0;
		}
	}
}

void My570SudokuSol::Reset()
{
	{
		My570ListElem* curr = m_RowIndex->Last();
		Node *n = NULL;
		int len = m_RowIndex->Length();
	  //  while (curr)
		for(int counter=0;counter<len;counter++)
		{
			n = ((Node*)(curr)->Obj())->left;
			Header *c = n->head;
			Node* i=c->up;
			Node* j=NULL;
			while (i!=c) 
			{
				j=i->left;
				while (j!=i) 
				{
					j=j->left;
				}
				i=i->up;
			}
			m_RowIndex->Unlink(curr);
			curr = m_RowIndex->Last();
		}
	}
	if(m_columns)
	{
		int c = 4 * m_iDims * m_iDims;
		for(int i=0;i<c;i++)
		{
			SAFE_DELETE(m_columns[i]);
		}
		SAFE_DELETE(m_columns);
	}
	if(m_rows)
	{
		int r = m_iDims*m_iDims*m_iDims;
		for(int i=0;i<r;i++)
		{
			Node* curr = m_rows[i];
			Node * temp;
			for (int j=0; j<4; j++) 
			{
				temp = curr->right;
				SAFE_DELETE(curr);
				curr = temp;
			}
		}
		SAFE_DELETE(m_rows);
	}
	SAFE_DELETE(m_head);
	m_RowIndex->UnlinkAll();
}
