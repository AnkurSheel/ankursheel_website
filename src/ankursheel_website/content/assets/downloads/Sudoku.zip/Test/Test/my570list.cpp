// ***************************************************************
//  my570list   version:  1.0   Ankur Sheel  date: 2010/02/21
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// ***************************************************************
// 
// ***************************************************************
#include "my570list.hpp"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "utility.h"
#include "myDebug.h"

My570List::My570List()
{
	num_members = 0;
	try 
	{
		anchor = new My570ListElem();
	}
	catch(...)
	{
		fprintf(stderr, "could not allocate memory\n");
		exit(1);
	}
	anchor->next = anchor;
	anchor->prev= anchor;
}

My570List::~My570List()
{
	UnlinkAll();
	SAFE_DELETE(anchor);
}

int  My570List::Append(void *obj)
{
	My570ListElem* curr = NULL;
	try 
	{
		curr = new My570ListElem();
	}
	catch(...)
	{
		fprintf(stderr, "could not allocate memory\n");
		return FALSE;
	}
	num_members++;

	curr->obj = obj;

	My570ListElem* last =  anchor->prev;
	last->next = curr;
	curr->prev= last;

	curr->next = anchor;
	anchor->prev = curr;
	
	return TRUE;
}

int  My570List::Prepend(void *obj)
{
	My570ListElem* curr = NULL;
	try 
	{
		curr = new My570ListElem();
	}
	catch(...)
	{
		return FALSE;
	}
	num_members++;

	curr->obj = obj;

	My570ListElem* first =  First();
	
	anchor->next = curr;
	curr->prev= anchor;

	curr->next = first;
	first->prev = curr;
	
	return TRUE;
}

void My570List::Unlink(My570ListElem* elem)
{
	My570ListElem* prevElem = elem->prev;
	My570ListElem* nextElem = elem->next;
	prevElem->next = nextElem;
	nextElem->prev = prevElem;
	SAFE_DELETE(elem);
	num_members--;
}

void My570List::UnlinkAll()
{
	My570ListElem *elem= anchor->next;
	if(!elem)
	{
		return;
	}
	anchor->next = anchor;
	anchor->prev = anchor;

	My570ListElem *nextElem = NULL;
	while(elem != NULL && elem!= anchor)
	{
		nextElem = elem->next;
		elem->prev = NULL;
		elem->next = NULL;
		SAFE_DELETE(elem);

		elem = nextElem;
	}
	num_members = 0;
}

int  My570List::InsertBefore(void *obj, My570ListElem *elem)
{
	if(elem == NULL)
	{
		return FALSE;
	}

	My570ListElem* curr = NULL;
	try 
	{
		curr = new My570ListElem();
	}
	catch(...)
	{
		return FALSE;
	}
	num_members++;	

	curr->obj = obj;
	
	My570ListElem * prevElem = elem->prev;

	prevElem->next = curr;
	curr->prev= prevElem;

	curr->next = elem;
	elem->prev = curr;
	
	return TRUE;
}

int  My570List::InsertAfter(void *obj, My570ListElem *elem)
{
	if(elem == NULL)
	{
		return FALSE;
	}

	My570ListElem* curr = NULL;
	try 
	{
		curr = new My570ListElem();
	}
	catch(...)
	{
		return FALSE;
	}
	num_members++;

	curr->obj = obj;
	
	My570ListElem * nextElem = elem->next;

	elem->next = curr;
	curr->prev= elem;

	curr->next = nextElem;
	nextElem->prev = curr;
	
	return TRUE;
}

My570ListElem* My570List::First()
{
	//if(anchor->next == anchor)
	//{
	//	return NULL;
	//}
	return anchor->next;
}
My570ListElem* My570List::Last()
{
	//if(anchor->prev == anchor)
	//{
	//	return NULL;
	//}
	return anchor->prev;
}
My570ListElem* My570List::Next(My570ListElem *cur)
{
	/*if(anchor->next == anchor)
	{
		return NULL;
	}*/
	if(cur->next == anchor)
	{
		return anchor->next;
	}
	return cur->next;
}
My570ListElem* My570List::Prev(My570ListElem *cur)
{
	/*if(anchor->prev == anchor)
	{
		return NULL;
	}*/
	if(cur->prev == anchor)
	{
		return anchor->prev;
	}
	return cur->prev;
}

My570ListElem* My570List::Find(void *obj)
{
	My570ListElem *first=First();
	My570ListElem *elem=first;
    //for (elem=First(); elem != NULL; elem=Next(elem)) 
	do
	{
		if(elem->Obj() == obj)
		{
			return elem;
		}
		elem = Next(elem);
    }
	while(elem != first);
	return NULL;

}

void My570List::Cover(My570ListElem *cur)
{
	cur->prev->next = cur->next;
	cur->next->prev = cur->prev;
	num_members--;
	
}
void My570List::UnCover(My570ListElem *cur)
{
	cur->prev->next = cur;
	cur->next->prev = cur;
	num_members++;
}
My570ListElem::My570ListElem(void *object)
{
	obj = object;
	next = NULL;
	prev = NULL;
}

My570ListElem::~My570ListElem()
{
	prev = NULL;
	next = NULL;
}

