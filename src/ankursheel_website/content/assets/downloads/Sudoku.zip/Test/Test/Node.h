#ifndef Node_h_
#define Node_h_

#include "cs570.h"

class Header;
class Node 
{
public:
	Node(int row =-1, Header* head = NULL);

	// neighbours
	Node *left;
	Node *right;
	Node *up;
	Node *down;

	// column header
	Header* head;
	int row;		
};

class Header
	: public Node
{
public:
	Header(int ID =0);
	int size;
	int ID;
};



#endif