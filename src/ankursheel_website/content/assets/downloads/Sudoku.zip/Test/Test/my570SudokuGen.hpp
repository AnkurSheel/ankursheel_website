// *****************************************************************************
//  myMazegen   version:  1.0   Ankur Sheel  date: 2010/03/23
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#ifndef myMazegen_h__
#define myMazegen_h__

#include <stdio.h>

class My570List;

class My570Cell
{
public:
	My570Cell(const int no, const int row, const int col);
public:
	int m_iNo;
	int m_iRow;
	int m_iCol;
};

class My570SudokuGen
{
public:
	My570SudokuGen(const int bInfo, const int iDims = 9);
	~My570SudokuGen();
	void Start( FILE *fp );

private:
	int ReadLine( FILE * fp);
	void PrintLists();
	void PrintMaze();
	int CreateBoard(const int row = 0, const int col = 0);
	void CreatePriorityLists( FILE * fp);
	void CreatePuzzle( FILE * fp, My570List* CellList);
	int CheckNoForConflict(const int CurrentRow, const int CurrentColumn, const int No);
	My570List** CreateCellLists();
private:
	FILE *m_fp;
	int m_bInfo;
	int m_iDims;
	int m_sqrtDim;
	int** m_iPuzzle;
	My570List** m_iLists;
};
#endif // myMazegen_h__
