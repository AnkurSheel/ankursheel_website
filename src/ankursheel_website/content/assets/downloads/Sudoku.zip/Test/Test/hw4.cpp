// *****************************************************************************
//  hw3   version:  1.0   Ankur Sheel  date: 2010/03/24
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "utility.h"
#include "my570SudokoSol.hpp"
#include "my570SudokuGen.hpp"
#include "myDebug.h"

static char gszProgName[MAXPATHLENGTH];

/* ----------------------- Utility Functions ----------------------- */

void CheckForMemoryLeaks() 
{
#ifdef	_DEBUG
	// Get Current flag
	int flag = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG) ; 

	// Turn on leak-checking bit
	flag |= (_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF) ; 

	// Set flag to the new value
	_CrtSetDbgFlag(flag) ; 
#endif	//_DEBUG
}

static void Usage()
{
	fprintf(stderr, "usage: 1) hw4 solve [file]\n");
	fprintf(stderr, "usage: 2) hw4 count [-printall] [-max=n] [file]\n");
	fprintf(stderr, "usage: 3) hw4 gen [-info] [rndfile]\n");
	exit(-1);
}

static void ProcessOptions(int argc, char *argv[])
{
	if(argc < 2)
	{
		Usage();
		return;
	}
	if ((strcmp(argv[1], "solve") == 0))
	{
		if (argc >3)
		{
			Usage();
			return;
		}
		FILE *fp = NULL;
		if(argc ==3)
		{
			fp = fopen(argv[2], "r");
			if ( errno != 0 ) 
			{
				fprintf(stderr,"%s",argv[2]);
				perror("\n");
				exit(0);
			}
		}
		else
		{
			fp= stdin;
		}

		My570SudokuSol *mazesol = NULL;
		try
		{
			mazesol = new My570SudokuSol();
		}
		catch (...)
		{
			fprintf(stderr, "could not allocate memory\n");
			exit(1);
		}
		mazesol->Start(fp);
		SAFE_DELETE(mazesol);
		fclose(fp);
		return;
	}

	if ((strcmp(argv[1], "count") == 0))
	{
		if (argc >5)
		{
			Usage();
			return;
		}
		int counter = 2;
		int bPrintAll = FALSE;
		FILE *fp = NULL;
		int NoOfSolutions = 0;
		while(counter < argc)
		{
			if(argv[counter][0] == '-')
			{
				if(strncmp(argv[counter], "-printall", 8) == 0)
				{
					bPrintAll = TRUE;

				}
				else
				{
					if(strncmp(argv[counter], "-max=", 4) == 0)
					{
						char temp[MAXSTRINGLENGTH];
						//strncpy(temp, &(argv[counter][5]), MAXSTRINGLENGTH);
						int i = 5;
						while(argv[counter][i-1] != '\0')
						{
							if(argv[counter][i] >= '0'
								&& argv[counter][i] <= '9')
							{
								temp[i-5] = argv[counter][i];
								i++;
							}
							else
							{
								fprintf(stderr, "n should be a no. \n");
								Usage();
							}
							
						}

						NoOfSolutions = atoi(temp);
						if (NoOfSolutions < 0)
						{
							fprintf(stderr, "n should be > 1\n");
							Usage();
							exit(0);
						}
					}
					else
					{
						Usage();
						exit(1);
					}
				}
			}
			else
			{
				fp = fopen(argv[counter], "r");
				if ( errno != 0 ) 
				{
					fprintf(stderr,"%s",argv[counter]);
					perror("\n");
					exit(0);
				}
			}
			counter++;		
		}

		
		if(fp == NULL)
		{
			fp= stdin;
		}

		My570SudokuSol *mazesol = NULL;
		try
		{
			mazesol = new My570SudokuSol(bPrintAll, NoOfSolutions);
		}
		catch (...)
		{
			fprintf(stderr, "could not allocate memory\n");
			exit(1);
		}
		mazesol->Start(fp);
		int NoOfSol = mazesol->GetNoOfSolutions();
		if(NoOfSol == 1)
		{
			fprintf(stdout, "%d solution found\n",NoOfSol);	
		}
		else
		{
			fprintf(stdout, "%d solutions found\n",NoOfSol);	
		}
		SAFE_DELETE(mazesol);
		fclose(fp);
		return;
	}
	if ((strcmp(argv[1], "gen") == 0))
	{
		if (argc >4)
		{
			Usage();
			return;
		}
		int counter = 2;
		int bInfo = FALSE;
		FILE *fp = NULL;
		while(counter < argc)
		{
			if(argv[counter][0] == '-')
			{
				if(strncmp(argv[counter], "-info", 8) == 0)
				{
					bInfo = TRUE;

				}
				else
				{
					Usage();
					exit(1);
				}
			}
			else
			{
				fp = fopen(argv[counter], "rb");
				if ( errno != 0 ) 
				{
					fprintf(stderr,"%s",argv[counter]);
					perror("\n");
					exit(0);
				}
			}
			counter++;		
		}

		
		if(fp == NULL)
		{
			fp= stdin;
		}

		My570SudokuGen *mazegen = NULL;
		try
		{
			mazegen = new My570SudokuGen(bInfo);
		}
		catch (...)
		{
			fprintf(stderr, "could not allocate memory\n");
			exit(1);
		}
		mazegen->Start(fp);
		
		SAFE_DELETE(mazegen);
		fclose(fp);
		return;
	}

	Usage();
}

static void SetProgramName(char *s)
{
	char *c_ptr=strrchr(s, DIR_SEP);

	if (c_ptr == NULL) {
		strcpy(gszProgName, s);
	} else {
		strcpy(gszProgName, ++c_ptr);
	}
}

/* ----------------------- main() ----------------------- */

int main(int argc, char *argv[])
{
	CheckForMemoryLeaks();
	SetProgramName(*argv);
	ProcessOptions(argc, argv);
	return(0);
}
