// *****************************************************************************
//  myMazeGen   version:  1.0   Ankur Sheel  date: 2010/03/23
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#include "my570SudokuGen.hpp"
#include "my570SudokoSol.hpp"
#include "my570list.hpp"
#include "utility.h"
#include "math.h"
#include "myDebug.h"
#include <stdio.h>
#include <stdlib.h>

My570SudokuGen::My570SudokuGen( const int bInfo, const int iDims )
: m_bInfo(bInfo)
, m_iDims(iDims)
{
	m_iPuzzle = new int*[m_iDims];
	m_iLists = new My570List*[m_iDims];
	for(int i =0;i<m_iDims;i++)
	{
		m_iPuzzle[i] = new int[m_iDims] ;
		m_iLists[i] = new My570List();
	}
	m_sqrtDim = (int)sqrt((float)m_iDims);
}

My570SudokuGen::~My570SudokuGen()
{
	for(int i =0;i<m_iDims;i++)
	{
		SAFE_DELETE_ARRAY(m_iPuzzle[i]);
		SAFE_DELETE(m_iLists[i]);
	}
	SAFE_DELETE_ARRAY(m_iPuzzle);
	SAFE_DELETE_ARRAY(m_iLists);
}

void My570SudokuGen::Start( FILE *fp )
{
	CreatePriorityLists(fp);
	if(m_bInfo)
	{
		fprintf(stdout, "Random shuffle results:\n\n");
		PrintLists();
		fprintf(stdout, "\n");
	}
	if(CreateBoard())
	{
		fprintf(stdout, "Full board generated:\n\n");
		PrintMaze();
	}
	else
	{
		fprintf(stderr, "\nCould Not Create Board\n");
		exit(1);
	}
	My570List* cellList = *(CreateCellLists());
	CreatePuzzle(fp, cellList);
	My570ListElem* curr = cellList->First();
	int len = cellList->Length();
	for(int i=0;i<len;i++)
	{
		My570Cell * cell = (My570Cell*)(curr->Obj());
		SAFE_DELETE(cell);
		cellList->Unlink(curr);
		curr = cellList->First();
	}
	SAFE_DELETE(cellList);
}

int My570SudokuGen::ReadLine( FILE * fp)
{
	char buff[4];

	fread(buff, sizeof(char), 4, fp);

	if(feof(fp))	
	{
		PrintMaze();
		fprintf(stderr, "Reached end of file\n");
		exit(0);
	}

	if (ferror(fp))
	{
		fprintf(stderr, "Error reading file\n");
		exit(0);
	}
	unsigned int X = 0;
	X = X | (0x000000FF & (unsigned int)(buff[0]))<<24;
	X = X | (0x000000FF & (unsigned int)(buff[1]))<<16;
	X = X | (0x000000FF & (unsigned int)(buff[2]))<<8;
	X = X | (0x000000FF & (unsigned int)(buff[3]));

	return X;
}

void My570SudokuGen::PrintLists()
{
	My570ListElem* curr;
	for(int i =0;i<m_iDims;i++)
	{
		curr = m_iLists[i]->First();
		int size = m_iLists[i]->Length();
		for(int j=0; j< size;j++)
		{
			fprintf(stdout, "%d", (int)(curr->Obj())); 
			curr = m_iLists[i]->Next(curr);
		}
		fprintf(stdout, "\n"); 
	}
}

void My570SudokuGen::PrintMaze()
{
	fprintf(stdout, "+---+---+---+\n"); 
	for(int i =0;i<m_iDims;i++)
	{
		fprintf(stdout, "|"); 
		for(int j =0;j<m_iDims;j++)
		{
			if(m_iPuzzle[i][j] <= 0)
			{
				fprintf(stdout, "."); 
			}
			else
			{
				fprintf(stdout, "%d", m_iPuzzle[i][j]); 
			}
			if(((j+1)%3) == 0)
			{
				fprintf(stdout, "|"); 
			}
		}
		fprintf(stdout, "\n"); 
		if(((i+1)%3) == 0)
		{
			fprintf(stdout, "+---+---+---+\n"); 
		}
	}
}

My570List** My570SudokuGen::CreateCellLists()
{
	My570List* pInputList = new My570List();
	for(int i=0;i<m_iDims;i++)
	{
		for(int j=0;j<m_iDims;j++)
		{
			My570Cell *cell  = new My570Cell(m_iPuzzle[i][j],i,j);
			pInputList->Append((void*)(cell));
		}
	}
	return &pInputList;
}

void My570SudokuGen::CreatePriorityLists( FILE * fp)
{
	My570List* pInputList = new My570List();
	int height = 0;
	int width = 0;
	while(height < m_iDims)
	{
		width = 0;
		for(int i=0;i<m_iDims;i++)
		{
			pInputList->Append((void*)(i+1));
		}

		unsigned int X;
		unsigned int L;
		unsigned int R;
		My570ListElem * curr;

		while(!(pInputList->Empty()))
		{
			L = pInputList->Length();
			X = ReadLine(fp);
			R = X%L;
			curr = pInputList->First();
			for(unsigned int i=0;i<R;i++)
			{
				curr=pInputList->Next(curr);
			}
			m_iLists[height]->Append(curr->Obj());
			pInputList->Unlink(curr);
			width++;
		}
		height++;
	}
	SAFE_DELETE(pInputList);
}

int My570SudokuGen::CreateBoard(const int row, const int col)
{
	if(row == m_iDims)
	{
		return TRUE;
	}
	int r = row;
	int c = col;
	int PriorityListCounter =0 ;
	int len = m_iLists[r]->Length();
	int no;
	My570ListElem * curr = m_iLists[r]->First();
	int bConflict = true;
	while(1)
	{
		bConflict = true;
		while(PriorityListCounter < len)
		{
			PriorityListCounter++;
			no = (int)(curr->Obj());
			if(CheckNoForConflict(r, c, no))
			{
				bConflict = false; 
				break;
			}
			curr = m_iLists[r]->Next(curr);
		}
		
		if(bConflict)
		{
			return FALSE;
		}
		//fprintf(stdout, "%d %d %d\n", r,c, no);
		m_iLists[r]->Cover(curr);
		m_iPuzzle[r][c] = no;
		c++;
		if(c >= m_iDims)
		{
			PrintLists();
			PrintMaze();
			c = 0;
			r++;
		}
		if(!CreateBoard(r,c))
		{
			c--;
			if(c < 0)
			{
				r--;
				c = m_iDims-1;
			}
			m_iPuzzle[r][c] = 0;
			My570ListElem* temp = m_iLists[r]->Next(curr);
			int a = (int)(curr->Obj());
			m_iLists[r]->UnCover(curr);			
			curr = temp;
			int b= (int)(curr->Obj());
		}
		else
		{
			SAFE_DELETE(curr);
			return TRUE;
		}
	}
}

int My570SudokuGen::CheckNoForConflict(const int CurrentRow, const int CurrentColumn, const int no)
{
	//check the row
	for(int i=0;i<CurrentColumn;i++)
	{
		if(m_iPuzzle[CurrentRow][i] == no )
		{
			return FALSE;
		}
	}

	//check the column
	for(int i=0;i<CurrentRow;i++)
	{
		if(m_iPuzzle[i][CurrentColumn] == no )
		{
			return FALSE;
		}
	}

	//check the box
	int r = CurrentRow - CurrentRow%3;
	int c = CurrentColumn - CurrentColumn%3;
	int maxC = c+3;
	while(r<=CurrentRow)
	{
		c = CurrentColumn - CurrentColumn%3;
		while(c<maxC)
		{
			if(m_iPuzzle[r][c] == no 
				&&!(r == CurrentRow
					&& c == CurrentColumn))
			{
				return FALSE;
			}
			c++;
		}
		r++;
	}
	return TRUE;
}

void My570SudokuGen::CreatePuzzle( FILE * fp, My570List* CellList)
{
	unsigned int X;
	unsigned int L;
	unsigned int R;
	My570ListElem * curr;
	My570Cell * pCell;
	My570SudokuSol* sol = new My570SudokuSol(FALSE, 0, m_iDims);
	int valUnassigned = 0;
	while(!(CellList->Empty()))
	{
		L = CellList->Length();
		X = ReadLine(fp);
		R = X%L;
		//fprintf(stdout, "R  %d\n", R);
		curr = CellList->First();
		for(unsigned int i=0;i<R;i++)
		{
			curr=CellList->Next(curr);
		}
		pCell = (My570Cell*)(curr->Obj());

		m_iPuzzle[pCell->m_iRow][pCell->m_iCol] = 0;
		sol->Start(m_iPuzzle);
		if(sol->GetNoOfSolutions() > 1)
		{

			if(m_bInfo)
			{
				fprintf(stdout, "\nUnassigning row %d column %d.  %d Solutions found.\n", pCell->m_iRow+1, pCell->m_iCol+1, sol->GetNoOfSolutions());
				fprintf(stdout, "Row %d column %d restored.\n", pCell->m_iRow+1, pCell->m_iCol+1);
			}
			m_iPuzzle[pCell->m_iRow][pCell->m_iCol] = pCell->m_iNo;
			break;
		}
		valUnassigned++;
		if(m_bInfo)
		{
			fprintf(stdout, "\nUnassigning row %d column %d...", pCell->m_iRow+1, pCell->m_iCol+1);
		}

		
		SAFE_DELETE(pCell);
		CellList->Unlink(curr);
		//PrintMaze();
	}
	fprintf(stdout, "\nSolution (after %d values unassigned):\n\n", valUnassigned);
	PrintMaze();
	SAFE_DELETE(sol);
}


My570Cell::My570Cell(const int no, const int row, const int col)
: m_iNo(no)
, m_iRow(row)
, m_iCol(col)
{
}
