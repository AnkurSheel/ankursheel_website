// *****************************************************************************
//  my570MazeSol   version:  1.0   Ankur Sheel  date: 2010/03/24
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#ifndef My570SudokuSol_h__
#define My570SudokuSol_h__
#include "cs570.h"
#include <stdio.h>

class Header;
class Node;
class My570List;

class My570SudokuSol
{
public:
	My570SudokuSol(const int bPrintSolution = TRUE, const int iNoOfSolutions = 0, const int iDims = 9);
	~My570SudokuSol();
	void Start(FILE *fp);
	void Start(int ** puzzleList);
	int GetNoOfSolutions();
private:
	int ReadLine( FILE * fp, char* const buff );
	void InitializePuzzle( FILE * fp );
	void InitializePuzzle( int ** puzzleList );
	void PrintMaze();
	void BuildMatrix();
	void BuildGrid();
	void CoverColumn(Header* c);
	void UncoverColumn(Header* c);
	void SolveSudoku();
	Header* FindMin();
	void UnselectAllRows() ;
	void GetSolution();
	void PrintSolution();
	void Reset();
private:
	int m_iDims;
	int **m_iPuzzle;
	int **m_iSol;
	Header** m_columns;
	Node ** m_rows;
	Header* m_head;
	int m_iTotSolutions;
	My570List* m_RowIndex;
	int m_bPrintSolution;
	int m_NoOfSolutions;;

};
#endif // my570MazeSol_h__
