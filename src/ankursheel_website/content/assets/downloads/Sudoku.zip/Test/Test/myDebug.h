// ***************************************************************
//  myDebug   version:  1.0   Ankur Sheel  date: 2010/02/22
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// ***************************************************************
// 
// ***************************************************************#ifdef _DEBUG
#ifndef myDebug_h__
#define myDebug_h__

#ifdef _DEBUG
#include <stdlib.h>
#include <crtdbg.h>
#define DEBUG_CLIENTBLOCK   new( _NORMAL_BLOCK, __FILE__, __LINE__)
#define new DEBUG_CLIENTBLOCK
#else
#define DEBUG_CLIENTBLOCK
#endif
#endif // myDebug_h__
