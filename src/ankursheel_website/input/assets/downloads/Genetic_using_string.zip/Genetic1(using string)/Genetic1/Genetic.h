#pragma once

#include "Main.h"

struct Genome
{
	string	szgenes ;
	float	ffitness ;
	Genome() ;
	Genome(const string &genes) ;
} ;

class cGenetic
{
protected:
	UINT			m_iTarget,
					m_iRowSize,
					m_iColSize,
					m_iGenomeLength,
					m_iPopSize,
					m_iMaxGenerations ;
	const float		m_iCrossoverRate,
					m_iMutationRate ;
	vector<Genome>	m_Population ;
	BOOL			m_bSolutionFound ;
	Genome			m_Solution ;
	int				m_iFoundinGenNo ;

public:
	cGenetic() ;
	~cGenetic() ;
	UINT GetTarget() ;
	UINT GetPopSize() ;
	float GetCrossOverRate() ;
	float GetMutationRate() ;
	void SetRandSeed() ;
	void CreateRandomPopulation() ;
	void FindSolution() ;
	void CalculateFitness() ;
	vector<int> ParseGenes(Genome genome) ;
	int ConvertBinaryStringtoNo(string szBinary) ;
	int CalculateRowTotal(vector<int> values) ;
	int CalculateColTotal(vector<int> values) ;
	Genome Selection() ;
	void CrossOver(Genome &Father, Genome &Mother) ;
	void Mutate(Genome &gene) ;
	void PrintSolution() ;
};