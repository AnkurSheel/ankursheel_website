#pragma once

#include <iostream>
#include <windows.h>
#include <tchar.h>
#include <vector>
#include <time.h>


#pragma comment(lib,"winmm.lib")

using namespace std ;
using std::vector ;
using std::string ;

const int BINPLACES = 3 ;