#include "Main.h"
#include "Genetic.h"

void main()
{
	cGenetic gene ;
	wcout<< "\nTarget:  " << gene.GetTarget() ;
	wcout<< "\nPop Size:  " << gene.GetPopSize() ;
	wcout<< "\nCrossover Rate:  " << gene.GetCrossOverRate() ;
	wcout<< "\nMutation Rate:  " << gene.GetMutationRate() ;

	gene.SetRandSeed() ;

	gene.CreateRandomPopulation() ;
	gene.FindSolution() ;
	gene.PrintSolution() ;
}