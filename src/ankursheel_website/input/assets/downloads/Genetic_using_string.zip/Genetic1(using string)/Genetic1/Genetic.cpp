#include "genetic.h"

Genome::Genome()
{
	szgenes = "" ;
	ffitness = 0.0f ;
}

Genome::Genome(const string &genes)
{
	szgenes = genes ;
	ffitness = 0.0f ;
}

cGenetic::cGenetic()
:m_iCrossoverRate(0.75f), m_iMutationRate(0.02f) 
{
	m_iTarget = 17 ;
	m_iRowSize = 3 ;
	m_iColSize = 3 ;
	m_iGenomeLength = m_iRowSize * m_iColSize * BINPLACES ;
	m_iPopSize		= 100 ;
	m_iMaxGenerations = 1000 ;
	m_bSolutionFound = false ;
	m_iFoundinGenNo = -1 ;

	srand((UINT)timeGetTime()) ;
}

cGenetic::~cGenetic()
{
}

UINT cGenetic::GetTarget()
{
	return m_iTarget ;
}

UINT cGenetic::GetPopSize()
{
	return m_iPopSize ;
}

float cGenetic::GetCrossOverRate() 
{
	return m_iCrossoverRate ;
}

float cGenetic::GetMutationRate()
{
	return m_iMutationRate ;
}
void cGenetic::SetRandSeed()
{
	srand(time(NULL) );
}
void cGenetic::CreateRandomPopulation()
{
	UINT	bit ;

	while(m_Population.size() < m_iPopSize)
	{
		string genes ;

		for(UINT i=0;i<m_iGenomeLength;i++)
		{
			bit = (rand() % 2) ; 
			if(bit == 1)
			{
				genes.append("1") ;
			}
			else
			{
				genes.append("0") ;
			}
		}
		m_Population.push_back(Genome(genes)) ;
	}
}
void cGenetic::FindSolution()
{
	vector <Genome>		NewPopulation ;
	Genome				Father,
						Mother ;


	for(UINT i=0;i<m_iMaxGenerations;i++)
	{
		CalculateFitness() ;
		if(m_bSolutionFound)
		{
			m_iFoundinGenNo = i ;
			break ;
		}
		
		while(NewPopulation.size() < m_iPopSize)
		{
			Father = Selection() ;
			Mother = Selection() ;
			

			CrossOver(Father, Mother) ;
			//Father = son ; Mother = Daughter after Crossover

			Mutate(Father) ;
			Mutate(Mother) ;

			NewPopulation.push_back(Father) ;
			NewPopulation.push_back(Mother) ;
		}

		m_Population = NewPopulation ;
		NewPopulation.clear() ;
		
	}
}

void cGenetic::CalculateFitness()
{
	
	vector<int>					values ;
	vector<Genome>::iterator	itr_gen ;
	int							rowDiff,
								colDiff,
								totalDiff ;

	for(itr_gen=m_Population.begin();itr_gen!=m_Population.end();itr_gen++)
	{
		values = ParseGenes(*itr_gen) ;

		rowDiff = CalculateRowTotal(values) ;
		colDiff = CalculateColTotal(values) ;
		totalDiff = rowDiff + colDiff ;

		if(totalDiff == 0)
		{
			m_Solution = *itr_gen ;
			m_bSolutionFound = true ;
			break ;
		}
		else
		{
			itr_gen->ffitness = 1.0f/totalDiff ;
		}

	}

}

vector<int> cGenetic::ParseGenes(Genome genome)
{
	vector<int>		values ;
	string			szBinary ;
	int				temp ;

	for(UINT pos=0;pos<m_iGenomeLength;pos +=BINPLACES)
	{
		szBinary = genome.szgenes.substr(pos, BINPLACES) ;
		temp = ConvertBinaryStringtoNo(szBinary) ;
		values.push_back(temp) ;
	}
	return values ;
}

int cGenetic::ConvertBinaryStringtoNo(string szBinary)
{
	int		iValBase10 = 0, 
			iBinVal, 
			iPow2 =1 ;
	char	currentchar ;

	for(int pos=BINPLACES-1;pos>=0;pos--)
	{
		currentchar = szBinary[pos] ;
		iBinVal = currentchar - '0' ;
		iValBase10 +=(iBinVal * iPow2) ;
		iPow2 = iPow2 * 2 ;
	}

	return iValBase10 ;

}

int cGenetic:: CalculateRowTotal(vector<int> values)
{
	int		result,
			total = 0 ;

	for(UINT row=0;row<m_iRowSize;row++)
	{
		result = 0;

		for (UINT box=0;box<m_iColSize;box++)
		{
			result += values[row*m_iRowSize + box];
		}

		//Add the difference between the target and result for this row.
		total += abs(m_iTarget - result);
	}
	return total ;
}

int cGenetic:: CalculateColTotal(vector<int> values)
{
	int		result,
			total = 0 ;

	for(UINT row=0;row<m_iColSize;row++)
	{
		result = 0;

		for (UINT box=0;box<m_iRowSize;box++)
		{
			result += values[row*m_iColSize + box];
		}
		total += abs(m_iTarget - result);
	}
	return total ;
}
Genome cGenetic::Selection()
{
	float	fTotalfitness = 0.0f,
			fball,
			fPie = 0.0f ;

	vector<Genome>::iterator	itr_gen ;

	for(itr_gen = m_Population.begin();itr_gen<m_Population.end();itr_gen++)
	{
		fTotalfitness += itr_gen->ffitness ;
	}
	fball = (rand()/(RAND_MAX+1.0f)) * fTotalfitness ;
	for(itr_gen = m_Population.begin();itr_gen<m_Population.end();itr_gen++)
	{
		fPie += itr_gen->ffitness ;
		if(fball < fPie)
		{
			return *itr_gen ;
		}
	}
}

void cGenetic::CrossOver(Genome &Father, Genome &Mother)
{
	float	fRand ;
	UINT	iRandPos;
	Genome	daughter,
			son ;

	fRand = rand()/(RAND_MAX + 1.0f) ;

	if(fRand<m_iCrossoverRate)
	{
		iRandPos = rand() % m_iGenomeLength ;

		// Son's genes are first part of father's, second part of mother's.
		son.szgenes  = Father.szgenes.substr(0, iRandPos) ;
		son.szgenes.append(Mother.szgenes.substr(iRandPos, string::npos)) ;
		
		daughter.szgenes  = Mother.szgenes.substr(0, iRandPos) ;
		daughter.szgenes.append(Father.szgenes.substr(iRandPos, string::npos)) ;
		

		//son.szgenes     = Father.szgenes.substr(0, iRandPos) + Mother.szgenes.substr(iRandPos, string::npos);

		//daughter.szgenes = Mother.szgenes.substr(0, iRandPos) +	Father.szgenes.substr(iRandPos, string::npos);

		Mother = daughter ;
        Father = son ;
    }
}

void cGenetic::Mutate(Genome &gene)
{
	float	fRand ;
	string::iterator			bit ;

	for(bit = gene.szgenes.begin();bit<gene.szgenes.end();bit++)
	{
		fRand = rand()/(RAND_MAX + 1.0f) ;

		if(fRand<m_iMutationRate)
		{
			if(*bit == '1')
			{
				*bit = '0' ;
			}
			else
			{
				*bit = '1' ;
			}
		}
	}
}

void cGenetic::PrintSolution()
{
	  if (m_bSolutionFound)
    {
        cout << "Solution found in " << m_iFoundinGenNo << " generations.\n\n";
		vector<int> values = ParseGenes(m_Solution);

		for (int val = 0; val < values.size(); ++val)
		{
			cout << values[val] ;
			if (val % m_iColSize == m_iColSize - 1)
			{
				cout << "\n\n" ;
			}
			else
			{
				cout << "\t";
			}
		}
    }
    else
    {
		cout << "No solution found in " << m_iMaxGenerations << " generations.\n\n";
    }
}
