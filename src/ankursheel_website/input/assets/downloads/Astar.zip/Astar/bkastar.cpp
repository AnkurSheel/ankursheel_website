#include "stdafx.h"
#include "AStar.h"

cAstar::cAstar()
{
	m_iOpenListIdNo = 1 ;
	ZeroMemory(&m_iOpenList, sizeof(m_iOpenList)) ;
	ZeroMemory(&m_iParentSquareNo, sizeof(m_iParentSquareNo)) ;
	ZeroMemory(&m_iItemSquareNo, sizeof(m_iItemSquareNo)) ;
	ZeroMemory(&m_fFcost, sizeof(m_fFcost)) ;
	ZeroMemory(&m_fGcost, sizeof(m_fGcost)) ;
	ZeroMemory(&m_fHcost, sizeof(m_fHcost)) ;
	ZeroMemory(&m_bInOpenList, sizeof(m_bInOpenList)) ;
	ZeroMemory(&m_bInClosedList, sizeof(m_bInClosedList)) ;

}

cAstar::~cAstar()
{
}

void cAstar::SetStartTargetPos(const POINT &startpos, const POINT &targetpos)
{
	m_iStartSquare = startpos ;
	m_iTargetSquare = targetpos ;
}

void cAstar::CalculatePath(SquareType **SqType)
{
	//int		m_iNoofOpenListItems = 1 ;//,
	POINT	ParentPos ;
	BOOL	bPathFound ;
	TCHAR str[50] ;

	m_SqType = SqType ;
	m_iNoofOpenListItems = 1 ;
	m_fGcost[m_iStartSquare.x][m_iStartSquare.y] = 0.0f ;
	m_iOpenList[m_iOpenListIdNo] = 1 ;
	m_iItemSquareNo[m_iOpenListIdNo] = m_iStartSquare ;

	while(1)
	{
		if(m_iNoofOpenListItems == 0)
		{
			bPathFound = false ;
			break ;
		}
		else
		{
			//delete the top element from heap
			ParentPos = m_iItemSquareNo[m_iOpenList[1]] ;
			m_bInClosedList[ParentPos.x][ParentPos.y] = true ;
			m_iNoofOpenListItems-- ;
			m_iOpenList[1] = m_iOpenList[m_iNoofOpenListItems + 1] ;
			SqType[ParentPos.x][ParentPos.y] = Closed ;

			//get correct pos for this item
			GetLowestFcostNodeonTop() ;

			//check the 8 adjacent squares and add them to the heap if walkable
			for(int a=ParentPos.x-1;a<=ParentPos.x+1;a++)
			{
				for(int b=ParentPos.y-1;b<=ParentPos.y+1;b++)
				{
					//check if in map boundary
					if(a!=-1 && b!=-1 && a!=NOOFROW && b!=NOOFCOL)
					{
						//check if unwalkable i.e obstacle
						if(SqType[a][b] != Wall /*&& m_Type[a][b] != Start*/)
						{
							// check if already closed
							if(!m_bInClosedList[a][b])
							{
								AddNodetoOpenList(a,b, ParentPos, SqType) ;
							}
						}
					}
				}
			}
		}

		//check if path is found
		if(m_bInOpenList[m_iTargetSquare.x][m_iTargetSquare.y])
		{
			bPathFound = true ;
			break ;
		}
	}

	if(bPathFound)
	{
		GetShortestPath(SqType) ;
	}
	else
	{
		_stprintf_s(str, _countof(str) - 1, TEXT("No Path Found")) ;
		MessageBox(0,str,0,0) ;
	}
	SqType[m_iStartSquare.x][m_iStartSquare.y] = Start ;
	SqType[m_iTargetSquare.x][m_iTargetSquare.y] = Target ;
	ResetValues() ;
}

void cAstar::GetLowestFcostNodeonTop()
{
	int		iItemPosinHeap = 1,
			iChildPosinHeap,
			itemp ;
	
	while(1)
	{
		iChildPosinHeap = iItemPosinHeap ;
		//check if both children exist
		if((2*iChildPosinHeap) +1 <= m_iNoofOpenListItems)
		{
			//check if greater than 1st child

			if(m_fFcost[m_iOpenList[iItemPosinHeap]] >= m_fFcost[m_iOpenList[2*iChildPosinHeap]])
			{
				iItemPosinHeap = 2 * iChildPosinHeap ;
			}
			if(m_fFcost[m_iOpenList[iItemPosinHeap]] >= m_fFcost[m_iOpenList[(2*iChildPosinHeap)+1]])
			{
				iItemPosinHeap = (2 * iChildPosinHeap) + 1 ;
			}
		}
		//check if 1 child exists
		else
		{
			if((2*iChildPosinHeap) <= m_iNoofOpenListItems)
			{
				if(m_fFcost[m_iOpenList[iItemPosinHeap]] >= m_fFcost[m_iOpenList[2*iChildPosinHeap]])
				{
					iItemPosinHeap = 2 * iChildPosinHeap ;
				}
			}
		}
		//if parent is greater than its child swap
		if(iItemPosinHeap != iChildPosinHeap)
		{
			itemp = m_iOpenList[iItemPosinHeap] ;
			m_iOpenList[iItemPosinHeap] = m_iOpenList[iChildPosinHeap] ;
			m_iOpenList[iChildPosinHeap] = itemp ;
		}
		else
		{
			break ;
		}
	}// end of while
}

void cAstar::AddNodetoOpenList(const int XPos, const int YPos, const POINT	&ParentPos,  SquareType **SqType)
{
	float	addGcost,
			newGCost ;

	if(!CheckIfCuttingCorner(XPos, YPos, ParentPos, SqType))
	{
		//check if already on Open List
		if(m_bInOpenList[XPos][YPos])
		{
			//get new Gcost
			if(abs(XPos-ParentPos.x) == 1 && abs(YPos-ParentPos.y) == 1)
			{
				addGcost = DIAGONALPATHCOST ;
			}
			else
			{
				addGcost = STRAIGHTPATHCOST ;
			}
			newGCost = m_fGcost[ParentPos.x][ParentPos.y] + addGcost ;

			//check if new Gcost is < previous Gcost
			if(newGCost <m_fGcost[XPos][YPos])
			{
				ChangeCostPosofItem(newGCost, XPos, YPos, ParentPos) ;
			}
		}
		else
		{
			m_iOpenListIdNo++ ;
			m_iItemSquareNo[m_iOpenListIdNo].x = XPos ;
			m_iItemSquareNo[m_iOpenListIdNo].y = YPos ;
			SqType[XPos][YPos] = Open ;

			//get new Gcost
			if(abs(XPos-ParentPos.x) == 1 && abs(YPos-ParentPos.y) == 1)
			{
				addGcost = DIAGONALPATHCOST ;
			}
			else
			{
				addGcost = STRAIGHTPATHCOST ;
			}
			AddItemtoOpenList(addGcost, XPos, YPos, ParentPos) ;
		}
	}
}

bool cAstar::CheckIfCuttingCorner(const int XPos, const int YPos, const POINT &ParentPos, SquareType **SqType)
{
	if(XPos == ParentPos.x - 1)
	{
		//top left square
		if(YPos == ParentPos.y -1)
		{
			if((SqType[ParentPos.x-1][ParentPos.y] == Wall)
				||(SqType[ParentPos.x][ParentPos.y-1] == Wall))
			{
				return true ;
			}
		}//end if top left square
		else
		{
			if(YPos == ParentPos.y + 1)
			{
				//bottom left square
				if((SqType[ParentPos.x-1][ParentPos.y] == Wall)
					||(SqType[ParentPos.x][ParentPos.y+1] == Wall))
				{
					return true ;
				}
			}
		}//end else top left square
	}//end if check if cutting a corner of an obstacle
	else
	{
		if(XPos == ParentPos.x + 1)
		{
			//top right square
			if(YPos == ParentPos.y -1)
			{
				if((SqType[ParentPos.x+1][ParentPos.y] == Wall)
					||(SqType[ParentPos.x][ParentPos.y-1] == Wall))
				{
					return true ;
				}
			}//end if top right square
			else
			{
				if(YPos == ParentPos.y + 1)
				{
					//bottom left square
					if((SqType[ParentPos.x+1][ParentPos.y] == Wall)
						||(SqType[ParentPos.x][ParentPos.y+1] == Wall))
					{
						return true ;
					}
				}
			}//end if top right square
		}//end if(XPos == ParentPos.x + 1)
	}//end else check if cutting XPos corner of an obstacle
	return false ;
}

void cAstar::ChangeCostPosofItem(const float &newGCost, const int XPos, const int YPos,const POINT &ParentPos)
{
	m_iParentSquareNo[XPos][YPos] = ParentPos ;
	m_fGcost[XPos][YPos] = newGCost ;

	//change FCost and position in heap for this node
	for(int x=1;x<=m_iNoofOpenListItems;x++)
	{
		//check if item found
		if(m_iItemSquareNo[m_iOpenList[x]].x == XPos 
			&& m_iItemSquareNo[m_iOpenList[x]].y == YPos)
		{
			//change f Cost
			m_fFcost[x] = m_fGcost[XPos][XPos] + m_fHcost[m_iOpenList[x]] ;

			//reorder heap
			ReorderHeap(x) ;
			break ;
		}//end if check if item found
	}
}
void cAstar::AddItemtoOpenList(const float &addGcost, const int XPos, const int YPos,const POINT &ParentPos) 
{
	int		m ;

	m = m_iNoofOpenListItems + 1 ;
	m_iOpenList[m] = m_iOpenListIdNo ;

	m_fGcost[XPos][YPos] = m_fGcost[ParentPos.x][ParentPos.y] + addGcost ;
	m_fHcost[m_iOpenList[m]]= 10*(abs(XPos - m_iTargetSquare.x) + abs(YPos- m_iTargetSquare.y)) ;
	m_fFcost[m_iOpenList[m]] = m_fGcost[XPos][YPos] + m_fHcost[m_iOpenList[m]] ;
	m_iParentSquareNo[XPos][YPos] = ParentPos ;

	//reorder heap
	ReorderHeap(m) ;
	
	m_iNoofOpenListItems++ ;
	m_bInOpenList[XPos][YPos] = true ;
}
void cAstar::ReorderHeap(const int iItemPos)
{
	int		m = iItemPos,
			temp ;

	while(m!=1)
	{
		if(m_fFcost[m_iOpenList[m]] < m_fFcost[m_iOpenList[m/2]])
		{
			temp = m_iOpenList[m] ;
			m_iOpenList[m] = m_iOpenList[m/2] ;
			m_iOpenList[m/2] = temp ;
			m = m/2 ;
		}//endif
		else
		{
			break ;
		}
	}//end while
}

void cAstar::GetShortestPath(SquareType **SqType)
{
		TCHAR str[50] ;
		POINT	temp = m_iTargetSquare ;
		int		PathLength = 2,
				pos ;
		POINT	*ShortestPath ;
		
		//get the Length of the path 
		while(temp.x != m_iStartSquare.x || temp.y != m_iStartSquare.y)
		{
			temp = m_iParentSquareNo[temp.x][temp.y] ;
			PathLength++ ;
		}
		ShortestPath = new POINT[PathLength] ;
		ShortestPath[0]  = m_iStartSquare ;

		temp = m_iTargetSquare ;
		pos = PathLength-1 ;
		//get the path ;
		while(temp.x != m_iStartSquare.x || temp.y != m_iStartSquare.y)
		{
			ShortestPath[pos] = temp ;
			SqType[temp.x][temp.y] = Path ;
			temp = m_iParentSquareNo[temp.x][temp.y] ;
			pos-- ;
		}

		_stprintf_s(str, _countof(str) - 1, TEXT("Length %f"), m_fGcost[m_iTargetSquare.x][m_iTargetSquare.y]) ;
		MessageBox(0,str,0,0) ;

}

void cAstar::ResetValues()
{

	m_iOpenListIdNo = 1 ;
	ZeroMemory(&m_iOpenList, sizeof(m_iOpenList)) ;
	ZeroMemory(&m_iParentSquareNo, sizeof(m_iParentSquareNo)) ;
	ZeroMemory(&m_iItemSquareNo, sizeof(m_iItemSquareNo)) ;
	ZeroMemory(&m_fFcost, sizeof(m_fFcost)) ;
	ZeroMemory(&m_fGcost, sizeof(m_fGcost)) ;
	ZeroMemory(&m_fHcost, sizeof(m_fHcost)) ;
	ZeroMemory(&m_bInOpenList, sizeof(m_bInOpenList)) ;
	ZeroMemory(&m_bInClosedList, sizeof(m_bInClosedList)) ;
}