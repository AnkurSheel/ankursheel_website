#pragma once

class cMyWindowMain
{
protected:
	HWND		hwnd ;
	WNDPROC		wndProc ;
	int			m_ClientWidth ;
	int			m_ClientHeight ;
	int			m_Wintop ;
	int			m_Winleft ;

public:
	cMyWindowMain(const WNDPROC WndProc) ;
	~cMyWindowMain() ;
	void MyRegisterWin(const HINSTANCE hInstance) ;
	HWND InitInstance(const HINSTANCE hInstance, const int nCmdShow) ;
	void MoveWin() ;
	void GetWinRect() ;
};








