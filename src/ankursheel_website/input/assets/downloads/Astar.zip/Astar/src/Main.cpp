#include "stdafx.h"
#include "Main.h"

cMyWindowMain *pmyWindowObj = NULL ; 
cMyDxClass *pmyDxObject = NULL ; 

int WINAPI WinMain(const HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	int		Msgparam ;
	HWND	hwnd ;

	CheckForMemoryLeaks() ;
	pmyWindowObj = new cMyWindowMain(WndProc) ;
	
	//Step 1: Registering the Window Class
	
	pmyWindowObj->MyRegisterWin(hInstance) ;

	// Step 2: Creating the Window
	hwnd = pmyWindowObj->InitInstance(hInstance,nCmdShow) ;
	if(hwnd == NULL)
	{
		PostQuitMessage(0) ;
	}

	// Step 3: The Message Loop
	Msgparam = MessageLoop() ; 

	Cleanup() ;
	
	return(Msgparam) ;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static BOOL		bFullScreen = WINDOW ;
	static BOOL		bLtButtonPressed = false ;
	HINSTANCE		hInstance ;
	PAINTSTRUCT		ps ;
	HDC				hdc ;
	

	hInstance = GetModuleHandle(NULL) ;


	switch(msg)
	{
	case WM_CREATE:
		pmyDxObject = new cMyDxClass(hwnd) ;
		pmyDxObject->Init() ;
		return 0 ;

	case WM_PAINT:
		hdc = BeginPaint (hwnd, &ps) ;
		EndPaint (hwnd, &ps) ;
		return 0 ;

	case WM_SIZE:
	case WM_MOVE:
		pmyWindowObj->GetWinRect() ;
		pmyDxObject->ResetDevice() ;
		return 0 ;
		
	case WM_KEYDOWN:

		switch(wParam)
		{
		case VK_ESCAPE:
			DestroyWindow(hwnd) ;
			break ;

		case VK_F1:
			bFullScreen = !bFullScreen ;
			pmyDxObject->SetParameters(bFullScreen) ;
			if(!bFullScreen)
			{
				pmyWindowObj->MoveWin() ;

			}
			UpdateWindow(hwnd) ;
			pmyDxObject->ResetDevice() ;
			break ;
		}

		//UpdateWindow(hwnd) ;

		return 0 ;

	case WM_LBUTTONDOWN:
		if(!bLtButtonPressed)
		{
			bLtButtonPressed = true ;
			pmyDxObject->ChangeGrid(MAKEPOINTS(lParam)) ;
		}
		break ;

	case WM_LBUTTONUP:
		bLtButtonPressed = false ;
		break ;

		case WM_CLOSE:
		DestroyWindow(hwnd) ;
		return 0 ;

	case WM_DESTROY:
		ReleaseCapture() ;
		PostQuitMessage(0) ;
		return 0 ;

	default:
		return DefWindowProc(hwnd, msg, wParam, lParam) ;
	}
}

int MessageLoop()
{
	MSG Msg ;
	HRESULT hr ;

	static float prevLasttime = (float)timeGetTime() ;

	PeekMessage(&Msg, NULL, 0, 0, PM_NOREMOVE) ;
	// run till completed
	while (Msg.message!=WM_QUIT)
	{
		float	Currtime, timeDelta ;

		Currtime  = (float)timeGetTime() ;
		timeDelta = (Currtime - prevLasttime) * 0.001f ;
		prevLasttime = Currtime ; 
		pmyDxObject->setTimeDelta(timeDelta) ;

		// is there a message to process?
		if (PeekMessage(&Msg, NULL, 0, 0, PM_REMOVE))
		{
			// dispatch the message
			TranslateMessage(&Msg) ;
			DispatchMessage(&Msg) ;
		}
		else
		{
			//No message to process?
			// Then do your game stuff here
			hr = pmyDxObject->IsAvailable() ;
			if(SUCCEEDED(hr))
			{
 				pmyDxObject->Render() ;
			}
			if(hr == D3DERR_DEVICELOST || hr == D3DERR_DEVICENOTRESET)
			{
				pmyDxObject->HandleLostDevice(hr) ;
			}
			else 
			{
				if(FAILED(hr))
				{ 
					PostQuitMessage(0) ;
				}
			}
		}
	}
	return Msg.wParam ;
}

void CheckForMemoryLeaks() 
{
#ifdef	_DEBUG
	// Get Current flag
	int flag = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG) ; 
	// Turn on leak-checking bit
	flag |= (_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF) ; 
	// Set flag to the new value
	_CrtSetDbgFlag(flag) ; 

#endif	_DEBUG
}

void Cleanup() 
{
	SAFE_DELETE(pmyWindowObj) ;
	SAFE_DELETE(pmyDxObject) ;
}
