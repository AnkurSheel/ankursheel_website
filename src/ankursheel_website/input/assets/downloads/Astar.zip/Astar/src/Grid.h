#pragma once

#include "Common\VertexStruct.h" 



class cGrid
{
protected:
	IDirect3DTexture9		*m_GridTex ;
	IDirect3DTexture9		*m_WallTex ;
	Vertex					m_gridvertex[4] ;
	WORD					m_gridIndices[6] ;

	int						m_sqheight,
							m_sqwidth ;

	SquareType				**m_Type ;
	POINT					m_StartPos,
							m_targetPos ;

public:
	cGrid() ;
	~cGrid() ;
	void InitAfterReset(IDirect3DDevice9 *pd3dDevice, int width, int height) ;
	void CreateGrid(IDirect3DDevice9 *pd3dDevice, int width, int height) ;
	void DrawGrid(IDirect3DDevice9 *pd3dDevice) ;
	void ToggleSquare(const int XCoord, const int YCoord) ;
	void FreeVolResources() ;
	void SetStartTargetPos(const POINT &startpos, const POINT &targetpos) ;
	SquareType **GetSquareTypeList() ;

};