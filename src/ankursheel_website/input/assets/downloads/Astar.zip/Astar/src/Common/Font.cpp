#include "stdafx.h"
#include "Font.h"

cMyFont::cMyFont()
{
}
cMyFont::~cMyFont()
{
	SAFE_RELEASE(m_Font) ;
}
void cMyFont::InitFont(IDirect3DDevice9 *pd3dDevice, const int iHeight, const UINT iWidth, const UINT iWeight, 
					   const BOOL bItalic, const BYTE charset, LPCTSTR szFaceName)

{
	D3DXFONT_DESCW		fonttype ;

	ZeroMemory(&fonttype, sizeof(D3DXFONT_DESCW)) ;
	fonttype.Height		= iHeight ;
	fonttype.Width		= iWidth ;
	fonttype.Weight		= iWeight ;
	fonttype.Italic		= bItalic ;
	fonttype.CharSet	= charset ;
	_tcscpy_s(fonttype.FaceName, LF_FACESIZE, szFaceName) ;

	D3DXCreateFontIndirect(pd3dDevice, &fonttype, &m_Font) ;
}
void cMyFont::DisplayText(IDirect3DDevice9 *pd3dDevice, LPCTSTR szString, const LPRECT pRect, 
						  DWORD *pformat, const D3DCOLOR Col)
{
	m_Font->DrawText(NULL, szString, -1, pRect, *pformat, Col) ;
}