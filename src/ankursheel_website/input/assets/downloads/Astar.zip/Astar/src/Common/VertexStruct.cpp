#include "stdafx.h"
#include "VertexStruct.h"

Vertex::Vertex()
{
	position.x = 0.0f ;
	position.y = 0.0f ;
	position.z = 0.0f ;
//	colour = WHITE ;
	tex.x = 0 ;
	tex.y = 0 ;


} 
Vertex::Vertex(const D3DXVECTOR3 *pos)
{
	position = *pos ;
//	colour = WHITE ;
	tex.x = 0 ;
	tex.y = 0 ;
}

Vertex::Vertex(const D3DXVECTOR3 *pos, const D3DCOLOR col)
{
	position = *pos ;
	colour = col ;
	tex.x = 0 ;
	tex.y = 0 ;
}
Vertex::Vertex(const D3DXVECTOR3 *pos, const D3DCOLOR col, const D3DXVECTOR2 *tex0)
{
	position = *pos ;
	rhw = 1.0f ;
	colour = col ;
	tex = *tex0 ;
}

VertexMultiTex::VertexMultiTex()
{
	position.x = 0.0f ;
	position.y = 0.0f ;
	position.z = 0.0f ;
	colour = WHITE ;
	u = 0 ;
	v = 0 ;
	u1 = 0 ;
	v1 = 0 ;


} 

VertexMultiTex::VertexMultiTex(const float a, const float b, const float c, const D3DCOLOR col, const float d, const float e, const float f, const float g)
{
	position.x = a ;
	position.y = b ;
	position.z = c ;
	colour = col ;
	u = d ;
	v = e ;
	u1 = f ;
	v1 = g ;
}


VertexLight::VertexLight()
{
}

VertexLight::VertexLight(const float a, const float b, const float c)
{
	position.x = a ;
	position.y = b ;
	position.z = c ;
	u = 0.0f ;
	v = 0.0f ;
}
VertexLight::VertexLight(const float a, const float b, const float c, const float d, const float e)
{
	position.x = a ;
	position.y = b ;
	position.z = c ;
	u = d ;
	v = e ;
}


MeshVertex::MeshVertex()
{
}


MeshVertex::MeshVertex(const float x, const float y, const float z, const float nx, const float ny, const float nz, const float u, const float v)
{
	pos.x = x ;			pos.y = y ;			pos.z = z ;
	normal.x = nx ;		normal.y = ny ;		normal.z = nz ;
	tex0.x = u ;		tex0.y = v ;
}


VertexNormDiffuse::VertexNormDiffuse()
{
}
VertexNormDiffuse::VertexNormDiffuse(const D3DXVECTOR3 *pos, const D3DXCOLOR col, const D3DXVECTOR3 *norm, const D3DXVECTOR2 *tex)
{
	position = *pos ;
	colour = col ;
	normal = *norm ;
	tex0 = *tex ;
}


VertexNormSpec::VertexNormSpec()
{
	position.x = 0.0f ;
	position.y = 0.0f ;
	position.z = 0.0f ;
	normal.x = 0.0f ;
	normal.y = 0.0f ;
	normal.z = 0.0f ;

	Diffcolour = WHITE ;
	Speccolour = WHITE ;

} 

VertexNormSpec::VertexNormSpec(const D3DXVECTOR3 *pos, const D3DXCOLOR Dcol, const D3DCOLOR Scol, const D3DXVECTOR3 *norm, const D3DXVECTOR2 *tex)
{
	position = *pos ;
	normal = *norm ;
	tex0 = *tex ;
	Diffcolour = Dcol ;
	Speccolour = Scol ;
}
