#include "Common\myWinMainClass.h"
#include "myDxClass.h"

#define new DEBUG_CLIENTBLOCK
#define DEBUG_CLIENTBLOCK new( _CLIENT_BLOCK, __FILE__, __LINE__)


void CheckForMemoryLeaks() ;
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) ;
int MessageLoop() ;
void Cleanup() ;
