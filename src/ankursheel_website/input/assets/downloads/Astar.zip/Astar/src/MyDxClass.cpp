#include "stdafx.h"
#include "myDxClass.h"

cMyDxClass::cMyDxClass(const HWND hWnd)
{
	m_bFirstTime = true ;
	hwnd = hWnd ;
	D3DXMatrixIdentity(&m_ProjectionMatrix) ;
	D3DXMatrixIdentity(&m_ViewMatrix) ;
	m_fTimeDelta = 0.0f ;
	m_prevLasttime  = (float)timeGetTime() ;

	//fps related 
	m_FpsFormat = DT_TOP | DT_LEFT ;
	m_FpsRect.top = 0 ;
	m_FpsRect.bottom = 25 ;
	m_FpsRect.left = 0 ;
	m_FpsRect.right = 250 ;

	//m_TimesNewRomanFont = new cMyFont ;


	m_grid = new cGrid ;
	m_Astar = new cAstar ;
}

cMyDxClass::~cMyDxClass()
{
	SAFE_DELETE(m_TimesNewRomanFont) ;
	SAFE_DELETE(m_grid) ;
	SAFE_DELETE(m_Astar) ;
}

void cMyDxClass::InitVolatileResources()
{
	//m_grid = new cGrid ;
	m_TimesNewRomanFont = new cMyFont ;

	SetupViewMatrix() ;
	SetupProjectionMatrix() ;
	//m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false) ;

	m_grid->InitAfterReset(m_pd3dDevice, m_Width, m_Height) ;
	Setup() ;
}


void cMyDxClass::FreeVolatileResources()
{
	SAFE_DELETE(m_TimesNewRomanFont) ;
	m_grid->FreeVolResources() ;
}

void cMyDxClass::SetupViewMatrix()
{
	D3DXVECTOR3 eyeposition(0.0f, 00.0f, -100.0f) ;
	D3DXVECTOR3 lookPosition(0.0f, 0.0f, 1.0f) ;
	D3DXVECTOR3 up(0.0f, 1.0f, 0.0f) ;

	D3DXMatrixLookAtLH(&m_ViewMatrix, &eyeposition, &lookPosition, &up) ;
	m_pd3dDevice->SetTransform(D3DTS_VIEW, &m_ViewMatrix) ;
}

void cMyDxClass::SetupProjectionMatrix()
{
	RECT	clientRect ;

	GetClientRect(hwnd, &clientRect) ;
	
	m_Width = clientRect.right - clientRect.left ;
	m_Height = clientRect.bottom - clientRect.top ;

	D3DXMatrixPerspectiveFovLH(
		&m_ProjectionMatrix,
		DegtoRad(45), 
		(float) (m_Width) / (float)(m_Height),
		1.0f,
		1000.0f) ;
	m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &m_ProjectionMatrix) ;
}
void cMyDxClass::Setup()
{
	D3DXMATRIX		m ;
	POINT			StartSq = {5,5}, //row,col
					TargetSq = {20,30} ;

	D3DXMatrixIdentity(&m) ;
	m_pd3dDevice->SetTransform(D3DTS_WORLD, &m) ;
	m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false) ;

	m_grid->CreateGrid(m_pd3dDevice, m_Width, m_Height) ;
	m_grid->SetStartTargetPos(StartSq, TargetSq) ;
	m_Astar->SetStartTargetPos(StartSq, TargetSq) ;
	
	//if(!m_inputMouse.InitDirectInput())
	//{
	//	PostQuitMessage(0) ;
	//}
	//if(!m_inputMouse.InitMouse(hwnd, m_Width, m_Height))
	//{
	//	PostQuitMessage(0) ;
	//}
	//if(!m_inputMouse.SetMouseProperty())
	//{
	//	PostQuitMessage(0) ;
	//}
	//if(!m_inputMouse.AcquireMouse())
	//{
	//	PostQuitMessage(0) ;
	//}

	m_TimesNewRomanFont->InitFont(m_pd3dDevice, 25, 8, 500, false, DEFAULT_CHARSET, _T("Times New Roman")) ;
}

void cMyDxClass::Render()
{
	float	Currtime ;

	Currtime  = (float)timeGetTime() ;
	m_fTimeDelta = (Currtime - m_prevLasttime) * 0.001f ;
	m_prevLasttime = Currtime ; 

	//CalculateFPS() ;

//	m_inputMouse.PollMouse() ;

	if(::GetAsyncKeyState(VK_SPACE) )
	{
		m_Astar->CalculatePath(m_grid->GetSquareTypeList()) ;
	}
	if(SUCCEEDED(m_pd3dDevice->BeginScene()))
	{
		m_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,m_BkColor, 1.0f, 0) ;

		m_grid->DrawGrid(m_pd3dDevice) ;

		//PrintText() ;

		m_pd3dDevice->EndScene() ;
	}
	// Present the back buffer contents to the display
	m_pd3dDevice->Present(NULL, NULL, NULL, NULL) ;
}

void cMyDxClass::setTimeDelta(const float timedelta)
{
	m_fTimeDelta = timedelta ;
}

void cMyDxClass::setFirstTime(const BOOL firstTime)
{
	m_bFirstTime = firstTime ;
}
void cMyDxClass::PrintText()
{
	m_TimesNewRomanFont->DisplayText(m_pd3dDevice, m_FPS, &m_FpsRect, &m_FpsFormat, WHITE) ;
}

void cMyDxClass::CalculateFPS()
{
	double	fFPS ;
	float	Currtime ;

	fFPS = (1.0 / (m_fTimeDelta + .001)) ;
	
	while(fFPS > 400)
	{
		Currtime  = (float)timeGetTime() ;
		m_fTimeDelta = (Currtime - m_prevLasttime) * 0.001f ;
		fFPS = (1.0 / (m_fTimeDelta + .001)) ;
	}	
	_stprintf_s(m_FPS, _countof(m_FPS) - 1, TEXT("FPS : %.3f"), fFPS) ;
	m_FPS[_countof(m_FPS) - 1] = TEXT('\0') ;

}
void cMyDxClass::ChangeGrid(const POINTS coord)
{
	m_grid->ToggleSquare(coord.x, coord.y) ;
}
