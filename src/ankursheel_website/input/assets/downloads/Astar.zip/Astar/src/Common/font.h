#pragma once

class cMyFont
{
protected:
	ID3DXFont	*m_Font ;
public:
	cMyFont() ;
	~cMyFont() ;
	void InitFont(IDirect3DDevice9 *pd3dDevice, const int iHeight, const UINT iWidth, const UINT iWeight, const BOOL bItalic, const BYTE charset, LPCTSTR szFaceName) ;
	void DisplayText(IDirect3DDevice9 *pd3dDevice, LPCTSTR szString, const LPRECT pRect, DWORD *pformat, D3DCOLOR Col) ;
} ;



