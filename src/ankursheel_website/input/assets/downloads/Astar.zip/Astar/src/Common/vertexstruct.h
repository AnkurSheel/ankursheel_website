#pragma once

struct Vertex
{
	D3DXVECTOR3	position ;
	float		rhw ;
	DWORD colour ;        // The vertex colour.
	D3DXVECTOR2 tex ;		//texture coordinates
	static const DWORD FVF = D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1 ;
	//static const DWORD FVF = D3DFVF_XYZRHW|D3DFVF_TEX1 ;

	Vertex() ;
	Vertex(const D3DXVECTOR3 *pos) ;
	Vertex(const D3DXVECTOR3 *pos, const D3DCOLOR col) ;
	Vertex(const D3DXVECTOR3 *pos, const D3DCOLOR col, const D3DXVECTOR2 *tex0) ;
} ;

struct VertexMultiTex
{
	D3DXVECTOR3	position ;
	DWORD colour ;        // The vertex colour.
	float u, v ;		//texture coordinates
	float u1,v1 ;			// tex1 coordinates
	static const DWORD FVF= D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1|D3DFVF_TEX2 ;

	VertexMultiTex() ;
	VertexMultiTex(const float a, const float b, const float c, const D3DCOLOR col, const float d, const float e, const float f, const float g) ;
} ;

struct VertexLight
{
	D3DXVECTOR3	position ;
	float u, v ;		//texture coordinates

	static const DWORD FVF=D3DFVF_XYZ|D3DFVF_TEX1 ;

	VertexLight() ;
	VertexLight(const float a, const float b, const float c) ;
	VertexLight(const float a, const float b, const float c, const float d, const float e) ;
} ;

struct MeshVertex
{
	D3DXVECTOR3		pos ;
	D3DXVECTOR3		normal ;
	D3DXVECTOR2		tex0 ;

	static const DWORD MESHVERTEX_FVF = D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1 ;

	MeshVertex() ;
	MeshVertex(const float x, const float y, const float z, const float nx, const float ny, const float nz, const float u, const float v) ;
} ;

struct VertexNormDiffuse
{
	D3DXVECTOR3	position ;
	D3DXVECTOR3	normal ;
	DWORD colour ;        // The vertex colour.
	D3DXVECTOR2		tex0 ;
	static const DWORD FVF = D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE| D3DFVF_TEX1 ;

	VertexNormDiffuse() ;
	VertexNormDiffuse(const D3DXVECTOR3 *pos, const D3DXCOLOR col, const D3DXVECTOR3 *norm, const D3DXVECTOR2 *tex) ;
} ;

struct VertexNormSpec
{
	D3DXVECTOR3		position ;
	D3DXVECTOR3		normal ;
	DWORD			Diffcolour ;        // The vertex colour.
	DWORD			Speccolour ;        // The vertex colour.
	D3DXVECTOR2		tex0 ;
	static const DWORD FVF = D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_SPECULAR|D3DFVF_TEX1 ;

	VertexNormSpec() ;
	VertexNormSpec(const D3DXVECTOR3 *pos, const D3DXCOLOR Dcol, const D3DCOLOR Scol, const D3DXVECTOR3 *norm, const D3DXVECTOR2 *tex) ;
} ;
