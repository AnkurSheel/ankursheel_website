#pragma once

class cInput
{
protected:
	LPDIRECTINPUT8			m_pDIObject;           //DirectInput main object
	LPDIRECTINPUTDEVICE8	m_pDIMouseDevice ;

	int						m_AbsMouseX,
							m_AbsMouseY,
							m_RelMouseX,
							m_RelMouseY ;

public:
	cInput();          //constructor
	~cInput();         //destructor
	bool InitDirectInput(); //inits DirectInput
	bool InitMouse(HWND hwnd, const int screenWidth, const int screenHeight) ;
	bool SetMouseProperty() ;
	bool AcquireMouse() ;
	bool UnacquireMouse() ;
	void PollMouse() ;
};