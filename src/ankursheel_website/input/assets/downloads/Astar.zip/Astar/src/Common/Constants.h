#define WINDOW false
#define FULLSCREEN true



const D3DXCOLOR WHITE(D3DCOLOR_ARGB(255, 255, 255, 255)) ;
const D3DXCOLOR BLACK(D3DCOLOR_ARGB(255, 0, 0, 0)) ;
const D3DXCOLOR RED(D3DCOLOR_ARGB(255, 255, 0, 0)) ;
const D3DXCOLOR BLUE(D3DCOLOR_ARGB(255, 0, 0, 255)) ;
const D3DXCOLOR GREEN(D3DCOLOR_ARGB(255, 0, 255, 0)) ;
const D3DXCOLOR GRAY(D3DCOLOR_ARGB(255, 190, 190, 190)) ;
const D3DXCOLOR TURQUOISE(D3DCOLOR_ARGB(255, 64, 224, 208)) ;
const D3DXCOLOR YELLOW(D3DCOLOR_ARGB(255, 255, 255, 0)) ;
const D3DXCOLOR TAN(D3DCOLOR_ARGB(255,210, 180, 140)) ;
const D3DXCOLOR ORANGE(D3DCOLOR_ARGB(255,255, 165, 0)) ;
const D3DXCOLOR VIOLET(D3DCOLOR_ARGB(255,238, 130, 238)) ;

#define DegtoRad(x)(x* D3DX_PI/180)

const float MOVECAMERAUNITS  = 2.0f ;
const float ROTATEANGLE DegtoRad(10) ;


const int NOOFROW = 30 ;
const int NOOFCOL  = 40 ;
const int NOOFSQUARES = NOOFROW * NOOFCOL ;

const int DIAGONALPATHCOST = 14 ;
const int STRAIGHTPATHCOST = 10 ;

enum SquareType {Plain, Wall, Open, Closed, Start, Target, Path} ;

#define SAFE_DELETE(p){ if(p) { delete (p) ; (p)=NULL ; } }

#define SAFE_RELEASE(p) {if(p) 	{ (p)->Release() ; (p)=NULL ; } }


