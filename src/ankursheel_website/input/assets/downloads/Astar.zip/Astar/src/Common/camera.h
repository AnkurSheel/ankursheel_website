#pragma once 

class cCamera
{
public:
	enum CameraType { LANDOBJECT, AIRCRAFT } ;
protected:
	CameraType		m_cameraType ;
	D3DXVECTOR3		m_right ;
	D3DXVECTOR3		m_up ;
	D3DXVECTOR3		m_look ;
	D3DXVECTOR3		m_pos ;
	D3DXQUATERNION	m_quaternion ;
public:
	cCamera() ;
	cCamera(const CameraType cameraType) ; 
	~cCamera() ;
	void Pitch(const float angle) ;
	void Yaw(const float angle) ;
	void Roll(const float angle) ;
	void Move(const float units) ;
	void Strafe(const float units) ;
	void Fly(const float units) ;
	void getViewMatrix(D3DXMATRIX* V) ;
	void setCameraType(const CameraType cameraType) ;
	D3DXVECTOR3 getPosition() ;
	void setPosition(D3DXVECTOR3 *pos) ;
	void UpdateVector() ;
};
