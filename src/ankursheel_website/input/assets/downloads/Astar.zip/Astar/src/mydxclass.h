#include "Common\myDxMainClass.h"
#include "Common\Font.h"
#include "Grid.h"
#include "Astar.h"
//#include "input.h"

class cMyDxClass : public cMyDirectxMain
{
protected:
	float			m_fTimeDelta ;
	float			m_prevLasttime ;
	BOOL			m_bFirstTime ;
	
	POINTS			m_prevMousePos ;		
	D3DXMATRIX		m_ViewMatrix ;
	D3DXMATRIX		m_ProjectionMatrix ;
	
	cMyFont			*m_TimesNewRomanFont ;

	// FPS related
	TCHAR			m_FPS[50] ;
	RECT			m_FpsRect ;
	DWORD			m_FpsFormat ; 
	
	int				m_Width,
					m_Height ;

	cGrid			*m_grid ;
	//cInput			m_inputMouse ;

	cAstar			*m_Astar ;

public:
	cMyDxClass(const HWND hWnd) ;
	~cMyDxClass() ;
	void Render() ;
	void InitVolatileResources() ;
	void FreeVolatileResources() ;
	void Setup() ;
	void SetupViewMatrix() ;
	void SetupProjectionMatrix() ;
	void setTimeDelta(const float timedelta) ;
	void setFirstTime(const BOOL firstTime) ;
	void PrintText() ;
	void CalculateFPS() ;
	void ChangeGrid(const POINTS coord) ;
} ;

