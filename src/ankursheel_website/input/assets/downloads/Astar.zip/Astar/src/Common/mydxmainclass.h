#pragma once

class cMyDirectxMain
{
protected:
	IDirect3D9				*m_pD3D ;
	IDirect3DDevice9		*m_pd3dDevice ;
	D3DCAPS9				m_Caps ;
	D3DCOLOR				m_BkColor ;
	HWND					hwnd ;
	D3DPRESENT_PARAMETERS	m_d3dpp ;
	int						m_FullScreenWidth ;
	int						m_FullScreenHeight ;

public:
	cMyDirectxMain() ;
	~cMyDirectxMain() ;
	void DirectxInit() ;
	void CreateDirectxDevice() ;
	virtual void Render() {};
	void Release() ;
	BOOL IsAvailable() ;
	void HandleLostDevice(HRESULT hr) ;
	void SetParameters(const BOOL bFullScreen) ;
	HRESULT ResetDevice() ;
	virtual void InitVolatileResources() {} ;
	virtual void Setup() {} ;
	void Init() ;
	virtual void FreeVolatileResources() {};
};
