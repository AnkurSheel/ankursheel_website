#include "stdafx.h"
#include "myWinMainClass.h"

cMyWindowMain::cMyWindowMain(const WNDPROC WndProc)
{
	hwnd = NULL ;
	wndProc = WndProc ;
	m_ClientHeight = 0 ;
	m_ClientWidth = 0 ;
}

cMyWindowMain::~cMyWindowMain()
{
}

void cMyWindowMain::MyRegisterWin(const HINSTANCE hInstance)
{
	WNDCLASSEX		wc ;

	wc.cbSize = sizeof(WNDCLASSEX) ;
	wc.style = 0 ;
	wc.lpfnWndProc = wndProc ;
	wc.cbClsExtra = 0 ;
	wc.cbWndExtra = 0 ;
	wc.hInstance = hInstance ;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION) ;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW) ;
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1) ;
	wc.lpszMenuName = NULL ;
	wc.lpszClassName = _T("Window") ;
	wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION) ;
	if(!RegisterClassEx(&wc))
	{
		MessageBox(NULL, _T("Window Registration Failed!"), _T("Error!"),MB_ICONEXCLAMATION | MB_OK) ;
		exit(0) ;
	}
}

HWND cMyWindowMain::InitInstance(const HINSTANCE hInstance, const int nCmdShow)
{
	hwnd = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		_T("Window"),
		_T("Direct"),
		WS_OVERLAPPEDWINDOW ,
		0, 0, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, hInstance, NULL) ;

	if(hwnd == NULL)
	{
		MessageBox(NULL, _T("Window Creation Failed!"), _T("Error!"),MB_ICONEXCLAMATION | MB_OK) ;
		return NULL ;
	}
	GetWinRect() ;
	ShowWindow(hwnd, nCmdShow) ;
	UpdateWindow(hwnd) ;

	return hwnd ;
}

void cMyWindowMain::MoveWin()
{
	//if(m_Wintop == 0)
	//{
	//	m_Wintop = 30 ;
	//	m_Winleft = 30 ;
	//}
	MoveWindow(hwnd,m_Winleft,m_Wintop,m_ClientWidth,m_ClientHeight,true) ;
}

void cMyWindowMain::GetWinRect()
{
	RECT	clientRect, windowRect ;

	GetClientRect(hwnd,&clientRect) ;
	GetWindowRect(hwnd,&windowRect) ;
	m_ClientWidth = (clientRect.right - clientRect.left) ;
	m_ClientHeight = (clientRect.bottom - clientRect.top) ;
	m_Wintop = (windowRect.top - clientRect.top) ;
	m_Winleft = (windowRect.left - clientRect.left) ;
}