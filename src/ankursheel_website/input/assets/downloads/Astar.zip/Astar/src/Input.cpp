#include "stdafx.h"
#include "Input.h"

cInput::cInput()
{
	m_pDIObject = NULL ;
	m_pDIMouseDevice = NULL ;
	m_AbsMouseX = 0 ;
	m_AbsMouseY = 0 ;
	m_RelMouseX = 0 ;
	m_RelMouseY = 0 ;
}

cInput::~cInput()
{
		SAFE_RELEASE(m_pDIObject) ;
		m_pDIMouseDevice->Unacquire() ; 
		SAFE_RELEASE(m_pDIMouseDevice) ;
} 

bool cInput::InitDirectInput()
{
	if(FAILED(DirectInput8Create(GetModuleHandle(NULL),
								DIRECTINPUT_VERSION,
								IID_IDirectInput8,
								(void**)&m_pDIObject,
								NULL)))
	{
		MessageBox(0,_T("DirectInput8Create() failed!"), _T("InitDirectInput()"), MB_OK);
		return false;
	}

	return true;
} 

bool cInput::InitMouse(HWND hwnd, const int screenWidth, const int screenHeight)
{
	HRESULT     hr ; 

	hr = m_pDIObject->CreateDevice(GUID_SysMouse, &m_pDIMouseDevice, NULL) ;

	if(FAILED(hr)) 
	{
		MessageBox(0,_T("CreateDevice() failed!"), _T("InitMouse()"), MB_OK);
		return false;
	}

	hr = m_pDIMouseDevice->SetDataFormat(&c_dfDIMouse) ;
	if(FAILED(hr)) 
	{
		MessageBox(0,_T("SetDataFormat() failed!"), _T("InitMouse()"), MB_OK);
		return false ;
	}

	hr = m_pDIMouseDevice->SetCooperativeLevel(hwnd, DISCL_NONEXCLUSIVE | DISCL_BACKGROUND) ;
	if(FAILED(hr)) 
	{
		MessageBox(0,_T("SetCooperativeLevel() failed!"), _T("InitMouse()"), MB_OK);
		return false ;
	}
	//ShowCursor(false) ;
	//m_AbsMouseX = 0 ;
	//m_AbsMouseY = 0 ;
	m_AbsMouseX = screenWidth/2;
	m_AbsMouseY = screenHeight/2;
	SetCursorPos(m_AbsMouseX, m_AbsMouseY) ;
	
	return true  ;
}

bool cInput::SetMouseProperty()
{
	DIPROPDWORD		dipdw ;
	HRESULT			hr ;
	const int		iNoofBufferedItems = 16 ;

	dipdw.diph.dwSize = sizeof(DIPROPDWORD);
	dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
	dipdw.diph.dwObj = 0;
	dipdw.diph.dwHow = DIPH_DEVICE;
	//dipdw.dwData = DIPROPAXISMODE_ABS;
	//hr = m_pDIMouseDevice->SetProperty(DIPROP_AXISMODE , &dipdw.diph);
	dipdw.dwData = iNoofBufferedItems ;
	hr = m_pDIMouseDevice->SetProperty(DIPROP_BUFFERSIZE , &dipdw.diph);
	
	if (hr != DI_OK)
	{
		MessageBox(0,_T("SetProperty() failed!"),_T("SetMouseProperty()"), MB_OK) ;
		return false ;
	}
	return true ;
}
bool cInput::AcquireMouse()
{
	HRESULT		hr ;

	hr = m_pDIMouseDevice->Acquire() ;
	if(FAILED(hr))
	{
		while(hr == DIERR_INPUTLOST ) 
		{
			hr = m_pDIMouseDevice->Acquire() ;
		}
	}
	if(FAILED(hr))
	{
		MessageBox(0,_T("Acquire() failed!"),_T("AcquireMouse()"), MB_OK) ;
		return false ;
	}
	return true ;
}

bool cInput::UnacquireMouse()
{
	HRESULT		hr ;

	hr = m_pDIMouseDevice->Unacquire() ;
	if(FAILED(hr))
	{
		MessageBox(0,_T("Unacquire() failed!"),_T("UnacquireMouse()"), MB_OK) ;
		return false ;
	}
	return true ;
}

void cInput::PollMouse()
{
	HRESULT		hr ;
	DIMOUSESTATE diMouseState;
	static BOOL  ClickHandled = false ;
	TCHAR m_str[50] ;

	ZeroMemory(&diMouseState, sizeof(diMouseState)) ;
	hr  = m_pDIMouseDevice->GetDeviceState(sizeof(diMouseState), &diMouseState) ;
	{
		if( FAILED(hr) ) 
		{
			hr = m_pDIMouseDevice->Acquire() ;
			while( hr == DIERR_INPUTLOST ) 
			{
				hr = m_pDIMouseDevice->Acquire() ;
			}
		}
		if(diMouseState.rgbButtons[0] & 0x80)
		{
			if(!ClickHandled)
			{
				MessageBeep(0);
				//MessageBox(0,_T("pressed"),0,0) ;
				ClickHandled = TRUE;
				//MouseX = diMouseState.lX;
				//MouseY = diMouseState.lY;

				_stprintf_s(m_str, _countof(m_str) - 1, TEXT("%d, %d "), m_AbsMouseX, m_AbsMouseY) ;
				MessageBox(0,m_str,0,0) ;
			}
		}
		else
		{
			ClickHandled = FALSE;
		}
		m_RelMouseX = diMouseState.lX;
		m_RelMouseY = diMouseState.lY;

		m_AbsMouseX += diMouseState.lX;
		m_AbsMouseY += diMouseState.lY;
		//_stprintf_s(m_str, _countof(m_str) - 1, TEXT("%d, %d "), MouseX, MouseY) ;
		//MessageBox(0,m_str,0,0) ;

	}

	
}
//HRESULT ReadImmediateData( HWND hDlg )
//{
//    HRESULT       hr;
//    TCHAR         strNewText[128] = TEXT("");   // Output string
//    DIMOUSESTATE2 dims2;      // DirectInput Mouse state structure
//
//    if( NULL == g_pMouse ) 
//        return S_OK;
//    
//    // Get the input's device state, and put the state in dims
//    ZeroMemory( &dims2, sizeof(dims2) );
//    hr = g_pMouse->GetDeviceState( sizeof(DIMOUSESTATE2), &dims2 );
//    if( FAILED(hr) ) 
//    {
//        // DirectInput may be telling us that the input stream has been
//        // interrupted.  We aren't tracking any state between polls, so
//        // we don't have any special reset that needs to be done.
//        // We just re-acquire and try again.
//        
//        // If input is lost then acquire and keep trying 
//        hr = g_pMouse->Acquire();
//        while( hr == DIERR_INPUTLOST ) 
//            hr = g_pMouse->Acquire();
//
//        // Update the dialog text 
//        if( hr == DIERR_OTHERAPPHASPRIO || 
//            hr == DIERR_NOTACQUIRED ) 
//            SetDlgItemText( hDlg, IDC_DATA, TEXT("Unacquired") );
//
//        // hr may be DIERR_OTHERAPPHASPRIO or other errors.  This
//        // may occur when the app is minimized or in the process of 
//        // switching, so just try again later 
//        return S_OK; 
//    }
//    
//    // The dims structure now has the state of the Mouse, so 
//    // display Mouse coordinates (x, y, z) and buttons.
//    StringCchPrintf( strNewText, 128, TEXT("(X=% 3.3d, Y=% 3.3d, Z=% 3.3d) B0=%c B1=%c B2=%c B3=%c B4=%c B5=%c B6=%c B7=%c"),
//                         dims2.lX, dims2.lY, dims2.lZ,
//                        (dims2.rgbButtons[0] & 0x80) ? '1' : '0',
//                        (dims2.rgbButtons[1] & 0x80) ? '1' : '0',
//                        (dims2.rgbButtons[2] & 0x80) ? '1' : '0',
//                        (dims2.rgbButtons[3] & 0x80) ? '1' : '0',
//                        (dims2.rgbButtons[4] & 0x80) ? '1' : '0',
//                        (dims2.rgbButtons[5] & 0x80) ? '1' : '0',
//                        (dims2.rgbButtons[6] & 0x80) ? '1' : '0',
//                        (dims2.rgbButtons[7] & 0x80) ? '1' : '0');
//
//    // Get the old text in the text box
//    TCHAR strOldText[128];
//    GetDlgItemText( hDlg, IDC_DATA, strOldText, 127 );
//    
//    // If nothing changed then don't repaint - avoid flicker
//    if( 0 != lstrcmp( strOldText, strNewText ) ) 
//        SetDlgItemText( hDlg, IDC_DATA, strNewText );
//    
//    return S_OK;
//}