#include "stdafx.h"
#include "Camera.h"

cCamera::cCamera()
{
	m_cameraType = AIRCRAFT ;
	m_pos   = D3DXVECTOR3(0.0f, 0.0f, -100.0f) ;
	m_right = D3DXVECTOR3(1.0f, 0.0f, 0.0f) ;
	m_up    = D3DXVECTOR3(0.0f, 1.0f, 0.0f) ;
	m_look  = D3DXVECTOR3(0.0f, 0.0f, 1.0f) ;
	D3DXQuaternionIdentity(&m_quaternion) ;
}
cCamera::cCamera(const CameraType cameraType)
{
	m_cameraType = cameraType ;
	m_pos   = D3DXVECTOR3(0.0f, 0.0f, -100.0f) ;
	m_right = D3DXVECTOR3(1.0f, 0.0f, 0.0f) ;
	m_up    = D3DXVECTOR3(0.0f, 1.0f, 0.0f) ;
	m_look  = D3DXVECTOR3(0.0f, 0.0f, 1.0f) ;
	D3DXQuaternionIdentity(&m_quaternion) ;
}
cCamera::~cCamera()
{
}
void cCamera::getViewMatrix(D3DXMATRIX* V)
{

	//// 1.1) First calcuate Translation
	D3DXMATRIX matTranslation;

	D3DXMatrixTranslation(&matTranslation, -m_pos.x, -m_pos.y, -m_pos.z) ;
	//D3DXMatrixIdentity(&matTranslation) ;

	//// 1.2) Now calculate rotation, by taking the conjucate of the quaternion
	D3DXMATRIX matRotation ;

	D3DXMatrixRotationQuaternion( &matRotation, &m_quaternion) ;

	//// 2) Apply rotation & translation matrix at view matrix
	D3DXMatrixMultiply(V , &matTranslation , &matRotation ) ;

	UpdateVector() ;
}

void cCamera::Pitch(const float angle)
{
	D3DXQUATERNION Rotation ;

	D3DXQuaternionRotationAxis(&Rotation, &D3DXVECTOR3(1.0f,0.0f,0.0f), angle) ;
	D3DXQuaternionMultiply(&m_quaternion, &m_quaternion, &Rotation) ;
	//m_quaternion *= Rotation  ;
	D3DXQuaternionNormalize(&m_quaternion, &m_quaternion) ;
}

void cCamera::Yaw(const float angle) 
{
	D3DXQUATERNION Rotation ;

	D3DXQuaternionRotationAxis(&Rotation, &D3DXVECTOR3(0.0f, 1.0f, 0.0f), angle) ;
	D3DXQuaternionMultiply(&m_quaternion, &m_quaternion, &Rotation) ;
	//m_quaternion *= Rotation ;
	D3DXQuaternionNormalize(&m_quaternion , &m_quaternion) ;
}

void cCamera::Roll(const float angle)
{
	D3DXQUATERNION Rotation ;
	// only roll for aircraft type
	if(m_cameraType == AIRCRAFT )
	{
		D3DXQuaternionRotationAxis(&Rotation, &D3DXVECTOR3(0.0f,0.0f,1.0f), angle) ;
	}
	D3DXQuaternionMultiply(&m_quaternion, &m_quaternion, &Rotation) ;
	//m_quaternion *= Rotation ;
	D3DXQuaternionNormalize(&m_quaternion , &m_quaternion) ;
}

void cCamera::Move(const float units)
{
	D3DXVECTOR3		temp ;

	if(m_cameraType == LANDOBJECT )
	{
		D3DXVec3Scale(&temp,&D3DXVECTOR3(m_look.x, 0.0f, m_look.z), units) ;
		D3DXVec3Add(&m_pos, &m_pos, &temp) ;
	}
	if( m_cameraType == AIRCRAFT )
	{
		D3DXVec3Scale(&temp,&m_look, units) ;
		D3DXVec3Add(&m_pos, &m_pos, &temp) ;
	}

}

void cCamera::Strafe(const float units)
{
	D3DXVECTOR3		temp ;

	if(m_cameraType == LANDOBJECT )
	{
		D3DXVec3Scale(&temp,&D3DXVECTOR3(m_right.x, 0.0f, m_right.z), units) ;
		D3DXVec3Subtract(&m_pos, &m_pos, &temp) ;
	}
	if( m_cameraType == AIRCRAFT )
	{
		D3DXVec3Scale(&temp,&m_right, units) ;
		D3DXVec3Subtract(&m_pos, &m_pos, &temp) ;
	}
}
void cCamera::Fly(const float units) 
{
	D3DXVECTOR3		temp ;

	if( m_cameraType == AIRCRAFT )
	{
		D3DXVec3Scale(&temp,&m_up, units) ;
		D3DXVec3Add(&m_pos, &m_pos, &temp) ;
	}
}

D3DXVECTOR3 cCamera::getPosition()
{
	return m_pos ;
}

void cCamera::setPosition(D3DXVECTOR3 *pos)
{
	m_pos = *pos ;
}

void cCamera::UpdateVector() 
{
	D3DXMATRIX matRotation;

	D3DXMatrixRotationQuaternion(&matRotation, &m_quaternion) ; 

	m_right.x = matRotation._11 ;
	m_up.x = matRotation._12 ; 
	m_look.x = matRotation._13 ;

	m_right.y = matRotation._21 ; 
	m_up.y = matRotation._22 ;
	m_look.y = matRotation._23 ;

	m_right.z = matRotation._31 ;
	m_up.z = matRotation._32 ;
	m_look.z = matRotation._33 ;
}