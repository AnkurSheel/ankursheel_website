#pragma once 
#include "Common\Cube.h"

class cRoom:public cCube
{
protected:
	D3DXMATRIX				m_RoomWorldMatrix ;
	IDirect3DVertexBuffer9	*m_RoomVB ;
	IDirect3DIndexBuffer9	*m_RoomIB ;
	IDirect3DTexture9		*m_RoomTex[6] ;

public:
	cRoom() ;
	~cRoom() ;
	void CreateRoom(IDirect3DDevice9 *pd3dDevice) ;
	void drawRoom(IDirect3DDevice9 *pd3dDevice, const D3DXVECTOR3 &cameraPos) ;
} ;
