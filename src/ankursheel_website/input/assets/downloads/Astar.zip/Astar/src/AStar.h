#pragma once

class cAstar
{
protected:
	int			m_iOpenListIdNo,
				m_iNoofOpenListItems,
				m_iOpenList[NOOFSQUARES] ;
	POINT		m_iStartSquare,
				m_iTargetSquare,
				m_iParentSquareNo[NOOFROW][NOOFCOL],
				m_iItemSquareNo[NOOFSQUARES] ;
	float		m_fFcost[NOOFSQUARES],
				m_fGcost[NOOFROW][NOOFCOL],
				m_fHcost[NOOFSQUARES] ;
	BOOL		m_bInOpenList[NOOFROW][NOOFCOL],
				m_bInClosedList[NOOFROW][NOOFCOL] ;
	SquareType	**m_SqType ;
	

public:
	cAstar() ;
	~cAstar() ;
	void SetStartTargetPos(const POINT &startpos, const POINT &targetpos) ;
	void CalculatePath(SquareType **SqType) ;
	//void ReorderHeap(const int CurrentPos, const int m_iNoofOpenListItems) ;
	void ResetValues() ;
	void GetLowestFcostNodeonTop() ;
	void AddNodetoOpenList(const int XPos, const int YPos, const POINT &ParentPos) ;
	void GetShortestPath() ;
	bool CheckIfCuttingCorner(const int XPos, const int YPos, const POINT &ParentPos) ;
	void ChangeCostPosofItem(const float &newGCost, const int XPos, const int YPos,const POINT &ParentPos) ;
	void AddItemtoOpenList(const float &addGcost, const int XPos, const int YPos,const POINT &ParentPos) ;
	void ReorderHeap(const int iItemPos) ;
} ;
