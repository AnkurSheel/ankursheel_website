#include "stdafx.h"
#include "Cube.h"

cCube::cCube()
{
}

cCube::~cCube()
{
}
void cCube::CreateCubeVertexLight(IDirect3DVertexBuffer9 *CubeVB, const D3DXVECTOR3 *vec)
{
	/* Pass vec as follows
	0	-x, -y, z
	1	-x, y, z
	2	x,y, z
	3	x, -y, z
	4	-x, -y, -z
	5	-x,y, -z
	6	x, y, -z
	7	x, -y, -z */

	VertexLight		*vertices ;

	HRESULT hres ;
	hres = CubeVB->Lock(0, 0, (void**)&vertices, 0) ;

	// positive x
	vertices[0] = VertexLight(vec[3].x, vec[3].y,  vec[3].z, 0.0f, 1.0f) ;
	vertices[1] = VertexLight(vec[2].x, vec[2].y,  vec[2].z, 0.0f, 0.0f) ;
	vertices[2] = VertexLight(vec[6].x, vec[6].y,  vec[6].z, 1.0f, 0.0f) ;
	vertices[3] = VertexLight(vec[7].x, vec[7].y,  vec[7].z, 1.0f, 1.0f) ;

	// negative x
	vertices[4] = VertexLight(vec[4].x, vec[4].y,  vec[4].z, 0.0f, 1.0f) ;
	vertices[5] = VertexLight(vec[5].x, vec[5].y,  vec[5].z, 0.0f, 0.0f) ;
	vertices[6] = VertexLight(vec[1].x, vec[1].y,  vec[1].z, 1.0f, 0.0f) ;
	vertices[7] = VertexLight(vec[0].x, vec[0].y,  vec[0].z, 1.0f, 1.0f) ;

	// positive y
	vertices[8]  = VertexLight(vec[1].x, vec[1].y,  vec[1].z, 0.0f, 1.0f) ;
	vertices[9]  = VertexLight(vec[5].x, vec[5].y,  vec[5].z, 0.0f, 0.0f) ; 
	vertices[10] = VertexLight(vec[6].x, vec[6].y,  vec[6].z, 1.0f, 0.0f) ;
	vertices[11] = VertexLight(vec[2].x, vec[2].y,  vec[2].z, 1.0f, 1.0f) ;

	// negative y
	vertices[12] = VertexLight(vec[4].x, vec[4].y,  vec[4].z, 0.0f, 1.0f) ;
	vertices[13] = VertexLight(vec[0].x, vec[0].y,  vec[0].z, 0.0f, 0.0f) ;
	vertices[14] = VertexLight(vec[3].x, vec[3].y,  vec[3].z, 1.0f, 0.0f) ;
	vertices[15] = VertexLight(vec[7].x, vec[7].y,  vec[7].z, 1.0f, 1.0f) ;

	// positive z
	vertices[16] = VertexLight(vec[0].x, vec[0].y,  vec[0].z, 0.0f, 1.0f) ;
	vertices[17] = VertexLight(vec[1].x, vec[1].y,  vec[1].z, 0.0f, 0.0f) ;
	vertices[18] = VertexLight(vec[2].x, vec[2].y,  vec[2].z, 1.0f, 0.0f) ;
	vertices[19] = VertexLight(vec[3].x, vec[3].y,  vec[3].z, 1.0f, 1.0f) ;

	// negative z
	vertices[20] = VertexLight(vec[7].x, vec[7].y,  vec[7].z, 0.0f, 1.0f) ;
	vertices[21] = VertexLight(vec[6].x, vec[6].y,  vec[6].z, 0.0f, 0.0f) ;
	vertices[22] = VertexLight(vec[5].x, vec[5].y,  vec[5].z, 1.0f, 0.0f) ;
	vertices[23] = VertexLight(vec[4].x, vec[4].y,  vec[4].z, 1.0f, 1.0f) ;

	CubeVB->Unlock() ;
}

void cCube::CreateCubeVertexColor(IDirect3DVertexBuffer9 *CubeVB, const D3DXVECTOR3 *vec, const int cubeno, 
								  const D3DCOLOR col)
{
	/* Pass vec as follows
	0	-x, -y, z
	1	-x, y, z
	2	x,y, z
	3	x, -y, z
	4	-x, -y, -z
	5	-x,y, -z
	6	x, y, -z
	7	x, -y, -z */

	Vertex		*vertices = 0 ;

	int size = sizeof(Vertex)  * 24;
	int offset = (cubeno - 1) * size;

	CubeVB->Lock(offset, size , (void**)&vertices, 0) ;

	// positive x
	vertices[0] = Vertex(&vec[3], col, &D3DXVECTOR2(0.0f, 1.0f)) ;
	vertices[1] = Vertex(&vec[2], col, &D3DXVECTOR2(0.0f, 0.0f)) ;
	vertices[2] = Vertex(&vec[6], col, &D3DXVECTOR2(1.0f, 0.0f)) ;
	vertices[3] = Vertex(&vec[7], col, &D3DXVECTOR2(1.0f, 1.0f)) ;


	// negative x
	vertices[4] = Vertex(&vec[4], col, &D3DXVECTOR2(0.0f, 1.0f)) ;
	vertices[5] = Vertex(&vec[5], col, &D3DXVECTOR2(0.0f, 0.0f)) ;
	vertices[6] = Vertex(&vec[1], col, &D3DXVECTOR2(1.0f, 0.0f)) ;
	vertices[7] = Vertex(&vec[0], col, &D3DXVECTOR2(1.0f, 1.0f)) ;


	// positive y
	vertices[8]  = Vertex(&vec[1], col, &D3DXVECTOR2(0.0f, 1.0f)) ;
	vertices[9]  = Vertex(&vec[5], col, &D3DXVECTOR2(0.0f, 0.0f)) ; 
	vertices[10] = Vertex(&vec[6], col, &D3DXVECTOR2(1.0f, 0.0f)) ;
	vertices[11] = Vertex(&vec[2], col, &D3DXVECTOR2(1.0f, 1.0f)) ;

	// negative y
	vertices[12] = Vertex(&vec[4], col, &D3DXVECTOR2(0.0f, 1.0f)) ;
	vertices[13] = Vertex(&vec[0], col, &D3DXVECTOR2(0.0f, 0.0f)) ;
	vertices[14] = Vertex(&vec[3], col, &D3DXVECTOR2(1.0f, 0.0f)) ;
	vertices[15] = Vertex(&vec[7], col, &D3DXVECTOR2(1.0f, 1.0f)) ;

	// positive z
	vertices[16] = Vertex(&vec[0], col, &D3DXVECTOR2(0.0f, 1.0f)) ;
	vertices[17] = Vertex(&vec[1], col, &D3DXVECTOR2(0.0f, 0.0f)) ;
	vertices[18] = Vertex(&vec[2], col, &D3DXVECTOR2(1.0f, 0.0f)) ;
	vertices[19] = Vertex(&vec[3], col, &D3DXVECTOR2(1.0f, 1.0f)) ;

	// negative z
	vertices[20] = Vertex(&vec[7], col, &D3DXVECTOR2(0.0f, 1.0f)) ;
	vertices[21] = Vertex(&vec[6], col, &D3DXVECTOR2(0.0f, 0.0f)) ;
	vertices[22] = Vertex(&vec[5], col, &D3DXVECTOR2(1.0f, 0.0f)) ;
	vertices[23] = Vertex(&vec[4], col, &D3DXVECTOR2(1.0f, 1.0f)) ;

	CubeVB->Unlock() ;
}

void cCube::GenerateCubeInwards(IDirect3DIndexBuffer9	*CubeIB)
{
	WORD		*indices = 0 ;

	CubeIB->Lock(0, 0, (void**)&indices, 0) ;

	// positive x
	indices[0] = 0 ; indices[1] = 1 ; indices[2] = 2 ;
	indices[3] = 0 ; indices[4] = 2 ; indices[5] = 3 ;

	// negative x
	indices[6]  = 4 ; indices[7]  = 5 ; indices[8]  = 6 ; 
	indices[9]  = 4 ; indices[10] = 6 ; indices[11] = 7 ;

	// positive y
	indices[12] = 8 ; indices[13] = 9 ; indices[14] = 10 ;
	indices[15] = 8 ; indices[16] = 10 ; indices[17] = 11 ;

	// negative y
	indices[18] = 12 ; indices[19] = 13 ; indices[20] = 14 ;
	indices[21] = 12 ; indices[22] = 14 ; indices[23] = 15 ;

	// positive z
	indices[24] = 16 ; indices[25] = 17 ; indices[26] = 18 ;
	indices[27] = 16 ; indices[28] = 18 ; indices[29] = 19 ;

	// negative z
	indices[30] = 20 ; indices[31] = 21 ; indices[32] = 22 ;
	indices[33] = 20 ; indices[34] = 22 ; indices[35] = 23 ;

	CubeIB->Unlock() ;

}

void cCube::GenerateCubeOutwards(IDirect3DIndexBuffer9	*CubeIB, const int cubeno)
{
	WORD		*indices ;

	int offset = (cubeno - 1) * 24 ;
	int size = sizeof(WORD) * 36 ;
	int offsetIB	= (cubeno - 1) * size ;

	CubeIB->Lock(offsetIB, size, (void**)&indices, 0) ;

	// positive x
	indices[0] = offset+0 ; indices[01] = offset+2 ; indices[2] = offset+1 ;
	indices[3] = offset+0 ; indices[4] = offset+3 ; indices[5] = offset+2 ;

	// negative x
	indices[6]  =offset+4 ; indices[7]  = offset+6 ; indices[8]  = offset+5 ; 
	indices[9]  = offset+4 ; indices[10] = offset+7 ; indices[11] = offset+6 ;

	// positive y
	indices[12] = offset+8 ; indices[13] = offset+10 ; indices[14] = offset+9 ;
	indices[15] = offset+8 ; indices[16] = offset+11 ; indices[17] = offset+10 ;

	// negative y
	indices[18] = offset+12 ; indices[19] = offset+14 ; indices[20] = offset+13 ;
	indices[21] = offset+12 ; indices[22] = offset+15 ; indices[23] = offset+14 ;

	// positive z
	indices[24] = offset+16 ; indices[25] = offset+18 ; indices[26] = offset+17 ;
	indices[27] = offset+16 ; indices[28] = offset+19 ; indices[29] = offset+18 ;

	// negative z
	indices[30] = offset+20 ; indices[31] = offset+22 ; indices[32] = offset+21 ;
	indices[33] = offset+20 ; indices[34] = offset+23 ; indices[35] = offset+22 ;

	indices[0] = offset+0 ; indices[1] = offset+2 ; indices[2] = offset+1 ;
	indices[3] = offset+0 ; indices[4] = offset+3 ; indices[5] = offset+2 ;

	// negative x
	indices[6]  = offset+4 ; indices[7]  = offset+6 ; indices[8]  = offset+5 ; 
	indices[9]  = offset+4 ; indices[10] = offset+7 ; indices[11] = offset+6 ;

	// positive y
	indices[12] = offset+8 ; indices[13] = offset+10 ; indices[14] = offset+9 ;
	indices[15] = offset+8 ; indices[16] = offset+11 ; indices[17] = offset+10 ;

	// negative y
	indices[18] = offset+12 ; indices[19] = offset+14 ; indices[20] = offset+13 ;
	indices[21] = offset+12 ; indices[22] = offset+15 ; indices[23] = offset+14 ;

	// positive z
	indices[24] = offset+16 ; indices[25] = offset+18 ; indices[26] = offset+17 ;
	indices[27] = offset+16 ; indices[28] = offset+19 ; indices[29] = offset+18 ;

	// negative z
	indices[30] = offset+20 ; indices[31] = offset+22 ; indices[32] = offset+21 ;
	indices[33] = offset+20 ; indices[34] = offset+23 ; indices[35] = offset+22 ;

	HRESULT hres ;
	hres = CubeIB->Unlock() ;

}

void cCube::DrawCube(IDirect3DDevice9 *pd3dDevice, IDirect3DVertexBuffer9 *CubeVB, IDirect3DIndexBuffer9 *CubeIB,
					 IDirect3DTexture9	**m_CubeTex, const int cubeno)
{
	int		iBaseVertIndex,
			iBaseindIndex ;

	iBaseVertIndex = (cubeno-1)*24 ;
	iBaseindIndex = (cubeno-1)*36 ;

	if(m_CubeTex)
	{
		pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE) ;
		pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE) ;	
		pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_TEXTURE) ;	
	}
	else
	{
		pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1) ;
		pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE) ;	
	}


	pd3dDevice->SetStreamSource(0, CubeVB, 0, sizeof(Vertex)) ;
	pd3dDevice->SetIndices(CubeIB) ;
	pd3dDevice->SetFVF(Vertex::FVF) ;
	for(int i = 0; i < 6; ++i)
	{ 
		if(m_CubeTex)
		{
			pd3dDevice->SetTexture(0, m_CubeTex[i]) ;
		}
		else
		{
			pd3dDevice->SetTexture(0, NULL) ;
		}
		pd3dDevice->DrawIndexedPrimitive(
			D3DPT_TRIANGLELIST,
			0,   // Base Vertex Index
			iBaseVertIndex +(i*4), // Min Vertex Index
			4,   // Num vertices (4 vertices / quad)
			//iBaseStartIndex+(i*6), // Start Index (6 indices / quad)
			iBaseindIndex + (i*6), // Start Index (6 indices / quad)
			2) ;  // Primitive Count (2 triangles / quad)
	}

	//for(int i = 0; i < 6; ++i)
	//{ 
	//	if(m_CubeTex)
	//	{
	//		pd3dDevice->SetTexture(0, m_CubeTex[i]) ;
	//	}
	//	pd3dDevice->DrawIndexedPrimitive(
	//		D3DPT_TRIANGLELIST,
	//		iBaseVertIndex,   // Base Vertex Index
	//		i*4, // Min Vertex Index
	//		4,   // Num vertices (4 vertices / quad)
	//		//iBaseStartIndex+(i*6), // Start Index (6 indices / quad)
	//		(i*6), // Start Index (6 indices / quad)
	//		2) ;  // Primitive Count (2 triangles / quad)
	//}

}
