#include "stdafx.h"
#include "myDxMainClass.h" 

cMyDirectxMain::cMyDirectxMain()
{
	m_pD3D = NULL ;
	m_pd3dDevice = NULL ;
	hwnd = NULL ;
	m_BkColor = BLACK ;
	m_FullScreenWidth = 800 ;
	m_FullScreenHeight = 600;
}

cMyDirectxMain::~cMyDirectxMain()
{
	Release() ;
}

void cMyDirectxMain::DirectxInit()
{
	m_pD3D = Direct3DCreate9(D3D_SDK_VERSION) ;
	if(m_pD3D == NULL)
	{
		MessageBox(NULL, _T("Direct3d object creation failed!"), _T("Error!"), MB_ICONEXCLAMATION | MB_OK) ;
	}
	m_pD3D->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &m_Caps) ;
}

void cMyDirectxMain::CreateDirectxDevice() 
{
	int		vp = 0 ;
	
	if(m_Caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT )
	{
		// yes, save in �vp� the fact that hardware vertex processing is supported.
		vp = D3DCREATE_HARDWARE_VERTEXPROCESSING ;
	}
	else
	{
		// no, save in �vp� the fact that we must use software vertex processing.
		vp = D3DCREATE_SOFTWARE_VERTEXPROCESSING ;
	}

	//SetParameters(FULLSCREEN) ;
	// Create the D3DDevice
	if(FAILED(m_pD3D->CreateDevice(D3DADAPTER_DEFAULT,
								   D3DDEVTYPE_HAL, 
								   hwnd,
								   vp,
								   &m_d3dpp,
								   &m_pd3dDevice)))
	{
		MessageBox(NULL, _T("Direct3d m_pd3dDevice creation failed!"), _T("Error!"),MB_ICONEXCLAMATION | MB_OK) ;
		PostQuitMessage(0) ;
		DestroyWindow(hwnd) ;
	}
}

void cMyDirectxMain::Release()
{
	SAFE_RELEASE(m_pd3dDevice) ;
	SAFE_RELEASE(m_pD3D) ;
}

BOOL cMyDirectxMain::IsAvailable()
{
	    return(m_pd3dDevice->TestCooperativeLevel()) ;
}

void cMyDirectxMain::HandleLostDevice(HRESULT hr)
{
	if(hr == D3DERR_DEVICELOST)
	{
		FreeVolatileResources() ;
		Sleep(500) ;
	}
	else 
	{
		if(hr == D3DERR_DEVICENOTRESET) //The m_pd3dDevice is ready to be Reset
		{
			hr = ResetDevice() ;
		}
   }
}

void cMyDirectxMain::SetParameters(const BOOL bFullScreen)
{
	ZeroMemory(&m_d3dpp, sizeof(m_d3dpp)) ;

	m_d3dpp.BackBufferCount = 1 ;
	m_d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE ;
	m_d3dpp.MultiSampleQuality = 0 ;
	m_d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD ;
	m_d3dpp.hDeviceWindow = hwnd ;
	m_d3dpp.Flags = 0 ;
	m_d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT ;
	m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE ;
	m_d3dpp.BackBufferFormat = D3DFMT_A8R8G8B8 ; //pixel format
	m_d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8 ; // depth format
	m_d3dpp.EnableAutoDepthStencil = true ;
	if(bFullScreen)
	{
		m_d3dpp.BackBufferWidth = m_FullScreenWidth ;
		m_d3dpp.BackBufferHeight = m_FullScreenHeight ;
		m_d3dpp.Windowed = false; // fullscreen
		
	}
	else
	{
		m_d3dpp.Windowed = true ;
		m_d3dpp.EnableAutoDepthStencil = TRUE ;
		m_d3dpp.AutoDepthStencilFormat = D3DFMT_D16 ;
	}
}

HRESULT cMyDirectxMain::ResetDevice()
{
	HRESULT		hr ;

	FreeVolatileResources() ;
	hr = m_pd3dDevice->Reset(&m_d3dpp) ;
	//If the m_pd3dDevice was successfully Reset, re-Initialize the Volatile resources
	if(SUCCEEDED(hr))
	{
		InitVolatileResources();
	}
	return hr ;
}

void cMyDirectxMain::Init()
{
	DirectxInit() ;
	SetParameters(WINDOW) ;
	//SetParameters(FULLSCREEN) ;
	CreateDirectxDevice() ;
	InitVolatileResources() ;
}
