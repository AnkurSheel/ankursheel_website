#include "stdafx.h"
#include "Room.h"

cRoom::cRoom()
{
	m_RoomIB = NULL ;
	m_RoomVB = NULL ;
	for(int i = 0; i<6 ;i++)
	{
		m_RoomTex[i] = NULL ;
	}
	D3DXMatrixIdentity(&m_RoomWorldMatrix) ;
	m_RoomWorldMatrix._43 = 0 ;
}

cRoom::~cRoom()
{
	for(int i = 0; i<6 ;i++)
	{
		if(m_RoomTex[i])
		{
			m_RoomTex[i]->Release() ;
		}
	}

	if(m_RoomIB)
	{
		m_RoomIB->Release() ;
	}

	if(m_RoomVB)
	{
		m_RoomVB->Release() ;
	}
}

void cRoom::CreateRoom(IDirect3DDevice9 *pd3dDevice)
{
	D3DXVECTOR3		vec[8] ;

	pd3dDevice->CreateVertexBuffer(
		24 * sizeof(VertexLight), 
		D3DUSAGE_WRITEONLY,
		VertexLight::FVF,
		D3DPOOL_MANAGED,
		&m_RoomVB,
		0) ;

	pd3dDevice->CreateIndexBuffer(
		36 * sizeof(WORD),
		D3DUSAGE_WRITEONLY,
		D3DFMT_INDEX16,
		D3DPOOL_MANAGED,
		&m_RoomIB,
		0) ;

	vec[0] = D3DXVECTOR3(-100.0f, -100.0f,  100.0f) ;
	vec[1] = D3DXVECTOR3(-100.0f,  100.0f,  100.0f) ;
	vec[2] = D3DXVECTOR3(100.0f,  100.0f,  100.0f) ;
	vec[3] = D3DXVECTOR3(100.0f, -100.0f,  100.0f) ;
	vec[4] = D3DXVECTOR3(-100.0f, -100.0f, -100.0f) ;
	vec[5] = D3DXVECTOR3(-100.0f,  100.0f, -100.0f) ;
	vec[6] = D3DXVECTOR3(100.0f,  100.0f, -100.0f) ;
	vec[7] = D3DXVECTOR3(100.0f, -100.0f, -100.0f) ;

	CreateCubeVertexLight(m_RoomVB, vec) ;
	GenerateCubeInwards(m_RoomIB) ;


	D3DXCreateTextureFromFile(pd3dDevice,TEXT("bin\\Textures\\desert.bmp"), &m_RoomTex[0]) ;
	D3DXCreateTextureFromFile(pd3dDevice,TEXT("bin\\Textures\\dirt.jpg"), &m_RoomTex[1]) ;
	D3DXCreateTextureFromFile(pd3dDevice,TEXT("bin\\Textures\\Brick0.jpg"), &m_RoomTex[2]) ;
	D3DXCreateTextureFromFile(pd3dDevice,TEXT("bin\\Textures\\Brick1.jpg"), &m_RoomTex[3]) ;
	D3DXCreateTextureFromFile(pd3dDevice,TEXT("bin\\Textures\\gravel.jpg"), &m_RoomTex[4]) ;
	D3DXCreateTextureFromFile(pd3dDevice,TEXT("bin\\Textures\\stonewall.jpg"), &m_RoomTex[5]) ;
		
	pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR) ;
	pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR) ;
	pd3dDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_POINT) ; 
}

void cRoom::drawRoom(IDirect3DDevice9 *pd3dDevice, const D3DXVECTOR3 &cameraPos)
{
	pd3dDevice->SetTransform(D3DTS_WORLD, &m_RoomWorldMatrix) ;

	pd3dDevice->SetStreamSource(0, m_RoomVB, 0, sizeof(VertexLight)) ;
	pd3dDevice->SetIndices(m_RoomIB) ;
	pd3dDevice->SetFVF(VertexLight::FVF) ;

	for(int i = 0; i < 6; ++i)
	{ 
		pd3dDevice->SetTexture(0, m_RoomTex[i]) ;
		pd3dDevice->DrawIndexedPrimitive(
			D3DPT_TRIANGLELIST,
			0,   // Base Vertex Index
			i*4, // Min Vertex Index
			4,   // Num vertices (4 vertices / quad)
			i*6, // Start Index (6 indices / quad)
			2) ;  // Primitive Count (2 triangles / quad)
	}
}

