# pragma once

#include "VertexStruct.h"

class cCube
{
public:
	cCube() ;
	~cCube() ;
	void CreateCubeVertexLight(IDirect3DVertexBuffer9 *CubeVB, const D3DXVECTOR3 *vec) ;
	void CreateCubeVertexColor(IDirect3DVertexBuffer9 *CubeVB, const D3DXVECTOR3 *vec, const int cubeno, const D3DCOLOR col) ;
	void GenerateCubeInwards(IDirect3DIndexBuffer9	*CubeIB) ;
	void GenerateCubeOutwards(IDirect3DIndexBuffer9	*CubeIB, const int cubeno) ;
	void DrawCube(IDirect3DDevice9 *pd3dDevice, IDirect3DVertexBuffer9 *CubeVB, IDirect3DIndexBuffer9 *CubeIB, IDirect3DTexture9 **m_CubeTex,const int cubeno) ;
} ;