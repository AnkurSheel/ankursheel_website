#include "stdafx.h"
#include "Grid.h"

cGrid::cGrid()
{
	m_GridTex = NULL ;
	m_WallTex = NULL ;

	m_sqheight = 0 ;
	m_sqwidth = 0 ;

	m_Type = new SquareType*[NOOFROW] ;
	for(int i=0;i<NOOFROW;i++)
	{
		m_Type[i] = new SquareType[NOOFCOL] ;
		for(int j=0;j<NOOFCOL;j++)
		{
			m_Type[i][j] = Plain ;
		}
	}
	m_Type[3][2] = Wall ;

}

cGrid::~cGrid()
{
	SAFE_RELEASE(m_GridTex)
	
	for(int i=0;i<NOOFROW;i++)
	{
		SAFE_DELETE(m_Type[i]) ;
	}
	SAFE_DELETE(m_Type) ;
}

void cGrid::CreateGrid(IDirect3DDevice9 *pd3dDevice, int width, int height)
{
	m_gridvertex[0] = Vertex(&D3DXVECTOR3(0.0f, m_sqheight , 0.0f),WHITE, &D3DXVECTOR2(0.0f,0.0f)) ;
	m_gridvertex[1] = Vertex(&D3DXVECTOR3(0.0f, 0.0f, 0.0f),WHITE, &D3DXVECTOR2(0.0f,0.5f)) ;
	m_gridvertex[2] = Vertex(&D3DXVECTOR3(m_sqwidth, 0.0f, 0.0f),WHITE, &D3DXVECTOR2(0.5f,0.5f)) ;
	m_gridvertex[3] = Vertex(&D3DXVECTOR3(m_sqwidth, m_sqheight, 0.0f), WHITE, &D3DXVECTOR2(0.5f,0.0f)) ;

	m_gridIndices[0] = 0 ;	m_gridIndices[1] = 1 ;	m_gridIndices[2] = 2 ;
	m_gridIndices[3] = 0 ;	m_gridIndices[4] = 2 ;	m_gridIndices[5] = 3 ;
	
	pd3dDevice->SetTexture(0, m_GridTex) ;
}

void cGrid::InitAfterReset(IDirect3DDevice9 *pd3dDevice, int width, int height)
{
	m_sqheight = height/NOOFROW ;
	m_sqwidth = width/NOOFCOL ;

	D3DXCreateTextureFromFile(pd3dDevice,TEXT("grid.bmp"), &m_GridTex) ;
}
void cGrid::FreeVolResources()
{
	SAFE_RELEASE(m_GridTex)
}
void cGrid::DrawGrid(IDirect3DDevice9 *pd3dDevice)
{

	pd3dDevice->SetFVF(Vertex::FVF) ;
	//pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME) ;
	for(int i=0;i<NOOFROW;i++)
	{
		for(int j=0;j<NOOFCOL;j++)
		{
			if(j == 0 || m_Type[i][j-1] != m_Type[i][j])
			{
				switch(m_Type[i][j])
				{
				case Plain:	
					m_gridvertex[0].tex.x = 0.0f ;
					m_gridvertex[1].tex.x = 0.0f ;
					m_gridvertex[2].tex.x = 0.25f ;
					m_gridvertex[3].tex.x = 0.25f ;

					m_gridvertex[0].tex.y = 0.0f ;
					m_gridvertex[1].tex.y = 0.25f ;
					m_gridvertex[2].tex.y = 0.25f ;
					m_gridvertex[3].tex.y = 0.0f ;
					break ;

				case Wall:
					m_gridvertex[0].tex.x = 0.25f ;
					m_gridvertex[1].tex.x = 0.25f ;
					m_gridvertex[2].tex.x = 0.5f ;
					m_gridvertex[3].tex.x = 0.5f ;

					m_gridvertex[0].tex.y = 0.0f ;
					m_gridvertex[1].tex.y = 0.25f ;
					m_gridvertex[2].tex.y = 0.25f ;
					m_gridvertex[3].tex.y = 0.0f ;
					break ;

				case Open:
					m_gridvertex[0].tex.x = 0.5f ;
					m_gridvertex[1].tex.x = 0.5f ;
					m_gridvertex[2].tex.x = 0.75f ;
					m_gridvertex[3].tex.x = 0.75f ;

					m_gridvertex[0].tex.y = 0.0f ;
					m_gridvertex[1].tex.y = 0.25f ;
					m_gridvertex[2].tex.y = 0.25f ;
					m_gridvertex[3].tex.y = 0.0f ;
					break ;

				case Closed:
					m_gridvertex[0].tex.x = 0.75f ;
					m_gridvertex[1].tex.x = 0.75f ;
					m_gridvertex[2].tex.x = 1.0f ;
					m_gridvertex[3].tex.x = 1.0f ;

					m_gridvertex[0].tex.y = 0.0f ;
					m_gridvertex[1].tex.y = 0.25f ;
					m_gridvertex[2].tex.y = 0.25f ;
					m_gridvertex[3].tex.y = 0.0f ;
					break ;

				case Start:
					m_gridvertex[0].tex.x = 0.0f ;
					m_gridvertex[1].tex.x = 0.0f ;
					m_gridvertex[2].tex.x = 0.25f ;
					m_gridvertex[3].tex.x = 0.25f ;

					m_gridvertex[0].tex.y = 0.25f ;
					m_gridvertex[1].tex.y = 0.5f ;
					m_gridvertex[2].tex.y = 0.5f ;
					m_gridvertex[3].tex.y = 0.25f ;
					break;

				case Target:
					m_gridvertex[0].tex.x = 0.25f ;
					m_gridvertex[1].tex.x = 0.25f ;
					m_gridvertex[2].tex.x = 0.5f ;
					m_gridvertex[3].tex.x = 0.5f ;

					m_gridvertex[0].tex.y = 0.25f ;
					m_gridvertex[1].tex.y = 0.5f ;
					m_gridvertex[2].tex.y = 0.5f ;
					m_gridvertex[3].tex.y = 0.25f ;
					break ;

				case Path:
					m_gridvertex[0].tex.x = 0.5f ;
					m_gridvertex[1].tex.x = 0.5f ;
					m_gridvertex[2].tex.x = 0.75f ;
					m_gridvertex[3].tex.x = 0.75f ;

					m_gridvertex[0].tex.y = 0.25f ;
					m_gridvertex[1].tex.y = 0.5f ;
					m_gridvertex[2].tex.y = 0.5f ;
					m_gridvertex[3].tex.y = 0.25f ;

				}
			}
			pd3dDevice->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 4, 2, m_gridIndices, D3DFMT_INDEX16, m_gridvertex, sizeof(Vertex)) ;

			for(int k=0;k<4;k++)
			{
				m_gridvertex[k].position.x += m_sqwidth ;
			}

		}
		for(int k=0;k<4;k++)
		{
			m_gridvertex[k].position.y += m_sqheight ;
		}
		m_gridvertex[0].position.x = 0.0f ;
		m_gridvertex[1].position.x = 0.0f ;
		m_gridvertex[2].position.x = m_sqwidth ;
		m_gridvertex[3].position.x = m_sqwidth ;
	}
	m_gridvertex[0].position.x = 0.0f ;
	m_gridvertex[1].position.x =0.0f ;
	m_gridvertex[2].position.x = m_sqwidth ;
	m_gridvertex[3].position.x = m_sqwidth ;
	m_gridvertex[0].position.y = m_sqheight ;
	m_gridvertex[1].position.y = 0.0f ;
	m_gridvertex[2].position.y = 0.0f ;
	m_gridvertex[3].position.y = m_sqheight ;
}

void cGrid::ToggleSquare(const int XCoord, const int YCoord)
{

	int y = XCoord/m_sqwidth ;
	int x = YCoord/m_sqheight ;

	
	switch(m_Type[x][y])
	{
	case Plain:
		//m_Type[temp] = Wall ;
		m_Type[x][y] = Wall ;
		break ;

	case Wall:
		//m_Type[temp] = Plain ;
		m_Type[x][y] = Plain ;
		break ;

	case Open:
	case Closed:
	case Path:
		for(int i=0;i<NOOFROW;i++)
		{
			for(int j=0;j<NOOFCOL;j++)
			{
				m_Type[i][j] = Plain ;
			}
		}
		m_Type[m_StartPos.x][m_StartPos.y] = Start ;
		m_Type[m_targetPos.x][m_targetPos.y] = Target ;
		m_Type[x][y] = Wall ;
		break ;
	}
}
void cGrid::SetStartTargetPos(const POINT &startpos, const POINT &targetpos)
{
	m_Type[startpos.x][startpos.y] = Start ;
	m_Type[targetpos.x][targetpos.y] = Target ;
	m_StartPos = startpos ;
	m_targetPos = targetpos ;
}

SquareType **cGrid::GetSquareTypeList()
{
	return m_Type ;
}