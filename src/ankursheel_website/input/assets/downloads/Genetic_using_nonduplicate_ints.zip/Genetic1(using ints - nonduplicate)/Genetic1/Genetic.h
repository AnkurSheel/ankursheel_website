#pragma once

#include "Main.h"

struct Genome
{
	//string	szgenes ;
	vector <int> genes ;
	float	ffitness ;
	Genome() ;
	Genome(vector<int> gene) ;
} ;

class cGenetic
{
protected:
	UINT			m_iTarget,
					m_iRowSize,
					m_iColSize,
					m_iGenomeLength,
					m_iPopSize,
					m_iMaxGenerations ;
	const float		m_iCrossoverRate,
					m_iMutationRate ;
	vector<Genome>	m_Population ;
	BOOL			m_bSolutionFound ;
	Genome			m_Solution ;
	int				m_iFoundinGenNo ;
	int				m_iMaxNo ;

public:
	cGenetic() ;
	~cGenetic() ;
	UINT GetTarget() ;
	UINT GetPopSize() ;
	float GetCrossOverRate() ;
	float GetMutationRate() ;
	void SetRandSeed() ;
	void CreateRandomPopulation() ;
	void FindSolution() ;
	void CalculateFitness() ;
	int CalculateRowTotal(vector<int> values) ;
	int CalculateColTotal(vector<int> values) ;
	Genome Selection() ;
	void CrossOver(vector<int> &Father, vector<int> &Mother) ;
	void Mutate(vector<int> &gene) ;
	void PrintSolution() ;
	BOOL CheckForDuplicateNo(const UINT no, const vector<int> gene) ;
};