#include "genetic.h"

Genome::Genome()
{
	ffitness = 0.0f ;
}

Genome::Genome(vector<int> gene)
{
	//szgenes = genes ;
	genes = gene ;
	ffitness = 0.0f ;
}

cGenetic::cGenetic()
:m_iCrossoverRate(0.75f), m_iMutationRate(0.02f) 
{
	m_iTarget = 15 ;
	m_iRowSize = 3 ;
	m_iColSize = 3 ;
	m_iGenomeLength = m_iRowSize * m_iColSize ;// * BINPLACES ;
	m_iPopSize		= 200 ;
	m_iMaxGenerations = 10000 ;
	m_bSolutionFound = false ;
	m_iFoundinGenNo = -1 ;
	m_iMaxNo = 9 ;//powf(2, BINPLACES) ;

	srand((UINT)timeGetTime()) ;
}

cGenetic::~cGenetic()
{
}

UINT cGenetic::GetTarget()
{
	return m_iTarget ;
}

UINT cGenetic::GetPopSize()
{
	return m_iPopSize ;
}

float cGenetic::GetCrossOverRate() 
{
	return m_iCrossoverRate ;
}

float cGenetic::GetMutationRate()
{
	return m_iMutationRate ;
}
void cGenetic::SetRandSeed()
{
	srand(time(NULL) );
}
void cGenetic::CreateRandomPopulation()
{
	UINT	no ;
	vector<int> genes ;

	while(m_Population.size() < m_iPopSize)
	{
		genes.clear() ;

		for(UINT i=0;i<m_iGenomeLength;i++)
		{
			no = (rand() % m_iMaxNo) + 1 ;
			while(CheckForDuplicateNo(no, genes))
			{
				no = (rand() % m_iMaxNo) + 1 ;
			}
			genes.push_back(no) ;
		}
		m_Population.push_back(Genome(genes)) ;
	}
}
void cGenetic::FindSolution()
{
	vector <Genome>		NewPopulation ;
	Genome				Father,
						Mother ;

	//for(UINT i=0;i<m_iMaxGenerations;i++)
	UINT i=0 ;
	while(1)
	{
		i++;
		CalculateFitness() ;
		if(m_bSolutionFound)
		{
			m_iFoundinGenNo = i ;
			break ;
		}
		
		while(NewPopulation.size() < m_iPopSize)
		{
			Father = Selection() ;
			Mother = Selection() ;
			
			CrossOver((Father.genes), (Mother.genes)) ;
			//Father = son ; Mother = Daughter after Crossover

			Mutate(Father.genes) ;
			Mutate(Mother.genes) ;

			NewPopulation.push_back(Father) ;
			NewPopulation.push_back(Mother) ;
		}

		m_Population = NewPopulation ;
		NewPopulation.clear() ;
		
	}
}

void cGenetic::CalculateFitness()
{
	
	vector<Genome>::iterator	itr_gen ;
	int							rowDiff,
								colDiff,
								totalDiff ;

	for(itr_gen=m_Population.begin();itr_gen!=m_Population.end();itr_gen++)
	{
		rowDiff = CalculateRowTotal(itr_gen->genes) ;
		colDiff = CalculateColTotal(itr_gen->genes) ;
		totalDiff = rowDiff + colDiff ;

		if(totalDiff == 0)
		{
			m_Solution = *itr_gen ;
			m_bSolutionFound = true ;
			break ;
		}
		else
		{
			itr_gen->ffitness = 1.0f/totalDiff ;
		}

	}

}

int cGenetic:: CalculateRowTotal(vector<int> values)
{
	int		result,
			total = 0 ;

	for(UINT row=0;row<m_iRowSize;row++)
	{
		result = 0;

		for (UINT box=0;box<m_iColSize;box++)
		{
			result += values[row*m_iRowSize + box];
		}

		//Add the difference between the target and result for this row.
		total += abs(m_iTarget - result);
	}
	return total ;
}

int cGenetic:: CalculateColTotal(vector<int> values)
{
	int		result,
			total = 0 ;

	for(UINT col=0;col<m_iColSize;col++)
	{
		result = 0;

		for (UINT box=0;box<m_iRowSize;box++)
		{
			result += values[box*m_iRowSize + col];
		}
		total += abs(m_iTarget - result);
	}
	return total ;
}
Genome cGenetic::Selection()
{
	float	fTotalfitness = 0.0f,
			fball,
			fPie = 0.0f ;

	vector<Genome>::iterator	itr_gen ;

	for(itr_gen = m_Population.begin();itr_gen<m_Population.end();itr_gen++)
	{
		fTotalfitness += itr_gen->ffitness ;
	}
	fball = (rand()/(RAND_MAX+1.0f)) * fTotalfitness ;
	for(itr_gen = m_Population.begin();itr_gen<m_Population.end();itr_gen++)
	{
		fPie += itr_gen->ffitness ;
		if(fball < fPie)
		{
			return *itr_gen ;
		}
	}
}

void cGenetic::CrossOver(vector<int> &Father, vector<int> &Mother)
{
	float		fRand ;
	UINT		iRandPos,
				iPos ;
	vector<int>	daughter,
				son,
				tempgenes,
				genepos ;

	fRand = rand()/(RAND_MAX + 1.0f) ;
	son = Father ;
	daughter = Mother ;

	if(fRand>m_iCrossoverRate || Father == Mother)
	{
		return ;
	}
	iRandPos = (rand() % (m_iGenomeLength-1)) ;

	while(iRandPos < m_iGenomeLength)
	{
		genepos.push_back(iRandPos) ;
		tempgenes.push_back(Mother[iRandPos]) ;
		iRandPos += (rand() % (m_iGenomeLength - 3)) + 1 ;
	}
	iPos = 0 ;
	for(UINT i=0;i<m_iGenomeLength;i++)
	{
		for(UINT j=0; j<tempgenes.size();j++)
		{
			if(son[i] == tempgenes[j])
			{
				son[i] = tempgenes[iPos] ;
				iPos++ ;
				break ;
			}
		}
		if(iPos == tempgenes.size())
		{
			break ;
		}
	}
	tempgenes.clear() ;
	iPos = 0 ;

	for(UINT i=0;i<genepos.size();i++)
	{
		tempgenes.push_back(Father[genepos[i]]) ;
	}

	for(UINT i=0;i<m_iGenomeLength;i++)
	{
		for(UINT j=0; j<tempgenes.size();j++)
		{
			if(daughter[i] == tempgenes[j])
			{
				daughter[i] = tempgenes[iPos] ;
				iPos++ ;
				break ;
			}
		}
		if(iPos == tempgenes.size())
		{
			break ;
		}
	}
	Mother = daughter ;
	Father = son ;
}

void cGenetic::Mutate(vector<int> &gene)
{
	float					fRand ;
	vector<int>::iterator	CurrPos ;
	int						CurrVal ;

	fRand = rand()/(RAND_MAX + 1.0f) ;

	if(fRand>m_iMutationRate)
	{
		return ; 
	}
	CurrPos = gene.begin() + (rand()% (m_iGenomeLength - 2)) ;
	CurrVal = *CurrPos ;
	gene.erase(CurrPos) ;
	CurrPos = gene.begin() + (rand()% (m_iGenomeLength - 2)) ;
	gene.insert(CurrPos, CurrVal) ;
}

void cGenetic::PrintSolution()
{
	  if (m_bSolutionFound)
    {
        cout << "Solution found in " << m_iFoundinGenNo << " generations.\n\n";
		//vector<int> values = ParseGenes(m_Solution);

		for (UINT val = 0; val < m_iGenomeLength; ++val)
		{
			cout << m_Solution.genes[val] ;
			if (val % m_iColSize == m_iColSize - 1)
			{
				cout << "\n\n" ;
			}
			else
			{
				cout << "\t";
			}
		}
    }
    else
    {
		cout << "No solution found in " << m_iMaxGenerations << " generations.\n\n";
    }
}

BOOL cGenetic::CheckForDuplicateNo(const UINT no, const vector<int> gene)
{
	for(UINT i=0;i<gene.size();i++)
	{
		if(no == gene[i]) 
		{
			return true ;
		}
	}
	return false ;
}