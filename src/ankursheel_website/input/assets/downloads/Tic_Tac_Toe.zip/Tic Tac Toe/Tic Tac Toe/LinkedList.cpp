
#include "LinkedList.h"

template <class DataType>
cList<DataType>::cList()
{
	m_phead = NULL ;
	m_ptail = NULL ;
	m_iTotalLinks = 0 ;
}

template <class DataType>
cList<DataType>::~cList()
{
	EmptyList() ;
}
template <class DataType>
bool cList<DataType>::IsEmpty()
{
	if(m_phead)
	{
		return false ;
	}
	return true ;
}

template <class DataType>
void cList<DataType>::Push(const DataType &data, const Side side)
{
	cLink<DataType> *Current = new cLink<DataType> ;
	Current->Data = data ;
	m_iTotalLinks++ ;
	switch side
	{
	case Left:
		Current->LtLink = NULL ;
		Current->RtLink = m_phead ;
		m_phead = Current ;
		break ;

	case Right:
		Current->LtLink = m_ptail ;
		Current->RtLink = NULL ;
		m_ptail= Current ;
	}

	if(IsEmpty())
	{
		//Current->LtLink = NULL ;
		//Current->RtLink = NULL ;
		m_phead = Current ;
		m_ptail = Current ;
	}
}

template <class DataType>
DataType cList<DataType>::Pop(Side side)
{	
	cLink<DataType> *Current = NULL ;
	DataType		data ;

	if(IsEmpty())
	{
		//error msg
		printf("No elements to pop\n") ;
		exit() ;
	}

	m_iTotalLinks-- ;

	switch side
	{
	case Left:
		Current = m_phead ;
		data = m_phead->Data ;
		m_phead = m_phead->RtLink ;
		m_phead->LtLink = NULL ;
		SAFE_DELETE(Current) ;

		break ;

	case Right:
		Current = m_ptail ;
		data = m_ptail->Data ;
		m_ptail = m_ptail->LtLink ;
		m_ptail->RtLink = NULL ;
		SAFE_DELETE(Current) ;
	}
	return data ;
}

template <class DataType>
void cList<DataType>::EmptyList()
{
	while(m_iTotalLinks >0)
	{
		Pop(Left) ;
	}
}