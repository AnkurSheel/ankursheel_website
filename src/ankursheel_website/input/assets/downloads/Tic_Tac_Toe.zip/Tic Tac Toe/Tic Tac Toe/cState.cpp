#include "cState.h"

cState::cState()
{
	for(int i=0;i<BOARD_SQUARES;i++)
	{
		m_Board[i] = ' ' ;
	}
	m_WhoseMove = Human ;
	m_Score = 0 ;
	m_movePosition =0 ;
}

cState::cState(cState &State)
{
	*this = State ;
	m_Score = State.GetScore() ;
	m_WhoseMove = State.getWhoseMove() ;
	m_movePosition = State.GetMovePosition() ;
}

cState::~cState()
{
}

void cState::Move(int position)
{
	m_movePosition = position ;
	switch(m_WhoseMove)
	{
	case Human:
		m_Board[position] = 'O' ;
		//m_WhoseMove = Computer ;
		break ;
	case Computer:
		m_Board[position] = 'X' ;
		//m_WhoseMove = Human ;
		break ;
	}
}

bool cState::IsMoveLegal(const int position)
{
	if(m_Board[position] == ' ')
	{
		return true ;
	}
	return false ;
}

Player cState::getWhoseMove()
{
	return m_WhoseMove ;
}
void cState::SetWhoseMove(Player player)
{
	m_WhoseMove = player ;
}

int cState::CheckScore()
{
	if(IsWin()) 
	{
		if(m_WhoseMove == ComputerWinScore)
		{
			m_Score = ComputerWinScore;
		}
		else
		{
			m_Score = HumanWinScore;
		}
	}
	else
	{
		if(IsDraw())
		{
			m_Score = DrawScore ;
		}
	}
	return m_Score ;
}

bool cState::IsDraw()
{
	bool	bIsDraw = true ;

	for(int n=0; n<BOARD_SQUARES; n++) 
	{
		if(m_Board[n] == ' ') 
		{ 
			bIsDraw = false ;
			break ;
		}
	}
	return bIsDraw ;
}
bool cState::IsWin()
{
	if(((m_Board[0] == m_Board[1]) && (m_Board[1] == m_Board[2]) && (m_Board[2] != ' ')) ||
	   ((m_Board[3] == m_Board[4]) && (m_Board[4] == m_Board[5]) && (m_Board[5] != ' ')) ||
	   ((m_Board[6] == m_Board[7]) && (m_Board[7] == m_Board[8]) && (m_Board[8] != ' ')) ||
	   ((m_Board[0] == m_Board[3]) && (m_Board[3] == m_Board[6]) && (m_Board[6] != ' ')) ||
	   ((m_Board[1] == m_Board[4]) && (m_Board[4] == m_Board[7]) && (m_Board[7] != ' ')) ||
	   ((m_Board[2] == m_Board[5]) && (m_Board[5] == m_Board[8]) && (m_Board[8] != ' ')) ||
	   ((m_Board[0] == m_Board[4]) && (m_Board[4] == m_Board[8]) && (m_Board[8] != ' ')) ||
	   ((m_Board[2] == m_Board[4]) && (m_Board[4] == m_Board[6]) && (m_Board[6] != ' ')) 
	   )
	{
		return true ;
	}
	return false ;
}

int cState::GetScore()
{
	return m_Score ;
}
void cState::SetScore(int score)
{
	m_Score = score ;
}

int cState::GetMovePosition()
{
	return m_movePosition ;
}

void cState::SetMovePosition(int pos)
{
	m_movePosition = pos ;
}

char *cState::GetBoard()
{
	return m_Board ;
}