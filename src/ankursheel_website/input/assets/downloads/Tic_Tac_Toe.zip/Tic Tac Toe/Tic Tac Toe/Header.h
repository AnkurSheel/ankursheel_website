#pragma once

#include <stdio.h>
#include <windows.h>
#include <crtdbg.h>

#define new DEBUG_CLIENTBLOCK
#define DEBUG_CLIENTBLOCK new( _CLIENT_BLOCK, __FILE__, __LINE__)

#define SAFE_DELETE(p){ if(p) { delete (p) ; (p)=NULL ; } }

enum Side {Left, Right} ;

enum Player{Human, Computer} ;

enum Marker{Empty, X, O} ;

const int	MAXDEPTH  = 12 ;
const int	BOARD_SQUARES = 9 ;

const int	HumanWinScore = -100 ;
const int	DrawScore = 50 ;
const int	ComputerWinScore = 100 ;