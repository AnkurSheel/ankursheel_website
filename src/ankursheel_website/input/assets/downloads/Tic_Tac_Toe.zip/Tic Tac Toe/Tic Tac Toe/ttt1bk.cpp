#include "ttt.h"

void main()
{
	CheckForMemoryLeaks()  ;

	char play ;
	int  pos ;
	cState		*ActualState  = new cState ;
	
	system("cls") ;
	do
	{
		printf(" Who will play first Human(H) or Computer(C)   :") ;
		scanf("%c", &play) ;
	}
	while(play != 'H' && play != 'h' && play != 'C' && play != 'c') ;
	switch(play)
	{
	case 'H':
	case 'h':
		ActualState->SetWhoseMove(Human) ;
		break ;
	case 'C':
	case 'c':
		ActualState->SetWhoseMove(Computer) ;
		break ;
	}
	PrintBoard(ActualState) ;
	do
	{
		system("cls") ;
		PrintBoard(ActualState) ;
		if(ActualState->getWhoseMove() == Human)
		{
			do			
			{
				printf("\nEnter position   :") ;
				scanf("%d", &pos) ;
			}
			while(!ActualState->IsMoveLegal(pos)) ;
			ActualState->Move(pos) ;
			ActualState->SetWhoseMove(Computer) ;
		}
		else
		{
			MinMax(*ActualState,0,Computer) ;
			pos = ActualState->GetMovePosition() ;
			printf("\nMoving to position  :%d", pos) ;
			ActualState->Move(pos) ;
			ActualState->SetWhoseMove(Human) ;
		}
	}
	while(!ActualState->IsWin() && !ActualState->IsDraw()) ;

	//ActualState->Move(0) ;
	//ActualState->SetWhoseMove(Computer) ;
	//MinMax(*ActualState,1,Computer) ;
	//ActualState->Move(ActualState->GetMovePosition()) ;
	//ActualState->SetWhoseMove(Human) ;
	//ActualState->Move(4) ;

	//ActualState->SetWhoseMove(Computer) ;
	//MinMax(*ActualState,1,Computer) ;
	//ActualState->Move(ActualState->GetMovePosition()) ;
	//ActualState->SetWhoseMove(Human) ;
	//ActualState->Move(1) ;

	//ActualState->SetWhoseMove(Computer) ;
	//MinMax(*ActualState,1,Computer) ;
	//ActualState->Move(ActualState->GetMovePosition()) ;
	//ActualState->SetWhoseMove(Human) ;
	//ActualState->Move(2) ;

	//ActualState->SetWhoseMove(Computer) ;
	//MinMax(*ActualState,1,Computer) ;
	//ActualState->Move(ActualState->GetMovePosition()) ;
	system("cls") ;
	PrintBoard(ActualState) ;
	SAFE_DELETE(ActualState);
}

void CheckForMemoryLeaks() 
{
#ifdef	_DEBUG
	// Get Current flag
	int flag = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG) ; 
	// Turn on leak-checking bit
	flag |= (_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF) ; 
	// Set flag to the new value
	_CrtSetDbgFlag(flag) ; 

#endif	_DEBUG
}
cState NegaMax(cState &State, const int CurrentDepth, const Player player)
{
	int				iBestScore = HumanWinScore - 1,
					iTemp,
					iNoofChildren = 0,
					iResultScore,
					iBestposition = -1 ;
	Player			nextPlayer ;
	cState			*CurrentState = NULL, 
					*resultState  = NULL ;
	cList<cState>	List ;
	//cList<cState>	Path ;

	if(CurrentDepth == MAXDEPTH)
	{
		State.CheckScore() ;
		return State ;
	}

	// check if game has ended
	if(State.IsWin() || State.IsDraw())
	{
		State.CheckScore() ;
		return State ;
	}


//	Path.Push(State, Right) ;
	List.Push(State, Right) ;

	// generate the tree
	for(int i=0;i<BOARD_SQUARES;i++)
	{
		CurrentState = new cState(State) ;
		CurrentState->SetWhoseMove(player) ;

		if(CurrentState->IsMoveLegal(i))
		{
			CurrentState->Move(i) ;
			//CurrentState->SetMovePosition(i) ;
			List.Push(*CurrentState, Right) ;
			iNoofChildren++ ;
		}
		SAFE_DELETE(CurrentState) ;
	}

	//get the next player
	switch(player)
	{
	case Computer:
		nextPlayer = Human ;
		//iBestScore = HumanWinScore - 1 ;
		break;
	case Human:
		nextPlayer = Computer ;
		//iBestScore = ComputerWinScore + 1 ;
		break ;
	}
	List.PeekNext(Left) ;

	for(int i=0;i<iNoofChildren;i++)
	{
		cState *temp = new cState(List.PeekNext(Left)) ;
		resultState = new cState(MinMax(*temp, CurrentDepth+1, nextPlayer)) ;
		//iResultScore = -(resultState->CheckScore()) ;
		iResultScore = -resultState->GetScore() ;
		if(iResultScore > iBestScore)
		{
			iBestposition = temp->GetMovePosition() ;
			iBestScore = iResultScore ;
		}

		//if(State.getWhoseMove() == Human)
		////if(nextPlayer == Computer)
		//{
		//	if(iResultScore > iMinScore)
		//	{
		//		iMinScore = iResultScore ;
		//		iBestScore = iResultScore ;
		//		iBestposition = temp->GetMovePosition() ;
		//	}
		//}
		//else
		//{
		//	if(iResultScore < iMaxScore)
		//	{
		//		iMaxScore = iResultScore ;
		//		iBestScore = iResultScore ;
		//		iBestposition = temp->GetMovePosition() ;
		//	}
		//}
		SAFE_DELETE(temp) ;
		SAFE_DELETE(resultState) ;
	}
	//List.PeekNext(Left) ;
	List.EmptyList() ;
	State.SetScore(iBestScore) ;
	if(CurrentDepth == 0)
	{
		State.SetMovePosition(iBestposition) ;
	}
	return State ;

}

cState NegaMax(cState &State, const int CurrentDepth, const Player player, int alpha, int beta)
{
	int				iBestScore = HumanWinScore - 1,
					iTemp,
					iNoofChildren = 0,
					iResultScore,
					iBestposition = -1 ;
	Player			nextPlayer ;
	cState			*CurrentState = NULL, 
					*resultState  = NULL ;
	cList<cState>	List ;
	//cList<cState>	Path ;

	if(CurrentDepth == MAXDEPTH)
	{
		State.CheckScore() ;
		return State ;
	}

	// check if game has ended
	if(State.IsWin() || State.IsDraw())
	{
		State.CheckScore() ;
		return State ;
	}


//	Path.Push(State, Right) ;
	List.Push(State, Right) ;

	// generate the tree
	for(int i=0;i<BOARD_SQUARES;i++)
	{
		CurrentState = new cState(State) ;
		CurrentState->SetWhoseMove(player) ;

		if(CurrentState->IsMoveLegal(i))
		{
			CurrentState->Move(i) ;
			//CurrentState->SetMovePosition(i) ;
			List.Push(*CurrentState, Right) ;
			iNoofChildren++ ;
		}
		SAFE_DELETE(CurrentState) ;
	}

	//get the next player
	switch(player)
	{
	case Computer:
		nextPlayer = Human ;
		//iBestScore = HumanWinScore - 1 ;
		break;
	case Human:
		nextPlayer = Computer ;
		//iBestScore = ComputerWinScore + 1 ;
		break ;
	}
	List.PeekNext(Left) ;

	for(int i=0;i<iNoofChildren;i++)
	{
		cState *temp = new cState(List.PeekNext(Left)) ;
		resultState = new cState(MinMax(*temp, CurrentDepth+1, nextPlayer)) ;
		//iResultScore = -(resultState->CheckScore()) ;
		iResultScore = -resultState->GetScore() ;
		if(iResultScore > iBestScore)
		{
			iBestposition = temp->GetMovePosition() ;
			iBestScore = iResultScore ;
		}

		//if(State.getWhoseMove() == Human)
		////if(nextPlayer == Computer)
		//{
		//	if(iResultScore > iMinScore)
		//	{
		//		iMinScore = iResultScore ;
		//		iBestScore = iResultScore ;
		//		iBestposition = temp->GetMovePosition() ;
		//	}
		//}
		//else
		//{
		//	if(iResultScore < iMaxScore)
		//	{
		//		iMaxScore = iResultScore ;
		//		iBestScore = iResultScore ;
		//		iBestposition = temp->GetMovePosition() ;
		//	}
		//}
		SAFE_DELETE(temp) ;
		SAFE_DELETE(resultState) ;
	}
	//List.PeekNext(Left) ;
	List.EmptyList() ;
	State.SetScore(iBestScore) ;
	if(CurrentDepth == 0)
	{
		State.SetMovePosition(iBestposition) ;
	}
	return State ;

}

void PrintBoard(cState *State)
{
	char *temp = State->GetBoard() ;
	for(int i=0;i<BOARD_SQUARES;i++)
	{
		printf(" %c",temp[i]) ;
		if(((i+1)%3) ==0)
		{
			printf("\n") ;
		}
		else
		{
			printf(" :") ;
		}
	}
	//Sleep(3000) ;
	//SAFE_DELETE(temp) ;
}
