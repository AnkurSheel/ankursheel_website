#pragma once

#include "header.h"
#include "cState.h"
#include "LinkedList.h"

void CheckForMemoryLeaks()  ;
cState NegaMax(cState &State, const int CurrentDepth, const Player player, int alpha, int beta) ;
cState NegaMax(cState &State, const int CurrentDepth, const Player player) ;
void PrintBoard(cState *State) ;