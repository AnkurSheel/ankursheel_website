#pragma once

#include "header.h"
#include "cState.h"

// Link structure
template <class DataType> 
struct cLink 
{
	cLink<DataType> *LtLink ;
	cLink<DataType> *RtLink ;
	DataType        Data ;
} ;

//List Structure
template <class DataType> 
class cList
{
protected:
	cLink<DataType>		*m_phead ;
	cLink<DataType>		*m_ptail ;
	UINT				m_iTotalLinks ;
	cLink<DataType>		*m_NextLinktoAccess ;

public:
	cList() ;
	~cList() ;
	void Push(const DataType &data, const Side side) ;
	DataType Pop(Side side) ;
	void EmptyList() ;
	bool IsEmpty() ;
	DataType PeekNext(Side side) ;
	//BOOL IsFull() ;
} ;



template <class DataType>
cList<DataType>::cList()
{
	m_phead = NULL ;
	m_ptail = NULL ;
	m_NextLinktoAccess = NULL ;
	m_iTotalLinks = 0 ;
}

template <class DataType>
cList<DataType>::~cList()
{
	EmptyList() ;
	m_NextLinktoAccess = NULL ;

}
template <class DataType>
bool cList<DataType>::IsEmpty()
{
	if(m_phead)
	{
		return false ;
	}
	return true ;
}

template <class DataType>
void cList<DataType>::Push(const DataType &data, const Side side)
{
	cLink<DataType> *Current = new cLink<DataType> ;

	Current->Data = data ;
	m_iTotalLinks++ ;
	if(IsEmpty())
	{
		m_phead = Current ;
		m_ptail = Current ;
		m_NextLinktoAccess = Current ;
	}
	switch (side)
	{
	case Left:
		m_phead->LtLink = Current ;
		Current->LtLink = NULL ;
		Current->RtLink = m_phead ;
		m_phead = Current ;
		break ;

	case Right:
		m_ptail->RtLink = Current ;
		Current->LtLink = m_ptail ;
		Current->RtLink = NULL ;
		m_ptail= Current ;
	}
}

template <class DataType>
DataType cList<DataType>::Pop(Side side)
{	
	cLink<DataType> *Current = NULL ;
	DataType		data ;

	if(IsEmpty())
	{
		//error msg
		printf("No elements to pop\n") ;
		exit(0) ;
	}

	m_iTotalLinks-- ;

	switch (side)
	{
	case Left:
		Current = m_phead ;
		data = m_phead->Data ;
		m_phead = m_phead->RtLink ;
		if(m_phead)
		{
			m_phead->LtLink = NULL ;
		}
		SAFE_DELETE(Current) ;

		break ;

	case Right:
		Current = m_ptail ;
		data = m_ptail->Data ;
		m_ptail = m_ptail->LtLink ;
		if(m_ptail)
		{
			m_ptail->RtLink = NULL ;
		}
		SAFE_DELETE(Current) ;
	}
	return data ;
}

template <class DataType>
void cList<DataType>::EmptyList()
{
	while(m_iTotalLinks >0)
	{
		Pop(Left) ;
	}
}

template <class DataType>
DataType cList<DataType>::PeekNext(Side side)
{	
	DataType		data ;

	if(IsEmpty())
	{
		//error msg
		printf("No elements to peek\n") ;
		exit(0) ;
	}
	data = m_NextLinktoAccess->Data ;
	switch (side)
	{
	case Left:
		
		m_NextLinktoAccess = m_NextLinktoAccess->RtLink ;
		break ;

	case Right:
		m_NextLinktoAccess = m_NextLinktoAccess->LtLink ;
		break ;
	}
	return data ;
}