#pragma once

#include "header.h"

class cState
{
protected:
	char	m_Board[BOARD_SQUARES] ;
	Player	m_WhoseMove ;
	int		m_Score ;
	int		m_movePosition ;
public:
	cState() ;
	cState(cState &State) ;
	~cState() ;
	void Move(const int position) ;
	bool IsMoveLegal(const int position) ;
	Player getWhoseMove() ;
	void SetWhoseMove(Player player) ;
	int CheckScore() ;
	int GetScore() ;
	bool IsDraw() ;
	bool IsWin() ;
	void SetScore(int score) ;
	int GetMovePosition() ;
	void SetMovePosition(int pos) ;
	char *GetBoard() ;


} ;