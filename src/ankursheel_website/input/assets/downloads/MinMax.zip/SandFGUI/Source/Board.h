#pragma once 

class cBoard
{
	bool			m_bGameFinished ; // variable to check if game has finished 

	BITBOARD		m_iBoard,  // the bitboard for the board
					m_iMaleFrogs, // the bitboard for the Male Frogs
					m_iFemaleFrogs, // the bitboard for the Female Frogs
					m_iBabyFrogs, // the bitboard for the Baby Frogs
					m_iSnake, // the bitboard for the snake
					m_iBlocks, // the bitboard for the blocks/stones
					m_iBurrows ; // the bitboard for the Burrows
#ifdef JavaVersion2
	BITBOARD		m_iSnakeMoveBitboard ;  // the bitboard for the square that the snake can move to
#endif
				//m_iFrogs, // the bitboard for all the frogs
				//m_iAdultFrogs, // the bitboard for all the frogs
				//m_iSquaresAttackedBySnake ;// the bitboard for the Squares Attacked by White

	Directions		m_SnakeDir ;
	SnakePosition	m_SnakePos ;

	int				m_iSnakeHeadPos, // the square no. at which the head of the snake is
					m_iNoOfMaleFrogsToBeEaten, // the total no. of male frogs to be eaten
					m_iNoOfFemaleFrogsToBeEaten, // the total no. of female frogs to be eaten
					m_iNoOfBabyFrogsToBeEaten, // the total no. of Baby frogs to be eaten
					m_iNoOfBabyFrogsToBeProduced, // the total no. of baby frogs yet to be produced on the board
					m_iNoOfBabyFrogsProduced, // the total no. of baby frogs produced on the board
					m_iNoOfMaleFrogsEaten, // the total no. of male frogs eaten
					m_iNoOfFemaleFrogsEaten, // the total no. of female frogs eaten
					m_iNoOfBabyFrogsEaten, // the total no. of Baby frogs eaten
					m_iNoOfBabyFrogsToBeProtected ;// the total no. of Baby frogs to be protected

	void UpdateSnakeBitboard(const MOVE &move) ;
	void AddBabytoBitboard(const MOVE &move) ;
	void ConvertPosToBitboard(const vector<int> &pTemp, BITBOARD &pElement) ;

public:
	cBoard() ;
	~cBoard() ;
	void UpdateBoard(const MOVE &move) ;
	//void DisplayBoard() ;
	BITBOARD GetBoardBitBoard() ;
	BITBOARD GetMaleFrogBitboard() ;
	BITBOARD GetFemaleFrogBitboard() ;
	BITBOARD GetBabyFrogBitboard() ;
	BITBOARD GetSnakeBitboard() ;
	BITBOARD GetBurrowsBitBoard() ;
	BITBOARD GetBlocksBitBoard() ;
	//BITBOARD GetFrogsBitboard() ;
	//BITBOARD GetAdultFrogBitboard() ;
	Directions	GetSnakeDirection() ;
	SnakePosition GetSnakePosition() ;
	int GetSnakeHeadPosition() ;
	PieceTypes GetPieceType(const int isquareNo) ;
	bool CheckIfSnakeTailPosValid(const int iSnakeHeadPos, const int iSnakeTailPos) ;
	int GetNoOfMaleFrogsToBeEaten() ;
	int GetNoOfFemaleFrogsToBeEaten() ;
	int GetNoOfBabyFrogsToBeEaten() ;
	int GetNoOfMaleFrogsEaten() ;
	int GetNoOfFemaleFrogsEaten() ;
	int GetNoOfBabyFrogsEaten() ;

	int GetNoOfBabyFrogsToBeProduced() ;
	int GetNoOfBabyFrogsProduced() ;
	void SetupBoard(const vector<int> &vMaleFrog, const vector<int> &vFemaleFrog, const vector<int> &vBabyFrog, const vector<int> &vMaleFemaleFrog, const vector<int> &vSnake, const vector<int> &vBurrows, const vector<int> &vBlocks, const SnakePosition SnakePos, const Directions SnakeDir, const int iSnakeHeadPosition) ;
	
	void SetGoals(const int iBabyFrogsToBeProduced, const int iMaleFrogsToBeEaten, const int iFemaleFrogsToBeEaten, const int iBabyFrogsToBeEaten, const int iMaleFrogsEaten, const int iFemaleFrogsEaten, const int iBabyFrogsEaten, const int iBabyFrogsProduced, const int iBabyFrogsToBeProtected) ;
	void GetSnakeTailPos(const int iSnakeHeadPos, const Directions SnakeDir, int &iSnakeTailPos) ;
	bool CheckifTopRow(const int iSquareNo) ;
	bool CheckifBottomRow(const int iSquareNo) ;
	bool CheckifFirstCol(const int iSquareNo) ;
	bool CheckifLastCol(const int iSquareNo) ;
} ;