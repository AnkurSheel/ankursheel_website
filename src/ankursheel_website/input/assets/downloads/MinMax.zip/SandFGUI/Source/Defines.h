#pragma once 

#define NULLCHAR '\0'
#define SAFE_DELETE(p){ if(p) { delete (p) ; (p)=NULL ; } }
#define SAFE_DELETE_ARRAY(p){ if(p) { delete [] p ; p = NULL ;} }
#define MAX_STR_LEN 1024
#define	MAXDEPTH 2


//#define JavaEngine // comment this for PC version
//#define JavaVersion1 // comment this if new negamax does not work ; for new move generation
#define JavaVersion2
#define TestEngine // comment this for playable version

typedef UINT64 BITBOARD ;

typedef struct {
	int				from  ;
	int				to ;
	MoveTypes		mvType ;
	PieceTypes		pcType ;
	int				newBabyPosition ;
	Directions		SnakeDir ;
	SnakePosition	SnakePos ;
	PieceTypes		attackedPcType ;
#ifdef TestEngine
	int				depth ;
	int				score ;
#endif
	//BITBOARD		iMaleFrogsBoard ; 
	//BITBOARD		iFemaleFrogsBoard ;
	//BITBOARD		iBabyFrogsBoard ;
	//BITBOARD		iSnakeBoard ;
	//int				iSnakeHeadPos ;
	//int				iSnakeTailPos ;
	//int				iNoOfMaleFrogsToBeEaten ; // the total no. of male frogs to be eaten
	//int				iNoOfFemaleFrogsToBeEaten ; // the total no. of female frogs to be eaten
	//int				iNoOfBabyFrogsToBeEaten ; // the total no. of Baby frogs to be eaten
	//int				iNoOfBabyFrogsToBeProduced ; // the total no. of baby frogs yet to be produced on the board
	//int				iNoOfBabyFrogsProduced ; // the total no. of baby frogs produced on the board
	//int				iNoOfMaleFrogsEaten ; // the total no. of male frogs eaten
	//int				iNoOfFemaleFrogsEaten ; // the total no. of female frogs eaten
	//int				iNoOfBabyFrogsEaten ; // the total no. of Baby frogs eaten
	//Directions	SnakeDir ;
} MOVE ;
//#else
//typedef struct {
//	int			from  ;
///	int			to ;
//	MoveTypes	mvType ;
//	PieceTypes	pcType ;
//	int			newBabyPosition ;
//	Directions	SnakeDir ;
//	SnakePosition SnakePos ;
//	PieceTypes  attackedPcType ;
//} MOVE ;
