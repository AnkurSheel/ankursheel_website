#pragma once

#include "stdafx.h"

template <class DataType>
void QuickSortAscending(DataType *dataArray, int lowIndex, int hiIndex)
{
	int			i = lowIndex, 
				j = hiIndex ;  
				
	DataType	temp,
				midVal = dataArray[(lowIndex+hiIndex)/2] ;

	//  partition
	do
	{    
		while (dataArray[i] < midVal)
		{
			i++ ; 
		}
		while (dataArray[j] > midVal)
		{
			j-- ;
		}
		if (i <= j)
		{
			temp = dataArray[i] ; 
			dataArray[i] = dataArray[j] ;
			dataArray[j] = temp ;
			i++ ;
			j-- ;
		}
	} 
	while (i<=j) ;

	//  recursion
	if (lowIndex < j)
	{
		qsort(dataArray, lowIndex, j) ;
	}
	if (i < hiIndex) 
	{
		qsort(dataArray, i, hiIndex) ;
	}
}

template <class DataType1, class DataType2>
void QuickSortVectorAscending(vector<DataType1> &dataArray, int lowIndex, int hiIndex, DataType2 SortingParam)
{
	int			i = lowIndex, 
				j = hiIndex ;  
	DataType1	temp,
				midVal = dataArray.at((lowIndex+hiIndex)/2) ;

	//  partition
	do
	{    
		while (dataArray.at(i)<x)
		{
			i++ ; 
		}
		while (dataArray.at(j)>x)
		{
			j-- ;
		}
		if (i<=j)
		{
			//a.swap(a.at(i), a.at(j)) ;
			temp=dataArray.at(i) ; 
			dataArray.at(i) = dataArray.at(j) ;
			dataArray.at(j) = temp ;
			i++ ;
			j-- ;
		}
	} 
	while (i<=j) ;

	//  recursion
	if (lowIndex<j)
	{
		qsort(dataArray, lowIndex, j) ;
	}
	if (i<hiIndex) 
	{
		qsort(dataArray, i, hiIndex) ;
	}
}