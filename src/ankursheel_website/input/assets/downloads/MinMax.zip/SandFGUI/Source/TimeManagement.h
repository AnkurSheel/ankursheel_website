#pragma once
#include <windows.h>

class CTimeManagement
{
	static double		dFrequencyToCounterRatio ;
	static __int64		i64Start, i64End ;

public:
	static BOOL Calibrate()
	{
		__int64		li ;

		if(!QueryPerformanceFrequency((LARGE_INTEGER*)&li))
		{
			return FALSE ;	// caller should report error
		}

		dFrequencyToCounterRatio = double(li) ;
		return TRUE ;
	}

	static void Start() 
	{
		QueryPerformanceCounter((LARGE_INTEGER *)&i64Start) ;
	}

	static void Stop() 
	{
		QueryPerformanceCounter((LARGE_INTEGER *)&i64End) ;
	}

	// Returns elapsed time in seconds
	static const float Elapsed()
	{
		const __int64		i64Difference = i64End - i64Start ;
		return (float)(double(i64Difference) / dFrequencyToCounterRatio) ;
	}

	// Returns elapsed time in milliseconds
	static const float Elapsedms()
	{
		const __int64		i64Difference = i64End - i64Start ;
		return (float)((double(i64Difference) * 1000.0) / dFrequencyToCounterRatio) ;
	}
} ;