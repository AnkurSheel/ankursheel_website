#include "stdafx.h"
#include "Board.h"

//default constructor
cBoard::cBoard()
{
	m_bGameFinished = false ; // game is not finished

	m_iBoard = 0x0 ;
	m_iMaleFrogs = 0x0 ;
	m_iFemaleFrogs = 0x0 ;
	m_iBabyFrogs = 0x0 ;
	m_iSnake = 0x0 ;
	m_iBurrows = 0x0 ;
	m_iBlocks = 0x0 ;
	//	m_iSquaresAttackedBySnake = 0x0 ;

	//	m_iAdultFrogs = m_iMaleFrogs | m_iFemaleFrogs ;
	//	m_iFrogs = m_iAdultFrogs | m_iBabyFrogs ;
	//m_iBoard = m_iMaleFrogs | m_iFemaleFrogs | m_iBabyFrogs | m_iSnake | m_iBurrows ;

	m_SnakeDir = DirNA ;
	m_SnakePos = OffBoard ;

	m_iSnakeHeadPos = 0 ;
	m_iNoOfMaleFrogsToBeEaten = 0 ;
	m_iNoOfFemaleFrogsToBeEaten = 0 ;
	m_iNoOfBabyFrogsToBeEaten = 0 ;
	m_iNoOfBabyFrogsToBeProduced = 0 ;
	m_iNoOfBabyFrogsProduced = 0 ;
	m_iNoOfMaleFrogsEaten = 0 ;
	m_iNoOfFemaleFrogsEaten = 0 ;
	m_iNoOfBabyFrogsEaten = 0 ;

}

//default destructor
cBoard::~cBoard()
{
}
//set the goals for the snake and the frog
void cBoard::SetGoals(const int iBabyFrogsToBeProduced, const int iMaleFrogsToBeEaten, const int iFemaleFrogsToBeEaten, const int iBabyFrogsToBeEaten,
					  const int iMaleFrogsEaten, const int iFemaleFrogsEaten, const int iBabyFrogsEaten, const int iBabyFrogsProduced, const int iBabyFrogsToBeProtected)
{
	/*
	int iBabyFrogsToBeProduced :  the no of baby frogs to be produced
	int iMaleFrogsToBeEaten : the no of male frogs to be eaten by the snake
	int iFemaleFrogsToBeEaten : the no of female frogs to be eaten by the snake
	int iBabyFrogsToBeEaten : the no of baby frogs to be eaten by the snake
	*/

	m_iNoOfBabyFrogsToBeProduced = iBabyFrogsToBeProduced ;
	m_iNoOfMaleFrogsToBeEaten = iMaleFrogsToBeEaten ;
	m_iNoOfFemaleFrogsToBeEaten = iFemaleFrogsToBeEaten ;
	m_iNoOfBabyFrogsToBeEaten = iBabyFrogsToBeEaten ;
	m_iNoOfMaleFrogsEaten = iMaleFrogsEaten ;
	m_iNoOfFemaleFrogsEaten = iFemaleFrogsEaten ;
	m_iNoOfBabyFrogsEaten = iBabyFrogsEaten ;
	m_iNoOfBabyFrogsProduced = iBabyFrogsProduced ;
	m_iNoOfBabyFrogsToBeProtected = iBabyFrogsToBeProtected ;
}
//setups the board
void cBoard::SetupBoard(const vector<int> &vMaleFrog, const vector<int> &vFemaleFrog, const vector<int> &vBabyFrog, const vector<int> &vMaleFemaleFrog, 
						const vector<int> &vSnake, const vector<int> &vBurrows, const vector<int> &vBlocks, const SnakePosition SnakePos, 
						const Directions SnakeDir, const int iSnakeHeadPosition)
{	
	/*
	vector<int> vMaleFrog : reference to vector containing the positions of male frogs
	vector<int> vFemaleFrog : reference to vector containing the positions of female frogs
	vector<int> vBabyFrog : reference to vector containing the positions of female frogs
	vector<int> vMaleFemaleFrog: reference to vector containing the positions of couple frogs
	vector<int> vSnake : reference to vector containing the positions of the snake
	vector<int> &vBurrows : reference to vector containing the positions of the burrows
	vector<int> &vBlocks : reference to vector containing the positions of the blocks
	SnakePosition SnakePos ; the position of the snake (OnBoard, InBurrow, OffBoard)
	Directions SnakeDir : the direction that the snake is facing
	int iSnakeHeadPosition : the sqaure no at which the head of the snake is 
	*/
	ConvertPosToBitboard(vMaleFrog, m_iMaleFrogs) ;
	ConvertPosToBitboard(vFemaleFrog, m_iFemaleFrogs) ;
	ConvertPosToBitboard(vBabyFrog, m_iBabyFrogs) ;
	ConvertPosToBitboard(vBurrows, m_iBurrows) ;
	ConvertPosToBitboard(vBlocks, m_iBlocks) ;
	ConvertPosToBitboard(vSnake, m_iSnake) ;
	ConvertPosToBitboard(vMaleFemaleFrog, m_iMaleFrogs) ;
	ConvertPosToBitboard(vMaleFemaleFrog, m_iFemaleFrogs) ;
	m_SnakeDir = SnakeDir ;
	m_SnakePos = SnakePos ;
	m_iSnakeHeadPos = iSnakeHeadPosition ;
	m_iBoard = m_iMaleFrogs | m_iFemaleFrogs | m_iBabyFrogs | m_iSnake | m_iBurrows | m_iBlocks ;
}

//Converts the vector of positions to the corresponding Bitboard
void cBoard::ConvertPosToBitboard(const vector<int> &pTemp, BITBOARD &pElement)
{
	/*
	vector<int> pTemp : reference to vector containing the positions that have to be converted
	BITBOARD &pElement : the bitboard that has to be generated
	*/
	int			iSize ; // the size of the vector
	BITBOARD	counter = 0x01 ;

	iSize = (int)pTemp.size() ;
	for(int i=0;i<iSize;++i)
	{
		counter = 0x1 ;
		counter = counter << pTemp.at(i) ;
		pElement = pElement | counter ;
	}
}
//returns the board bitboard
BITBOARD cBoard::GetBoardBitBoard()
{
	return m_iBoard ;
}

//returns the male frogs bitboard
BITBOARD cBoard::GetMaleFrogBitboard()
{
	return m_iMaleFrogs ;
}

//returns the female frogs bitboard
BITBOARD cBoard::GetFemaleFrogBitboard()
{
	return m_iFemaleFrogs ;
}

//returns the snakes bitboard
BITBOARD cBoard::GetSnakeBitboard()
{
	return m_iSnake ;
}

//returns the burrow bitboard
BITBOARD cBoard::GetBurrowsBitBoard()
{
	return m_iBurrows ;
}
//returns the blocks bitboard
BITBOARD cBoard::GetBlocksBitBoard()
{
	return m_iBlocks ;
}


//returns the baby frogs bitboard
BITBOARD cBoard::GetBabyFrogBitboard()
{
	return m_iBabyFrogs ;
}

//returns the Snake Direction
Directions cBoard::GetSnakeDirection()
{
	return m_SnakeDir ;
}

//returns the Snake Position
SnakePosition cBoard::GetSnakePosition()
{
	return m_SnakePos ;
}

//returns the square no at the which the head of the snake is
int cBoard::GetSnakeHeadPosition()
{
	return m_iSnakeHeadPos ;
}
//returns the piece at the the square no
PieceTypes cBoard::GetPieceType(const int isquareNo)
{
	/*
	int isquareNo : the square no currently being checked
	*/
	BITBOARD counter = 0x1 ;

	counter = counter <<isquareNo ;
	if (isquareNo == m_iSnakeHeadPos)
	{
		return Snake ;
	}
	if (((counter & m_iMaleFrogs) > 0)
		&& ((counter & m_iFemaleFrogs) > 0))
	{
		return Couples ;
	}
	if ((counter & m_iMaleFrogs) > 0)
	{
		return MaleFrogs ;
	}
	if ((counter & m_iFemaleFrogs) > 0)
	{
		return FemaleFrogs ;
	}
	if ((counter & m_iBabyFrogs) > 0)
	{
		return BabyFrogs ;
	}
	if ((counter & m_iBurrows) > 0)
	{
		return Burrow ;
	}
	if((counter & m_iBlocks) > 0)
	{
		return Blocks ;
	}
	return NoPiece ;
}
//Update the board after each move
void cBoard::UpdateBoard(const MOVE &move)
{
	/*
	MOVE move : the move that has been made, according to which the board is to be updated
	*/
	BITBOARD	newpos = 1, // to hold the bitboard of the topos
				prevpos = 1, // to hold the bitboard of the frompos
				NegNewPos  = 1, // to hold the complement of the newpos
				NegPrevPos  = 1 ; // to hold the complement of the prevpos

	newpos = newpos<<move.to ; // get bitboard for tosquare
	prevpos = prevpos<<move.from ;// get bitboard for fromsquare
	NegPrevPos = ~prevpos ; // negate the bitboard got for from square
	NegNewPos = ~newpos ;// negate the bitboard got for to square

	if (move.mvType == AttackMove)
	{
		if(move.attackedPcType == Couples || move.attackedPcType == MaleFrogs)
		{
			m_iMaleFrogs = m_iMaleFrogs & NegNewPos ; // remove the male frog from the board
			m_iNoOfMaleFrogsToBeEaten-- ;
			m_iNoOfMaleFrogsEaten++ ;
		}
		if(move.attackedPcType == Couples || move.attackedPcType == FemaleFrogs)
		{
			m_iFemaleFrogs = m_iFemaleFrogs & NegNewPos ; // remove the female frog from the board
			m_iNoOfFemaleFrogsToBeEaten-- ;
			m_iNoOfFemaleFrogsEaten++ ;
		}
		if (move.attackedPcType == BabyFrogs)
		{
			m_iBabyFrogs = m_iBabyFrogs & NegNewPos ; // remove the female frog from the board
			m_iNoOfBabyFrogsToBeEaten-- ;
			m_iNoOfBabyFrogsEaten++ ;
		}
	}
	else
	{
		if (move.mvType == ReproductionMove)// add the baby frog to the board
		{
			AddBabytoBitboard(move) ;
			m_iNoOfBabyFrogsToBeProduced-- ;
			m_iNoOfBabyFrogsProduced++ ;
		}
	}

	switch(move.pcType) // update the board 
	{
	case NoPiece:
		break ;
	case Snake:
		UpdateSnakeBitboard(move) ;
		m_SnakeDir = move.SnakeDir ;
		m_SnakePos = move.SnakePos ;

		m_iSnakeHeadPos = move.to ;
		break ;
	case MaleFrogs:
		m_iMaleFrogs = m_iMaleFrogs & NegPrevPos ;// remove the piece form prev position on the Male Frogs Bitboard
		m_iMaleFrogs = m_iMaleFrogs | newpos ;// add the piece to the new pos on the Male Frogs Bitboard
		break;
	case FemaleFrogs:
		m_iFemaleFrogs = m_iFemaleFrogs & NegPrevPos ;// remove the piece form prev position on the Female Frogs Bitboard
		m_iFemaleFrogs = m_iFemaleFrogs | newpos ;// add the piece to the new pos on the Female Frogs Bitboard
		break;
	case BabyFrogs:
		m_iBabyFrogs = m_iBabyFrogs & NegPrevPos ;// remove the piece form prev position on the Baby frogs Bitboard
		m_iBabyFrogs = m_iBabyFrogs | newpos ;// add the piece to the new pos on the Baby frogs Bitboard
		break;
	}
	//if(m_iNoOfPlayers == 1)
	//{
	//	UpdateAttackedSquaresBitboard() ;
	//}
	//	ToggleCurrentPieceColor() ;
	m_iBoard = 0 ;
	m_iBoard = m_iMaleFrogs | m_iFemaleFrogs | m_iBabyFrogs | m_iSnake | m_iBurrows | m_iBlocks ;
}


//Update the snake bitboard after each move
void cBoard::UpdateSnakeBitboard(const MOVE &move)
{
	/*
	MOVE move : the move that has been made, according to which the snake bitboard is to be updated
	*/
	BITBOARD	newHeadpos = 1, // to hold the bitboard of the to pos
				SnakeTailPosBitboard = 0x1 ; // to hold the bitboard for the snakes tale

	int			iSnakeTailPos ;// the snake tail pos

	m_iSnake = 0 ;
	if (move.SnakePos == OnBoard)
	{
		newHeadpos = newHeadpos<<move.to ; // get bitboard for to square and the head pos of the snake

		GetSnakeTailPos(move.to, move.SnakeDir, iSnakeTailPos) ;
		
		m_iSnake = m_iSnake | newHeadpos ;// add the piece to the new pos on the Snake Bitboard

		if (iSnakeTailPos ==  -1) // the tail is outside the board
		{
			return ;
		}
		else
		{
			SnakeTailPosBitboard = SnakeTailPosBitboard<<iSnakeTailPos ;
			m_iSnake = m_iSnake | SnakeTailPosBitboard ;
		}
	}
}

//checks if the tail is on the board and is adjoining the head
bool cBoard::CheckIfSnakeTailPosValid(const int iSnakeHeadPos, const int iSnakeTailPos) 
{
	/*
	int iSnakeHeadPos : the head position
	int iSnakeTailPos : the tail position
	*/
	int iRowDiff, // the row difference b/w heads and tail pos
		iColDiff, // the column difference b/w heads and tail pos
		iSquareDiff ;// the square difference b/w heads and tail pos

	iRowDiff = abs(iSnakeHeadPos/ciSquaresInRow - iSnakeTailPos/ciSquaresInRow) ;
	iColDiff = abs(iSnakeHeadPos%ciSquaresInRow - iSnakeTailPos%ciSquaresInRow) ;

	iSquareDiff = abs(iSnakeHeadPos - iSnakeTailPos) ;

	if (iSquareDiff == 1)
	{
		if (iRowDiff == 0)
		{
			return true ;
		}
		return false ;
	}

	if (iSquareDiff == ciSquaresInRow)
	{
		if (iColDiff == 0)
		{
			return true ;
		}
		return false ;
	}
	return false ; // should never come here

	//switch(iSquareDiff)
	//{
	//	//horizontally placed
	////case -1:
	//case 1:
	//	if (iRowDiff == 0)
	//	{
	//		return true ;
	//	}
	//	return false ;

	//	//vertically placed
	////case -8:
	//case 8:
	//	if (iColDiff == 0)
	//	{
	//		return true ;
	//	}
	//	return false ;

	//default:
	//	return false ; // should never come here
	//}
}

//adds a new  baby to the baby frogs bitboard
void cBoard::AddBabytoBitboard(const MOVE &move)
{
	/*
	MOVE move : the move that has been made, according to which the board is to be updated
	*/
	BITBOARD newBabyFrogBitboard  = 0x1 ;// to hold the bitboard for the new baby frog

	newBabyFrogBitboard = newBabyFrogBitboard<<move.newBabyPosition ;
	m_iBabyFrogs = m_iBabyFrogs | newBabyFrogBitboard ;

}
//returns the No of male frogs to be eaten by the snake
int cBoard::GetNoOfMaleFrogsToBeEaten()
{
	return m_iNoOfMaleFrogsToBeEaten ;
}

//returns the No of female frogs to be eaten by the snake
int cBoard::GetNoOfFemaleFrogsToBeEaten()
{
	return m_iNoOfFemaleFrogsToBeEaten ;
}

//returns the No of baby frogs to be eaten by the snake
int cBoard::GetNoOfBabyFrogsToBeEaten()
{
	return m_iNoOfBabyFrogsToBeEaten ;
}

//returns the No of baby frogs to be produced
int cBoard::GetNoOfBabyFrogsToBeProduced()
{
	return m_iNoOfBabyFrogsToBeProduced ;
}

//returns the No of baby frogs already produced
int cBoard::GetNoOfBabyFrogsProduced()
{
	return m_iNoOfBabyFrogsProduced ;
}

//returns the No of male frogs already eaten by the snake
int cBoard::GetNoOfMaleFrogsEaten()
{
	return m_iNoOfMaleFrogsEaten ;
}

//returns the No of female frogs already eaten by the snake
int cBoard::GetNoOfFemaleFrogsEaten()
{
	return m_iNoOfFemaleFrogsEaten ;
}

//returns the No of baby frogs already eaten by the snake
int cBoard::GetNoOfBabyFrogsEaten()
{
	return m_iNoOfBabyFrogsEaten ;
}
//returns the position of the tail of the snake
void cBoard::GetSnakeTailPos(const int iSnakeHeadPos, const Directions SnakeDir, int &iSnakeTailPos)
{
	BITBOARD		SnakeTailBitBoard = 0x1 ;

	switch(SnakeDir)// check if tail is on the board
	{
	case North:
		//if ((iSnakeHeadPos>=(ciMaxIndexBoard - ciSquaresInRow+1)) && iSnakeHeadPos<=ciMaxIndexBoard) // the head is in the last row
		if(CheckifBottomRow(iSnakeHeadPos))
		{
			iSnakeTailPos = -1 ;
		}
		else
		{
			iSnakeTailPos = iSnakeHeadPos + ciSquaresInRow ;
		}
		break ;

	case South:
		//if (iSnakeHeadPos<=ciSquaresInRow)// the head is in the 1st row
		if (CheckifTopRow(iSnakeHeadPos))
		{
			iSnakeTailPos = -1 ;
		}
		else
		{
			iSnakeTailPos = iSnakeHeadPos - ciSquaresInRow ;
		}
		break ;

	case East:
		//if((iSnakeHeadPos%ciSquaresInRow) == 0)// 1st col
		if(CheckifFirstCol(iSnakeHeadPos))
		{
			iSnakeTailPos = -1;
		}
		else
		{
			iSnakeTailPos = iSnakeHeadPos - 1 ;
		}
		break ;

	case West:
		//if ((iSnakeHeadPos%ciSquaresInRow) == (ciSquaresInRow-1))// last col
		if (CheckifLastCol(iSnakeHeadPos))
		{
			iSnakeTailPos = -1 ;
		}
		else
		{
			iSnakeTailPos = iSnakeHeadPos + 1 ;
		}
		break ;			
	}

	//check if the 
	SnakeTailBitBoard = SnakeTailBitBoard << iSnakeTailPos ;
	if ((SnakeTailBitBoard & m_iBurrows) > 0 )
	{
		iSnakeTailPos = -1 ;		
	}
	if(iSnakeTailPos != -1 && (!CheckIfSnakeTailPosValid(iSnakeHeadPos, iSnakeTailPos)))// the tail is out of the board
	{
		iSnakeTailPos = -1;
	}

}

//checks if the square is in the top row
bool cBoard::CheckifTopRow(const int iSquareNo)
{
	/*
	int iSquareNo : the square no which is to be checked
	*/
	if (iSquareNo<ciSquaresInRow)// the square is in the 1st row
	{
		return true ;
	}
	return false ;
}
//checks if the square is in the bottom row
bool cBoard::CheckifBottomRow(const int iSquareNo)
{
	/*
	int iSquareNo : the square no which is to be checked
	*/
	if ((iSquareNo>=(ciMaxIndexBoard - ciSquaresInRow+1)) && iSquareNo<=ciMaxIndexBoard) // the square is in the last row
	{
		return true ;
	}
	return false ;
}
//checks if the square is in the first column
bool cBoard::CheckifFirstCol(const int iSquareNo)
{
	/*
	int iSquareNo : the square no which is to be checked
	*/
	if((iSquareNo%ciSquaresInRow) == 0)// 1st col
	{
		return true ;
	}
	return false ;
}
//checks if the square is in the last column
bool cBoard::CheckifLastCol(const int iSquareNo)
{
	/*
	int iSquareNo : the square no which is to be checked
	*/
	if ((iSquareNo%ciSquaresInRow) == (ciSquaresInRow-1))// last col
	{
		return true ;
	}
	return false ;
}