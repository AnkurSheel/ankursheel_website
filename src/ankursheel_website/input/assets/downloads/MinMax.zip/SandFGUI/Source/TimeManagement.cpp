#include "stdafx.h"
#include "TimeManagement.h"

double CTimeManagement::dFrequencyToCounterRatio = 1.0 ;
__int64 CTimeManagement::i64Start = 0 ;
__int64 CTimeManagement::i64End = 0 ;
