#pragma  once

enum PieceTypes {NoPiece, MaleFrogs, FemaleFrogs, BabyFrogs, Snake, Burrow, Frogs, Couples, Blocks} ;// the possible piece types on the board
enum Directions {DirNA, North, East, West, South} ;// the directions in which the snake can move 
enum Player {Human, Computer} ;// the type of players
enum MoveTypes {NoMove, NormalMove, BurrowMove, OutOfBoardMove, AttackMove, ReproductionMove} ;//the different moves that can be made by pieces

enum SnakePosition {OnBoard, InBurrow, OffBoard} ; // the different places the snake can be



const int ciMinIndexBoard = 0 ; // the minimum index of a square on the board
const int ciMaxIndexBoard = 63 ;// the maximum index of a square on the board
const int ciSquaresInRow = 8 ; // the no of squares in each row
const int ciSquaresInCol = 8 ; // the no of squares in each col

const int ciMaxSnakeMove = 2 ;// the maximum no. of moves a snake can move in one turn

const int ciNegInfinity = -9999999 ;
const int ciPosInfinity = 9999999 ;

const int ciNoOfNodesToCheckAfter = 50 ;

const int ciMinRangeofRandomNo = 0 ;
const int ciMaxRangeofRandomNo = 100 ;
const int ciPercentageChance = 50 ;	

//Deltas
//const int MaleFrogDelta[13] = {-16, -9, -8, -7, -2, -1, 1, 2, 7, 8, 9, 16, 0} ;
//const int FemaleFrogDelta[5] = {-8, -1, 1, 8, 0} ;
//const int BabyFrogDelta[9] = {-9, -8, -7, -1, 1, 7, 8, 9, 0} ;
//const int SnakeDelta[5] ={-8, -1, 1, 8, 0} ;
//const int PlaceBabyFrogsDelta[9] ={-9,-8,-7,-1,1,7,8,9,0} ;

//Deltas
const int MaleFrogDelta[13] = {-(ciSquaresInRow*2), -(ciSquaresInRow+1), -ciSquaresInRow, -(ciSquaresInRow-1), -2, -1, 1, 2, (ciSquaresInRow-1), 
ciSquaresInRow, (ciSquaresInRow+1), (ciSquaresInRow*2), 0} ;
const int FemaleFrogDelta[5] = {-(ciSquaresInRow), -1, 1, (ciSquaresInRow), 0} ;
const int BabyFrogDelta[9] = {-(ciSquaresInRow+1), -ciSquaresInRow, -(ciSquaresInRow-1), -1, 1, (ciSquaresInRow-1), ciSquaresInRow, 
(ciSquaresInRow+1), 0} ;
const int SnakeDelta[5] ={-ciSquaresInRow, -1, 1, ciSquaresInRow, 0} ;
const int PlaceBabyFrogsDelta[9] = {-(ciSquaresInRow+1), -ciSquaresInRow, -(ciSquaresInRow-1), -1, 1, (ciSquaresInRow-1), ciSquaresInRow, 
(ciSquaresInRow +1) ,0} ;

//Weights - try to keep total = 100
const int ciFrogsEatenWhenRemainingWeightFrog = 200 ;// if a required frog is eaten and frogs move
const int ciFrogsEatenWhenRemainingWeightSnake = 200 ;// if a required frog is eaten and snakes move
const int ciFrogsEatenWhenFinishedWeightFrog = 50 ;// if a not required frog is eaten and frogs move
const int ciFrogsEatenWhenFinishedWeightSnake = 50 ;// if a not required frog is eaten and snakes move
const int ciBabyFrogsProducedWeightSnake = 200 ;// if a baby frog is produced and snakes move
const int ciBabyFrogsProducedWeightFrog = 1000 ;// if a baby frog is produced and frogs move
//const int ciFrogsSafeWeight = 20 ;// if a frog is safe


const int ciFrogSafeGoalWeightFrog = 100 ;// if a frog is safe and frogs move
const int ciFrogSafeGoalWeightSnake = 40 ;// if a frog is safe and snakes move


//Values
const int ciMaleFrogsValue = 100 ;
const int ciFemaleFrogsValue = 100 ;
const int ciBabyFrogsValueEat = 50 ;
const int ciBabyFrogsValueProduce = 1000 ;
const int ciAdultFrogsValueSafe = 50 ;
const int ciBabyFrogsValueSafe = 25 ;

const int ciFrogsValueEdge = -50 ;
const int ciFrogEdgeWeightFrog = 50 ;
const int ciMaleFrogAttackedBySnakeValue = 12 ;
const int ciFemaleFrogAttackedBySnakeValue = 4 ;
const int ciBabyFrogAttackedBySnakeValue = 8 ;
const int ciSurroundingSquareAttackedBySnakeValue = -1 ;

//for JavaVersion2
//for Evaluating which frog
//RegionChecks

//[row][col] = [region no][region delta]
const int FrogRegionDelta[6][5] = {{-(ciSquaresInRow), -1, 1, (ciSquaresInRow), 0}, // region 1
								   {-((ciSquaresInRow*1)-1), -((ciSquaresInRow*1)+1), ((ciSquaresInRow*1)-1), ((ciSquaresInRow*1)+1), 0}, //region 2
								   {-(ciSquaresInRow*2), -2, 2, (ciSquaresInRow*2), 0}, // region 3
								   {-((ciSquaresInRow*2)-1), -((ciSquaresInRow*2)+1), -((ciSquaresInRow*1)-2), -((ciSquaresInRow*1)+2), 0},//region 4
								   {((ciSquaresInRow*1)-2), ((ciSquaresInRow*1)+2), ((ciSquaresInRow*2)-1), ((ciSquaresInRow*2)+1), 0}, //region 5
								   {-(ciSquaresInRow*3), -3, 3, (ciSquaresInRow*3), 0}} ;

//BoardPieces Value
//[row][col] = [region][Board piece]
//Region = {R1,R2,R3,R4,R5}
//Board piece  = {Male, Female, Baby, Burrow, Edge } 

//for Snake Ai
const int MaleFrogsRegionValueSnake[9][7] = {{7, 15, 3, -3, -9},
											{7, 15, 3, -6,  0},
											{7, 15, 3, -3, -3},
											{7,  7, 3,  0,  0},
											{7,  7, 3,  0,  0},
											{7,  7, 3,  0,  0}} ;

const int FemaleFrogsRegionValueSnake[9][7] = {{15, 7, 3, -3, -9},
											 {15,  7, 3, -6,  0},
											 {15,  7, 3, -3, -3},
											 { 7,  0, 3,  0,  0},
											 { 7,  0, 3,  0,  0},
											 { 7,  0, 0,  0,  0}} ;

const int BabyFrogsRegionValueSnake[9][7] = {{7, 7, 1, -3, -9},
											{7, 7, 1, -6,  0},
											{7, 7, 1, -3, -3},
											{7, 7, 1,  0,  0},
											{7, 7, 1,  0,  0},
											{7, 0, 0,  0,  0}} ;

//for Frog Ai
const int MaleFrogsRegionValueFrog[9][7] = {{7, 20, 3, -3, -9},
										{7, 20, 3, -6,  0},
										{7, 20, 3, -3, -3},
										{7,  7, 3,  0,  0},
										{7,  7, 3,  0,  0},
										{7,  7, 3,  0,  0}} ;

const int FemaleFrogsRegionValueFrog[9][7] = {{20, 7, 3, -3, -9},
											{20,  7, 3, -6,  0},
											{20,  7, 3, -3, -3},
											{ 7,  0, 3,  0,  0},
											{ 7,  0, 3,  0,  0},
											{ 7,  0, 0,  0,  0}} ;

const int BabyFrogsRegionValueFrog[9][7] = {{7, 7, 1, -3, -9},
										{7, 7, 1, -6,  0},
										{7, 7, 1, -3, -3},
										{7, 7, 1,  0,  0},
										{7, 7, 1,  0,  0},
										{7, 0, 0,  0,  0}} ;

const int ciMaxSnakeDepth = 2 ; 