# pragma once

#include "stdafx.h"
 
void QuickSortBestMoveFirst(vector<MOVE> &dataArray, int lowIndex, int hiIndex)
{
	int			i = lowIndex, 
				j = hiIndex ;  
	MOVE		temp,
				midVal = dataArray.at((lowIndex+hiIndex)/2) ;

	//  partition
	do
	{    
		while (dataArray.at(i).mvType > midVal.mvType)
		{
			i++ ; 
		}
		while (dataArray.at(j).mvType < midVal.mvType)
		{
			j-- ;
		}
		if (i<=j)
		{
			//a.swap(a.at(i), a.at(j)) ;
			temp=dataArray.at(i) ; 
			dataArray.at(i) = dataArray.at(j) ;
			dataArray.at(j) = temp ;
			i++ ;
			j-- ;
		}
	} 
	while (i<=j) ;

	//  recursion
	if (lowIndex<j)
	{
		QuickSortBestMoveFirst(dataArray, lowIndex, j) ;
	}
	if (i<hiIndex) 
	{
		QuickSortBestMoveFirst(dataArray, i, hiIndex) ;
	}
}
void QuickSortBestMoveLast(vector<MOVE> &dataArray, int lowIndex, int hiIndex)
{
	int			i = lowIndex, 
				j = hiIndex ;  
	MOVE		temp,
				midVal = dataArray.at((lowIndex+hiIndex)/2) ;

	//  partition
	do
	{    
		while (dataArray.at(i).mvType < midVal.mvType)
		{
			i++ ; 
		}
		while (dataArray.at(j).mvType > midVal.mvType)
		{
			j-- ;
		}
		if (i<=j)
		{
			//a.swap(a.at(i), a.at(j)) ;
			temp=dataArray.at(i) ; 
			dataArray.at(i) = dataArray.at(j) ;
			dataArray.at(j) = temp ;
			i++ ;
			j-- ;
		}
	} 
	while (i<=j) ;

	//  recursion
	if (lowIndex<j)
	{
		QuickSortBestMoveLast(dataArray, lowIndex, j) ;
	}
	if (i<hiIndex) 
	{
		QuickSortBestMoveLast(dataArray, i, hiIndex) ;
	}
}