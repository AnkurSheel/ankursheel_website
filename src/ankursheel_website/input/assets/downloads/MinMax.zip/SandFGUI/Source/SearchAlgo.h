# pragma once

class cSearch
{
protected:
	PieceTypes	m_compPlayer ;// the piece that the computer player is playing as
	BITBOARD	m_iToSquareBitboard,// the bitboard for the To Square
				m_boardBitBoard ; // the bitboard of the state of the board
	cBoard		m_board ;// a copy of the board
	float		m_fTimeElapsed, // the time that has elapsed
				m_fTimeAllowed ;// the total time that the engine is allowed to run
	int			m_iNoOfNodes,// the total no of nodes traversed
				m_iMaxDepth ; // the max depth that the engine is to run
#ifdef TestEngine
	int			*m_piTotalNoofNodesAtLevel ; // the total no of nodes traversed at a level
	int			*m_piTotalNoofNodesEvaluatedAtLevel ;//the total no of nodes evaluated at a level
	vector <MOVE> m_AllMoves ;
#endif

	PieceTypes	m_CurrentPieceType ; // the current piece whose turn it is

	void InitializePiece(cBoard &Board) ;
	void SetToSquare(const int iToSquare) ;
	void SetRowAndColDiff(const int iFromSquare, const int iToSquare, int &iRowDiff, int &iColDiff, int &iSquareDiff) ;
#ifdef JavaVersion1
	int NegaMaxSnake(cBoard &Board, const int CurrentDepth, const Player player, const PieceTypes CurrentPcType ,int alpha, int beta, vector<MOVE> &pv, bool &bHasSnakeMovedOut, bool &bHasSnakedMovedinBurrow, const int iOrignalFromSquareNum, const int iFromSquareNum,Directions SnakeDir, const int iMoveNo) ;
	int NegaMaxFrog(cBoard &Board, const int CurrentDepth, const Player player, const PieceTypes CurrentPcType ,int alpha, int beta, vector<MOVE> &pv) ;
	bool CheckIfValidAttack(MOVE &move) ;
#else
	vector<MOVE> GenerateMoves(cBoard &Board, const PieceTypes CurrentPieceType) ;
	void GeneratePsuedoMovesMaleFrog(cBoard &pBoard, const int iFromSquareNum, vector<MOVE> &PsuedoMoves) ;
	void GeneratePsuedoMovesFemaleFrog(cBoard &pBoard, const int iFromSquareNum, vector<MOVE> &PsuedoMoves) ;
	void GeneratePsuedoMovesBabyFrog(cBoard &pBoard, const int iFromSquareNum, vector<MOVE> &PsuedoMoves) ;
	void GeneratePsuedoMovesSnake(cBoard &pBoard, const int iOrignalFromSquareNum, const int iFromSquareNum, vector<MOVE> &PsuedoMoves,const Directions SnakeDir, bool &bHasSnakedMovedOut, bool &bHasSnakedMovedinBurrow) ;
	void GeneratePsuedoMovesSnakeOnBoard(MOVE &move, const int iOrignalFromSquareNum, const int iFromSquareNum, vector<MOVE> &PsuedoMoves, const int iMoveNo, const Directions SnakeDir, bool &bHasSnakedMovedOut, bool &bHasSnakedMovedinBurrow) ;
	void GeneratePsuedoMovesSnakeInBurrow(MOVE &move, vector<MOVE> &PsuedoMoves) ;
	void GeneratePsuedoMovesSnakeoutOffBoard(MOVE &move, vector<MOVE> &PsuedoMoves) ;
	void AddMoveFrog(vector<MOVE> &PsuedoMoves, MOVE &move) ;
	MoveTypes AddMoveSnake(vector<MOVE> &PsuedoMoves, MOVE &move, bool &bHasSnakedMovedinBurrow) ;
	bool CheckIfValidAttack(vector<MOVE> &PsuedoMoves, MOVE &move) ;
#ifdef JavaVersion2
	void GetBestMoveSnake(cBoard &Board, const int CurrentDepth, const Player player, const PieceTypes CurrentPcType, MOVE &BestMove, int &iBestScore) ;
	void GetBestMoveFrog(cBoard &Board, const int CurrentDepth, const Player player, const PieceTypes CurrentPcType, MOVE &BestMove, int &iBestScore) ;
	void EvaluateFrogForSnakeAI(const PieceTypes FrogType,  const int iFrogPos, int &iFrogScore) ;
	void EvaluateMaleFrogForSnakeAI(const int iFrogSquare, int &iFrogScore) ;
	void EvaluateFemaleFrogForSnakeAI(const int iFrogSquare, int &iFrogScore) ;
	void EvaluateBabyFrogForSnakeAI(const int iFrogSquare, int &iFrogScore) ;
	void EvaluateFrogForFrogAI(const PieceTypes FrogType,  const int iFrogPos, int &iFrogScore, const BITBOARD &isSnakeMoveBitboard) ;
	void EvaluateMaleFrogForFrogAI(const int iFrogSquare, int &iFrogScore, const BITBOARD &isSnakeMoveBitboard) ;
	void EvaluateFemaleFrogForFrogAI(const int iFrogSquare, int &iFrogScore, const BITBOARD &isSnakeMoveBitboard) ;
	void EvaluateBabyFrogForFrogAI(const int iFrogSquare, int &iFrogScore, const BITBOARD &isSnakeMoveBitboard) ;

	void GenerateRegionMovesMaleFrog(cBoard &pBoard, const int iFromSquareNum, vector<MOVE> &PsuedoMoves, BITBOARD regionBitBoard) ;
	void GenerateRegionMovesFemaleFrog(cBoard &pBoard, const int iFromSquareNum, vector<MOVE> &PsuedoMoves, BITBOARD regionBitBoard) ;
	void GenerateRegionMovesBabyFrog(cBoard &pBoard, const int iFromSquareNum, vector<MOVE> &PsuedoMoves, BITBOARD regionBitBoard) ;
	
#else
	//int NegaMax(cBoard &Board, vector<MOVE> &moves, const int CurrentDepth, const Player player, const PieceTypes CurrentPcType ,int alpha, int beta, vector<MOVE> &pv) ;
	int NegaMax(cBoard &Board, const int CurrentDepth, const Player player, const PieceTypes CurrentPcType ,int alpha, int beta, vector<MOVE> &pv) ;
#endif
#endif
	void CheckIfValidReproduction(vector<MOVE> &PsuedoMoves, MOVE &move) ;
	
	bool cSearch::CheckIfValidMove(const int iSquareOne, const int iSquareTwo) ;
	bool CheckIfFrogIsSafe(const int iCurrentSquare, const int iCurrentSquareLessOne, const int iCurrentSquareLessTwo) ;
	bool CheckIfFrogIsBlocked(const int iCurrentSquare, const int iCurrentSquarePlusOne) ;
	//bool CheckIfValidMove(const int iSquareDiff, const int iRowDiff, const int iColDiff) ;
	int IsWinOrDraw(cBoard &Board) ;
#ifdef JavaVersion2
	int EvaluateBoardFrog(cBoard &Board, const BITBOARD iregionBitboard) ;
#else
	int EvaluateBoard(cBoard &Board, const Player player, const PieceTypes CurrentPcType) ;
#endif
	
	//int  EvaluatePosition(cBoard &Board, const Player player) ;


public:
	cSearch() ;
	~cSearch() ;
	void RunSearchAlgo(cBoard &Board, const PieceTypes compPlayer, const float &fTimeAllowed, const int iMaxDepth, vector<MOVE> &pv) ;
#ifdef TestEngine
	vector<MOVE> GetAllMoves() ;
	//int *GetTotalNodesAtLevel() ;
	//int *GetTotalEvaluatedNodesAtLevel() ;
	void GetInfo(char *szInfo) ;
#endif
} ;
