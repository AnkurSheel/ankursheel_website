// *****************************************************************************
//  Neuron   version:  1.0   Ankur Sheel  date: 2010/04/02
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#ifndef Neuron_h__
#define Neuron_h__

class cNeuron;

// struct to hold the link data
struct stLink
{
	float		fWeight;	// the weight of this link
	cNeuron*	link;		// the neuron to which this link connects to
	stLink(float wt, cNeuron *lnk)
	{
		fWeight = wt;
		link = lnk;
	}
};

class cNeuron
{
	float				m_fValue;		// the value of this nueron
	float				m_fError;		// the error in this neuron

public:
	vector<stLink *>	m_vInLinks;		// the in links of this neuron
	vector<stLink *>	m_vOutLinks;	// the out links of this neuron
	float				m_Bias;         // the bais in this neuron
	float				m_BiasWeight;   // the weight of the bias for this neuron

public:
	cNeuron();
	~cNeuron(){}

	void SetLink(const float& wt, cNeuron* const pLinkedNeuron , const bool bInLink = true);
	void SetValue(const float& val);
	float GetValue();
	float GetError();
	void SetError(const float& val);
	void AdjustWeight(float learningRate);
	void Evaluate();
	void Destroy();
};
#endif // Neuron_h__