// *****************************************************************************
//  NNLayer   version:  1.0   Ankur Sheel  date: 2010/04/02
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#include "stdafx.h"
#include "NNLayer.h"
#include "Neuron.h"
#include "FileIO.h"

cNNLayer::cNNLayer()
: m_pPrevLayer(NULL)
, m_pNextLayer(NULL)
, m_eType(NONE)
{

}

cNNLayer::~cNNLayer()
{
}

// create the neurons in the layer
// Parameter: const int iNumberOfNeurons - the number of neurons in this layer
// Parameter: const LayerType type - the type of layer(Input/Hidden/Output)
void cNNLayer::CreateLayer( const int iNumberOfNeurons ,const LayerType type )
{
	for (int i=0;i<iNumberOfNeurons;i++)
	{
		cNeuron * neuron = new cNeuron();
		m_vNeurons.push_back(neuron);
		if(type == OUTPUT)
		{
			m_DesiredOutputs.push_back(0);
		}
	}
	m_eType = type;
}


// creates all the link b/w all the neurons of this slayer with all the neurons in the passed layer
// Parameter: cNNLayer * const pLayer - the layer to link to
void cNNLayer::SetLinkForLayer( cNNLayer* const pLayer )
{
	int			iIndex;			// index of neuron in passed layer
	cNeuron		*tempNeuron;

	for (unsigned int i=0;i<m_vNeurons.size();i++)
	{
		iIndex = 0;
		tempNeuron = pLayer->GetNeuron(iIndex);
		float val;
		while (tempNeuron)
		{
			RandomValue(val);
			//cout<<"Neuron "<<i<<" to "<<iIndex<<" in layer : "<<val<<endl;

			// Set the out link of the neuron
			m_vNeurons[i]->SetLink(val, tempNeuron, false);

			//set the in link to other neuron
			tempNeuron->SetLink(val,m_vNeurons[i] , true);

			//get the next neuron in the layer to link to
			iIndex++;
			tempNeuron = pLayer->GetNeuron(iIndex);
		}	
	}
}

cNeuron* cNNLayer::GetNeuron( const unsigned int iIndex )
{
	if(iIndex < m_vNeurons.size())
	{
		return m_vNeurons.at(iIndex);
	}
	return NULL;
}

void cNNLayer::WriteNeuronWeight( cFileIO& fileio, const char* const strLayer )
{
	char temp[100];
	char temp1[100];
	char temp2[100];
	char temp3[100];
	//cout<<"Layer start\n";
	cNeuron		*tempNeuron;
	stLink* link;
	for (unsigned int i=0;i<m_vNeurons.size();i++)
	{
		tempNeuron = m_vNeurons[i];
		//cout<<"Neuron Starts\n";
		sprintf(temp, "%s_Neuron%d", strLayer, i+1 );
		fileio.AddNode(strLayer, temp, "");

		//cout<<"neuron bias "<<tempNeuron->m_Bias<<"\n";
		sprintf(temp2, "%s_Bias%d", temp, i+1 );
		_gcvt(tempNeuron->m_Bias, 10, temp1);
		fileio.AddNode(temp, temp2, temp1);

		//cout<<"neuron bias weight "<<tempNeuron->m_BiasWeight<<"\n";
		sprintf(temp2, "%s_BiasWeight%d", temp, i+1 );
		_gcvt(tempNeuron->m_BiasWeight, 10, temp1);
		fileio.AddNode(temp, temp2, temp1);

		sprintf(temp2, "%s_InLinks", temp);
		fileio.AddNode(temp, temp2, "");
		for (unsigned int i= 0;i<tempNeuron->m_vInLinks.size();i++)
		{
			link = (tempNeuron->m_vInLinks).at(i);
			sprintf(temp3, "%s_Link%d", temp2, i+1 );
			_gcvt(link->fWeight, 10, temp1);
			fileio.AddNode(temp2, temp3, temp1);
		}

		sprintf(temp2, "%s_OutLinks", temp);
		fileio.AddNode(temp, temp2, "");
		for (unsigned int i= 0;i<tempNeuron->m_vOutLinks.size();i++)
		{
			link = (tempNeuron->m_vOutLinks).at(i);
			sprintf(temp3, "%s_OutLink%d", temp2, i+1 );
			_gcvt(link->fWeight, 10, temp1);
			fileio.AddNode(temp2, temp3, temp1);
		}
		//cout<<"Neuron Ends\n";
	}
}

void cNNLayer::ReadNeuronWeights( cFileIO& fileio, const char* const strLayer )
{
	cNeuron		*tempNeuron;
	stLink* link;
	string strNode;
	string strNode1;
	string strNode2;
	string strValue;
	int count;
	for (unsigned int i=0;i<m_vNeurons.size();i++)
	{

		tempNeuron = m_vNeurons[i];

		count = 0;
		strNode = fileio.GetNodeName(strLayer, i);
		strNode1 = fileio.GetNodeName(strNode, count++);
		strValue = fileio.GetNodeValue(strNode1);
		tempNeuron->m_Bias = (float)atof(strValue.c_str());

		strNode1 = fileio.GetNodeName(strNode, count++);
		strValue = fileio.GetNodeValue(strNode1);
		tempNeuron->m_BiasWeight = (float)atof(strValue.c_str());

		strNode1 = fileio.GetNodeName(strNode, count++);

		//To do : write back corresponding inlinks
		for (unsigned int i= 0;i<tempNeuron->m_vInLinks.size();i++)
		{
			link = (tempNeuron->m_vInLinks).at(i);

			strNode2 = fileio.GetNodeName(strNode1, i);
			strValue = fileio.GetNodeValue(strNode2);
			link->fWeight = (float)atof(strValue.c_str());
		}
		strNode1 = fileio.GetNodeName(strNode, count++);

		//To do : write back corresponding inlinks
		for (unsigned int i= 0;i<tempNeuron->m_vOutLinks.size();i++)
		{
			link = (tempNeuron->m_vOutLinks).at(i);

			strNode2 = fileio.GetNodeName(strNode1, i);
			strValue = fileio.GetNodeValue(strNode2);
			link->fWeight = (float)atof(strValue.c_str());
			//cout<<"Neuron : "<<link->fWeight<<"\n";
		}
	}

}
void cNNLayer::SetInputValues( const int iNeuronId ,const float& val )
{
	m_vNeurons[iNeuronId]->SetValue(val);
}

void cNNLayer::SetOutputValues( const int neuron ,const float& val )
{
	m_DesiredOutputs[neuron] = val;
}

bool cNNLayer::AdjustWeights( const float& learningRate )
{
	// the BP algo  and error correction for the o/p layer
	if(m_eType == OUTPUT)
	{
		int			iNoOfNeurons = (int)m_vNeurons.size();
		float		fDesiredOutput;
		float		fCalculatedOutput;
		for(int i=0; i<iNoOfNeurons; i++) // for all the neurons in the o/p layer
		{
			fDesiredOutput = m_DesiredOutputs[i];
			fCalculatedOutput = m_vNeurons[i]->GetValue();

			// calculate error in this neuron according to the formula
			// error = (desired - calculated) * calculated * (1 - calculated)
			float error = (fDesiredOutput - fCalculatedOutput) * fCalculatedOutput * (1.f - fCalculatedOutput);

			m_vNeurons[i]->SetError(error);
		}
	}
	else // hidden layer
	{
		int			iNoOfNeurons = (int)m_vNeurons.size();

		for(int i=0; i<iNoOfNeurons; i++) // for all the neurons in the layer
		{
			m_vNeurons[i]->AdjustWeight(learningRate);
		}
	}
	return true;
}

void cNNLayer::Evaluate()
{
	int			iNoOfNeurons = (int)m_vNeurons.size();

	for(int i=0; i<iNoOfNeurons; i++)
	{
		m_vNeurons[i]->Evaluate();
	}
}

void cNNLayer::Destroy()
{
	int			iTotalNoOfNeurons = (int)m_vNeurons.size();

	for (int i=0; i<iTotalNoOfNeurons; i++)
	{
		m_vNeurons[i]->Destroy();
		SAFE_DELETE(m_vNeurons[i]);
	}
	m_vNeurons.clear();
}
