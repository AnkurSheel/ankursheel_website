// *****************************************************************************
//  NN   version:  1.0   Ankur Sheel  date: 2010/04/02
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#ifndef NN_h__
#define NN_h__

class cNNLayer;
enum eUsage;

// structure to hold the training sets
struct stTrainingSet
{
	vector<float>	InputSet;			// vector to hold the inputs
	vector<float>	OutputSet;			// vector to hold the outputs
};

class cNN
{
	float					m_fLearningRate;		
	vector<cNNLayer*>		m_vLayers;				// vector of pointers to the layers of the network
	vector<stTrainingSet>	m_TrainingSet;			// vector to hold the training data
	int						m_iNoOfInputNeurons;
	int						m_iNoOfOutputNeurons;
	eUsage					m_eUsage;
	char					m_strDataFilePath[MAXPATHLENGTH];
	char					m_strNNFilePath[MAXPATHLENGTH];
	void ReadTrainingData();
	void SetOutput(const vector<float>& OutSet);
	void SetInput(const vector<float>& trainingSet);
	void CreateNN();
	void SetNNLinks();

public:
	cNN();
	~cNN();
	void InitNN(const eUsage eUsage, const char* const strNNFilePath, const char* const strDataFilePath);

	void LoadNNFile();
	void Evaluate();
	bool TrainNetwork();
	void WriteNNFile();
	
	void Destroy();
	void TestData();
};
#endif // NN_h__