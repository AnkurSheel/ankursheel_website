// *****************************************************************************
//  Neuron   version:  1.0   Ankur Sheel  date: 2010/04/02
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#include "stdafx.h"
#include "Neuron.h"

cNeuron::cNeuron()
: m_fValue(0.f)
, m_fError(0.f)
, m_Bias(1.f)
{
	RandomValue(m_BiasWeight);
}

void cNeuron::SetLink( const float& wt, cNeuron* const pLinkedNeuron , const bool bInLink /*= true*/ )
{
	if(pLinkedNeuron)
	{	
		stLink *pLinkNeuron = new stLink(wt,pLinkedNeuron);

		if(bInLink)
		{
			m_vInLinks.push_back(pLinkNeuron);
		}
		else
		{
			m_vOutLinks.push_back(pLinkNeuron);
		}
	}
}

void cNeuron::SetValue( const float& val )
{
	m_fValue = val;
}

float cNeuron::GetValue()
{
	return m_fValue;
}

void cNeuron::SetError( const float& val )
{
	m_fError = val;
}

float cNeuron::GetError()
{
	return m_fError;
}

void cNeuron::AdjustWeight( float learningRate ) // only for hidden neurons
{
	unsigned int iTotalNoOfPostLinks = (int) m_vOutLinks.size();

	m_fError = 0;

	// calculate the error associated with this neuron
	// according to the formula
	//	error = sumof(output link error * output link weight) * calculated * (1 - calculated)
	for(unsigned int i=0;i<iTotalNoOfPostLinks;i++)
	{
		float fLinkWt = m_vOutLinks[i]->fWeight;
		float fLinkError = m_vOutLinks[i]->link->GetError();
		m_fError = m_fError + (fLinkError * fLinkWt);
	}

	m_fError = m_fError * m_fValue * (1.f - m_fValue);


	// Adjust Weights
	for(unsigned int i=0;i<m_vOutLinks.size();i++)
	{
		// get the delta weight according to the formula
		// delta = learning rate * error * calculated
		float deltaWeight = learningRate * m_vOutLinks[i]->link->GetError() * m_fValue;

		m_vOutLinks[i]->fWeight += deltaWeight;
		
		// ajust the bias weight
		m_vOutLinks[i]->link->m_BiasWeight += (learningRate * m_vOutLinks[i]->link->GetError() * m_vOutLinks[i]->link->m_Bias);

		int		iTotalNoOfInLinks = (int)m_vOutLinks[i]->link->m_vInLinks.size();

		// synchronise with the weights for which this link is an inlink
		for(int j=0;j<iTotalNoOfInLinks;j++) // for all the in links
		{
			if(m_vOutLinks[i]->link->m_vInLinks[j]->link == this)
			{
				m_vOutLinks[i]->link->m_vInLinks[j]->fWeight = m_vOutLinks[i]->fWeight;
				break;
			}
		}
	}
}

void cNeuron::Evaluate()
{
	unsigned int iTotalNoOfInLinks = (int) m_vInLinks.size();

	m_fValue = 0;
	for(unsigned int i=0;i<iTotalNoOfInLinks;i++)
	{
		m_fValue = m_fValue + m_vInLinks[i]->fWeight * m_vInLinks[i]->link->GetValue(); 
	}
	m_fValue += m_Bias * m_BiasWeight;
	m_fValue = 1.f / (1.f + exp(-m_fValue));
}

void cNeuron::Destroy()
{
	int		iTotalNoOfPostLinks = (int) m_vOutLinks.size();
	int		iTotalNoOfInLinks = (int) m_vInLinks.size();

	for (int i=0; i<iTotalNoOfPostLinks; i++)
	{
		SAFE_DELETE(m_vOutLinks[i]);
	}

	for (int i=0; i<iTotalNoOfInLinks; i++)
	{
		if (m_vInLinks[i])
		{
			SAFE_DELETE(m_vInLinks[i]);
		}
	}

	m_vOutLinks.clear();
	m_vInLinks.clear();

}