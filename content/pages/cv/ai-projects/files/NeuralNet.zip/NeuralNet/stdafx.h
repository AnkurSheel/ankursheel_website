// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#pragma warning(disable : 4996)

#ifdef _DEBUG
#define _CRTDBG_MAP_ALLOC
#endif

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <stdio.h>
//#include <char.h>
#include <iostream>
#include <map>
#include <vector>
#include <math.h>
#include <conio.h>
using namespace std;

// TODO: reference additional headers your program requires here
#ifdef _DEBUG
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

#define new new(_NORMAL_BLOCK, __FILE__, __LINE__)
#endif

#define SAFE_DELETE(p) {if(p){delete p; p = NULL;}}

#define RandomValue(x) x = ((float)(rand()%10000) / 5000)-1

#define ToString(X) ToString2(X)
#define ToString2(X) #X

#define Concat2(arg1, arg2)  arg1##arg2 
#define Concat(arg1, arg2)  Concat2(arg1, arg2)

#define MAXPATHLENGTH 256