// *****************************************************************************
//  NNLayer   version:  1.0   Ankur Sheel  date: 2010/04/02
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#ifndef NNLayer_h__
#define NNLayer_h__

class cNeuron;
class cFileIO;
enum eUsage;

enum LayerType
{
	NONE = -1,
	INPUT,
	HIDDEN,
	OUTPUT
};

class cNNLayer
{
	vector<cNeuron*>	m_vNeurons;					// vector to store all the neurons in this layer
	vector<float>		m_DesiredOutputs;			// vector to store the desire outputs
	cNNLayer*			m_pPrevLayer;				// pointer to the previous layer i.e the layer of which the neurons are i/p to this one
	cNNLayer*			m_pNextLayer;				// pointer to the previous layer i.e the layer of which the neurons are o/p for this one
	LayerType			m_eType;
	
	
public:
	cNNLayer();
	~cNNLayer();
	void CreateLayer(const int iNumberOfNeurons ,const LayerType type);
	void Destroy();
	void SetLinkForLayer(cNNLayer* const pLayer);
	cNeuron* GetNeuron(const unsigned int iIndex);
	void SetInputValues(const int iNeuronId ,const float& val);
	void SetOutputValues(const int neuron ,const float& val);
	bool AdjustWeights(const float& learningRate);
	void Evaluate();
	void WriteNeuronWeight(cFileIO& fileio, const char* const strLayer );
	void ReadNeuronWeights(cFileIO& fileio, const char* const strLayer );
};
#endif // NNLayer_h__