// ***************************************************************
//  FileIO   version:  1.0   Ankur Sheel  date: 2009/10/30
//  -------------------------------------------------------------
//  
//  -------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// ***************************************************************
// 
// ***************************************************************
#ifndef FileIO_h__
#define FileIO_h__

#include "tinyxml.h"
#include <string>

enum eUsage
{
	SAVEDATAFILE,
	SAVENNFILE,
	LOADNNFILE
};

class cFileIO
{
private:
	typedef map<const string, const TiXmlElement* > ElementMap;

	TiXmlDocument*	m_pDoc;  
	ElementMap		m_ElementMap;
	TiXmlElement*	m_pRoot;

public:
	cFileIO();
	~cFileIO();
	void Init(const string strRootName);
	void AddComment(const string strParent, const string strComment);
	void AddNode(const string strParent, const string strNode, const string strNodeValue);
	void AddAttribute(const string strNode, const string strAttributeNode, const int iValue );
	void AddAttribute(const string strNode, const string strAttributeNode, const string strValue );
	void Save(const string strFilePath);
	string Load(const string strFilePath);
	string GetNodeName(const string strParent, const int iIndex) ;
	string GetNodeValue(const string strNode);
};

#endif // FileIO_h__

