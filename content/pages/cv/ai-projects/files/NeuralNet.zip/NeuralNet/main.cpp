// *****************************************************************************
//  main   version:  1.0   Ankur Sheel  date: 2010/04/02
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#include "stdafx.h"
#include "NN.h"
#include "FileIO.h"

void CheckForMemoryLeaks();
void Usage();
eUsage GetIsLoad( const char* const load);

int main(int argc, char* argv[])
{
	if (argc < 3)
	{
		Usage();
		exit(0);
	}
	eUsage usage = GetIsLoad(argv[1]);

	CheckForMemoryLeaks();

	cNN NeuralNet;

	if (usage == SAVEDATAFILE
		|| usage == SAVENNFILE)
	{
		if (argc < 5)
		{
			Usage();
			exit(0);
		}
		NeuralNet.InitNN(usage, argv[2], argv[3]);

		int iNoOfIterations = atoi(argv[4]);
		for (int i=0;i<iNoOfIterations;i++)
		{
			NeuralNet.TrainNetwork();
		}
		NeuralNet.WriteNNFile();
		cout<<"TRAINED .. \n";
	}
	else
	{
		NeuralNet.InitNN(usage, argv[2], "");
		NeuralNet.LoadNNFile();
	}

	NeuralNet.TestData();
	
	
	NeuralNet.Destroy();
	return 0;
}

void CheckForMemoryLeaks()
{
	_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CRTDBG_ALLOC_MEM_DF);
}

void Usage()
{
	cout<<"Usage\n";
	cout<<"1) For create data : NeuralNet create_data NNFilePath DataFilePath iterations\n";
	cout<<"2)For create NN : NeuralNet save_NN NNFilePath DataFilePath iterations\n";
	cout<<"2)For load NN : NeuralNet load_NN NNFilePath\n";
}

eUsage GetIsLoad( const char* const load )
{
	if (strnicmp("create_data", load, MAXPATHLENGTH) == 0)
	{
		return SAVEDATAFILE;
	}
	if (strnicmp("save_NN", load, MAXPATHLENGTH) == 0)
	{
		return SAVENNFILE;
	}
	if (strnicmp("load_NN", load, MAXPATHLENGTH) == 0)
	{
		return LOADNNFILE;
	}
	Usage();
	exit(0);
}