// *****************************************************************************
//  NN   version:  1.0   Ankur Sheel  date: 2010/04/02
//  ----------------------------------------------------------------------------
//  
//  ----------------------------------------------------------------------------
//  Copyright (C) 2008 - All Rights Reserved
// *****************************************************************************
// 
// *****************************************************************************
#include "stdafx.h"
#include "NN.h"
#include "NNLayer.h"
#include "Neuron.h"
#include "FileIO.h"

cFileIO fileio;
cFileIO fileio1;
char temp [100];
char temp1[100];

//#define Load

cNN::cNN() 
: m_fLearningRate(0)
{

}

cNN::~cNN()
{
	m_vLayers.clear();
}

void cNN::CreateNN()
{
	if (m_eUsage == SAVEDATAFILE
		|| m_eUsage == SAVENNFILE)
	{
		int		iNoOfHiddenLayer;
		int		iNoOfNeurons;
		fileio1.Init("Root");

		// the 1st layer will be the input layer
		cNNLayer* pNewLayer = new cNNLayer();
		m_vLayers.push_back(pNewLayer);

		cout<<"Enter the no of input neurons\n";
		cin>>m_iNoOfInputNeurons;
		itoa(m_iNoOfInputNeurons, temp, 10);
		fileio1.AddNode("Root", "input_neurons", temp);

		//create the input layer with the required no of neurons
		pNewLayer->CreateLayer(m_iNoOfInputNeurons, INPUT);

		cout<<"Enter the no of hidden layers\n";
		cin>>iNoOfHiddenLayer;
		itoa(iNoOfHiddenLayer, temp, 10);
		fileio1.AddNode("Root", "hidden_layers", temp);

		//loop for all the hidden layers
		for (int i=0;i<iNoOfHiddenLayer;i++)
		{
			pNewLayer = new cNNLayer();
			m_vLayers.push_back(pNewLayer);
			cout<<"Enter the no of neurons in hidden layer "<<i+1<<"\n";
			cin>>iNoOfNeurons;
			itoa(iNoOfNeurons, temp, 10);
			sprintf(temp1, "hidden_layer%d", i+1 );
			fileio1.AddNode("Root", temp1, temp);
			//create the hidden layer
			pNewLayer->CreateLayer(iNoOfNeurons, HIDDEN);
		}

		// the final layer will be the o/p layer
		pNewLayer = new cNNLayer();
		m_vLayers.push_back(pNewLayer);

		cout<<"Enter the no of output neurons\n";
		cin>>m_iNoOfOutputNeurons;
		itoa(m_iNoOfOutputNeurons, temp, 10);
		fileio1.AddNode("Root", "output_neurons", temp);

		//create the output layer
		pNewLayer->CreateLayer(m_iNoOfOutputNeurons, OUTPUT);

		m_fLearningRate = 0.9f; 
		_gcvt(m_fLearningRate, 2, temp);
		fileio1.AddNode("Root", "learning_rate", temp);

		//fileio.Save(m_strFilePath);

		ReadTrainingData();
	}
	if (m_eUsage == LOADNNFILE)
	{
		int		iNoOfHiddenLayer;
		int		iNoOfNeurons;
		int		count = 0;
		string strRoot = fileio1.Load(m_strNNFilePath);
		string strNode;

		// the 1st layer will be the input layer
		cNNLayer* pNewLayer = new cNNLayer();
		m_vLayers.push_back(pNewLayer);

		strNode = fileio1.GetNodeName(strRoot,count++);
		string strNode1 = fileio1.GetNodeValue(strNode);
		m_iNoOfInputNeurons = atoi(strNode1.c_str());

		//create the input layer with the required no of neurons
		pNewLayer->CreateLayer(m_iNoOfInputNeurons, INPUT);

		strNode = fileio1.GetNodeName(strRoot,count++);
		strNode1 = fileio1.GetNodeValue(strNode);
		iNoOfHiddenLayer = atoi(strNode1.c_str());

		//loop for all the hidden layers
		for (int i=0;i<iNoOfHiddenLayer;i++)
		{
			pNewLayer = new cNNLayer();
			m_vLayers.push_back(pNewLayer);

			strNode = fileio1.GetNodeName(strRoot,(count));
			count++;
			string strNode1 = fileio1.GetNodeValue(strNode);
			iNoOfNeurons = atoi(strNode1.c_str());

			pNewLayer->CreateLayer(iNoOfNeurons, HIDDEN);
		}

		// the final layer will be the o/p layer
		pNewLayer = new cNNLayer();
		m_vLayers.push_back(pNewLayer);

		strNode = fileio1.GetNodeName(strRoot,count++);
		strNode1 = fileio1.GetNodeValue(strNode);
		m_iNoOfOutputNeurons = atoi(strNode1.c_str());

		//create the output layer
		pNewLayer->CreateLayer(m_iNoOfOutputNeurons, OUTPUT);

		strNode = fileio1.GetNodeName(strRoot,count++);
		strNode1 = fileio1.GetNodeValue(strNode);
		m_fLearningRate = (float)atof(strNode1.c_str());

		//ReadTrainingData();
	}
}


// Parameter: const vector<float> & InSet - the input data for the network
void cNN::SetInput( const vector<float>& InSet )
{
	//set the i/p value at the layer level
	for (int i=0; i<m_iNoOfInputNeurons; i++)
	{
		m_vLayers[0]->SetInputValues(i,InSet[i]);	
	}	
}

// Parameter: const vector<float> & OutSet - the Output data for the network
void cNN::SetOutput(const vector<float>& OutSet)
{

	cNNLayer	*pOutputLayer = m_vLayers[m_vLayers.size()-1];

	//set the o/p value at the layer level
	for (int i=0; i<m_iNoOfOutputNeurons; i++)
	{
		pOutputLayer->SetOutputValues(i,OutSet[i]);	
	}	
}

void cNN::Evaluate()
{
	int		iTotalNoOfLayers = (int)m_vLayers.size();

	// Evaluate all Hidden layers
	for(int i=1; i<=iTotalNoOfLayers-1;i++) // 1st layer is input and last is output
	{
		m_vLayers[i]->Evaluate();		
	}

}

//sets up the post links b/w the layers
void cNN::SetNNLinks()
{
	int		iTotalNoOfLayers = (int)m_vLayers.size();

	for (int i=0; i<iTotalNoOfLayers-1; i++)// o/p layer will have no post links
	{
		m_vLayers[i]->SetLinkForLayer(m_vLayers[i+1]);
	}
}

bool cNN::TrainNetwork()
{
	int		iOutputLayerIndex = (int)m_vLayers.size() - 1;

	for(unsigned int j = 0 ; j<m_TrainingSet.size();j++)
	{
		//m_fLearningRate *= 0.9999;

		//train the n/w for the data from the training set
		SetInput(m_TrainingSet[j].InputSet);
		SetOutput(m_TrainingSet[j].OutputSet);
		Evaluate();

		//Run Back Propagation algo
		for(int i = iOutputLayerIndex ;i>=0 ;i--)
		{
			m_vLayers[i]->AdjustWeights(m_fLearningRate);
		}
	}
	return false;
}

void cNN::WriteNNFile()
{
	if (m_eUsage == SAVEDATAFILE
		|| m_eUsage == SAVENNFILE)
	{
		char temp[100];
		int		iTotalNoOfLayers = (int)m_vLayers.size();
		fileio1.AddNode("Root", "Layers", "");
		for (int i=0; i<iTotalNoOfLayers; i++)// o/p layer will have no post links
		{
			sprintf(temp, "Layer%d", i+1 );
			fileio1.AddNode("Layers", temp, "");
			m_vLayers[i]->WriteNeuronWeight( fileio1, temp);
		}
		fileio1.Save(m_strNNFilePath);
	}
}
void cNN::ReadTrainingData()
{
	if (m_eUsage == SAVEDATAFILE)
	{
		int		inSets;
		float	val;
		char	temp2[100];

		fileio.Init("Training_Data");
		//fileio.AddNode("Root", "Training_Data", "");

		cout<<"Enter the number of training sets : ";
		cin>>inSets;
		itoa(inSets, temp, 10);
		fileio.AddNode("Training_Data", "training_sets", temp);
		for(int i=0; i<inSets; i++)
		{
			stTrainingSet newSet;
			m_TrainingSet.push_back(newSet);
			cout<<"Enter the input values for "<<i+1<<" Input Set"<<"\n";
			sprintf(temp1, "training_set%d", i+1 );
			fileio.AddNode("Training_Data", temp1, "");

			for(int j=0;j<m_iNoOfInputNeurons;j++)
			{
				cout<<"Enter the input value for "<<j+1<<" Neuron"<<"\n";
				cin>>val;
				//itoa(val, temp, 10);
				_gcvt(val,10,temp);
				sprintf(temp2, "%sInput_Neuron%d", temp1, j+1 );
				fileio.AddNode(temp1, temp2, temp);
				m_TrainingSet[i].InputSet.push_back(val);
			}
			cout<<"Enter the Output values for "<<i+1<<" Output Set"<<"\n";
			for(int j=0;j<m_iNoOfOutputNeurons;j++)
			{
				cout<<"Enter the Output value for "<<j+1<<" Neuron"<<"\n";
				cin>>val;
				//itoa(val, temp, 10);
				_gcvt(val,10,temp);
				sprintf(temp2, "%sOutput_Neuron%d", temp1, j+1 );
				fileio.AddNode(temp1, temp2, temp);
				m_TrainingSet[i].OutputSet.push_back(val);
			}		
		}
		fileio.Save(m_strDataFilePath);
	}
	if (m_eUsage == SAVENNFILE)
	{
		int		inSets;
		float	val;
		string strNode;
		string strParent;
		string strRoot = fileio.Load(m_strDataFilePath);
		//string strRoot = fileio.GetNodeName("Root",0);
		strNode = fileio.GetNodeName(strRoot,0);
		string strNode1 = fileio.GetNodeValue(strNode);
		inSets = atoi(strNode1.c_str());
		int count;
		for(int i=0; i<inSets; i++)
		{
			stTrainingSet newSet;
			m_TrainingSet.push_back(newSet);
			strParent = fileio.GetNodeName(strRoot,i+1);
			count = 0;
			for(int j=0;j<m_iNoOfInputNeurons;j++)
			{
				strNode = fileio.GetNodeName(strParent,j);
				strNode1 = fileio.GetNodeValue(strNode);
				val = (float)atof(strNode1.c_str());
				m_TrainingSet[i].InputSet.push_back(val);
				count++;
			}		
			for(int j=0;j<m_iNoOfOutputNeurons;j++)
			{
				strNode = fileio.GetNodeName(strParent, count+j);
				strNode1 = fileio.GetNodeValue(strNode);
				val = (float)atof(strNode1.c_str());
				m_TrainingSet[i].OutputSet.push_back(val);
			}		
		}
	}
}

void cNN::Destroy()
{
	int			iTotalNoOfLayers = (int)m_vLayers.size();

	for (int i=0; i<iTotalNoOfLayers; i++)
	{
		m_vLayers[i]->Destroy();
		SAFE_DELETE(m_vLayers[i]);
	}
	m_vLayers.clear();
}

void cNN::InitNN( const eUsage eUsage, const char* const strNNFilePath, const char* const strDataFilePath )
{
	m_eUsage = eUsage;
	strcpy_s(m_strNNFilePath, MAXPATHLENGTH, strNNFilePath );
	strcpy_s(m_strDataFilePath, MAXPATHLENGTH, strDataFilePath );

	CreateNN();
	SetNNLinks();
}

void cNN::LoadNNFile()
{
	int		iTotalNoOfLayers = (int)m_vLayers.size();
	string strRoot = fileio1.GetNodeName("Root",iTotalNoOfLayers+2);

	string strNode;

	for (int i=0; i<iTotalNoOfLayers; i++)// o/p layer will have no post links
	{
		strNode = fileio1.GetNodeName(strRoot, i);
		m_vLayers[i]->ReadNeuronWeights(fileio1, strNode.c_str());
	}
}

void cNN::TestData()
{
	stTrainingSet newSet;
	char cInput;
	while(1)
	{
		newSet.InputSet.clear();
		cout<<"Do you want to give a test data(y or n) : ";
		cin>> cInput;
		if (cInput != 'y')
		{
			break;
		}
		cout<<"Enter the input values\n";
		float val;
		for(int j=0;j<m_iNoOfInputNeurons;j++)
		{
			cout<<"Enter the input value for "<<j+1<<" Neuron"<<"\n";
			cin>>val;
			_gcvt(val,10,temp);
			newSet.InputSet.push_back(val);
		}
		SetInput(newSet.InputSet);
		Evaluate();
		unsigned int iNoOfLayers = m_vLayers.size();
		for(int j=0;j<m_iNoOfOutputNeurons;j++)
		{
			cout<<"Output Neuron "<<j+1<<" : ";
			float value = (m_vLayers[iNoOfLayers-1])->GetNeuron(j)->GetValue();
			cout<<value<<"\n";
		}
	}
}